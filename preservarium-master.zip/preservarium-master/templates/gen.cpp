#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();

int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
	}

	if(type == "extreme") {
	}

	generate();
	return 0;
}

void generate()
{
}
