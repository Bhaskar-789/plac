#include <bits/stdc++.h>
#define ll long long
using namespace std;

vector<int> adj[3001];
vector<int> dis(3001,-1);

int dfs(int u,int par,vector<int>&vis){
    vis[u]=1;
    for(int t:adj[u]){
        if(!vis[t]){
            int x=dfs(t,u,vis);
            if(x==0)return 0;
            if(x>0){
                dis[u]=0;
                if(u==x)return 0;
                else return x;
            }
        }
        else if(t!=par){
            dis[u]=0;
            return t;
        }
    }
    return -1;
}

int main(){
    int n,m,x,y;
    cin>>n>>m;
    for(int i=0;i<m;i++){
        cin>>x>>y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }
    vector<int> vis(n+1,0);
    dfs(1,-1,vis);
    queue<int> q;
    for(int i=1;i<=n;i++){
        if(dis[i]==0)q.push(i);
    }
    while(!q.empty()){
        int p=q.front();q.pop();
        for(int t:adj[p]){
            if(dis[t]>=0)continue;
            dis[t]=dis[p]+1;
            q.push(t);
        }
    }
    for(int i=1;i<=n;i++)cout<<dis[i]<<" ";
    return 0;
}