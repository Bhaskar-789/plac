# Node-Distances

---

# Intuition
First find the nodes in the cycle via dfs,then perform bfs strating from these nodes to find the distances.
You can construct the adjacency list from the input and then keep an additional `vis` array.Whenever we visit a node twice we backtrack and mark the `dis[ ]` values for these nodes as 0  
Then we push these nodes having `dis[ ]` 0 to a queue and perform bfs and update the `dis[ ]` entries.  

---

# Pseudocode
```py
def dfs(u,par,vis):
    vis[u]=1
    for t in adj[u]:
        if(not vis[t]):
            x=dfs(t,u ,vis)
            #if cycle has been found return a value 0
            if(x==0):
                return 0
            if(x>0):
                dis[u]=0

                #cycle end is marked by return value 0
                if(u==x)return 0
                else return x

        #cycle start now backtrack
        else if(t!=par):
            dis[u]=0
            return t
#if node not in cycle and cycle not found yet return -1
    return -1

#perform bfs 
#queue q
for i in 1 to n:
    if(dis[i]==0)q.push(i)

while(!q.empty()):
    p=q.pop()
    for t in adj[p]:
        #if already visited don't visit again
        if(dis[t]>=0):
            continue
        else :
            dis[t]=dis[p]+1
            q.push(t)



```
---

# Code
* [Editorialist/Setter's Solution](sol.cpp)

---
