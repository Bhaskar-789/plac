#include<bits/stdc++.h>
#include "testlib.h"
using namespace std;
/********************* Custom Inputs ***************************/
int n_low=3;
int n_high=3e3;
/********************* Custom Inputs ***************************/
#define endl '\n'
void generate();
int main(int argc, char* argv[]){
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small"){
		n_high = 30;
	}

	if(type == "extreme"){
		n_low = n_high;
	}
	generate();
	return 0;
}
void generate(){
	int g_nodes = rnd.next(n_low, n_high);
	int g_edges = g_nodes;
	cout << g_nodes << " " << g_edges << endl;
	vector<int>nodes(g_nodes);
	for(int i=0;i<g_nodes;i++)
		nodes[i] = i+1;
	shuffle(nodes.begin(), nodes.end(), default_random_engine());
	vector< pair<int,int> >edges;
	int nodes_in_cycle = rnd.next(3, g_nodes);
	for(int i=0;i<nodes_in_cycle;i++){
		edges.push_back({nodes[i], nodes[(i+1) % nodes_in_cycle]});	
	}
	int nbr = 0;
	for(int i=nodes_in_cycle;i<g_nodes;i++){
		nbr = rnd.next(0, i-1);
		edges.push_back({nodes[i], nodes[nbr]});	
	}
	shuffle(edges.begin(), edges.end(), default_random_engine());
	for(auto& edge: edges)
		cout << edge.first << " " << edge.second << endl;
}

