# The-Largest-String

---

# Intuition  
we can solve this using greedy approach.We will go on using the current maximum character until it repeats `k` times and then choose one current next largest character ,and repeat this process for all characters,and whenever there is no `2nd` larger element to choose we will delete the excess largest character and exit.  

---

# Pseudocode
```py
vector<int> cnt(26,0);
for(char c:s)cnt[c-'a']++;
string ans="";
for(int i=25;i>=0;i--){
    while(cnt[i]>0){
        for(int j=0;j<min(cnt[i],k);j++){
            ans.push_back(char('a'+i));
        }
        cnt[i]=max(0,cnt[i]-k);
        if(cnt[i]==0)break;
        bool chk=false;
        for(int j=i-1;j>=0;j--){
            if(cnt[j]>0){ans.push_back(char('a'+j));cnt[j]--;chk=true;break;}
        }
        if(!chk)break;
    }
}
return ans
```
---

# Code
* [Editorialist/Setter's Solution](sol.cpp)

---
