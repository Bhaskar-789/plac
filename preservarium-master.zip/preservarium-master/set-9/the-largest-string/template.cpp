#include <bits/stdc++.h>
using namespace std;


/*
 * Complete the 'getLargestString' function below.
 *
 * The function is expected to return a STRING.
 * The function accepts following parameters:
 *  1. STRING s
 *  2. INTEGER k
 */

string getLargestString(string s, int k) {

}

int main()
{

    string s; cin >> s;

    int k; cin >> k;

    string result = getLargestString(s, k);
    cout << result << "\n";

    return 0;
}