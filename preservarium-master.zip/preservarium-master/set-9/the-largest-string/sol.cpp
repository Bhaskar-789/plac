#include <bits/stdc++.h>
using namespace std;
#define ll long long


/*
 * Complete the 'getLargestString' function below.
 *
 * The function is expected to return a STRING.
 * The function accepts following parameters:
 *  1. STRING s
 *  2. INTEGER k
 */

string getLargestString(string s, int k) {
    vector<int> cnt(26,0);
    for(char c:s)cnt[c-'a']++;
    string ans="";
    for(int i=25;i>=0;i--){
        while(cnt[i]>0){
            for(int j=0;j<min(cnt[i],k);j++){
                ans.push_back(char('a'+i));
            }
            cnt[i]=max(0,cnt[i]-k);
            if(cnt[i]==0)break;
            bool chk=false;
            for(int j=i-1;j>=0;j--){
                if(cnt[j]>0){ans.push_back(char('a'+j));cnt[j]--;chk=true;break;}
            }
            if(!chk)break;
        }
    }
    return ans;
}

int main()
{

    string s; cin >> s;

    int k; cin >> k;

    string result = getLargestString(s, k);
    cout << result << "\n";

    return 0;
}