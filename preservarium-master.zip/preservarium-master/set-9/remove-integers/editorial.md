# Remove Integers

---

# Intuition
 This is pretty much a simulation problem .Only non-trivial part is to find the number of special integers in the range `[l,r]`.This can be calculated using `map`(let's call it `mp`).  
 We will first store `mp[i]=1`,for each special integer and additionally to avoid boundary condition check we will make `mp[(1<<30)+1] =0`  as well as `mp[0] =0`  
 Then we will prefix sum the map by iterating through it.  
 Now to find the number of special integers in the range `[l,r]` find the largest special integer `<=r` using lower_bound for map and the largest special integer `< l` and then subtract map values of these integers.  
 
---

# Pseudocode
```py
for i in special
    mp[i]=1
mp[0]=0
mp[(1<<30)+1]=0
it=mp.begin()
it1=(mp.begin()+1)
#prefix summing the map
while it1 !=mp.end():
    it1->second = it1->second +it->second
    it=it1
    (++it1)

#to find the special integers in the range [l,r] let's call it cnt
it=mp.lower_bound(r)
if(it->first!=r)it--
cnt=it->second
auto it1=mp.lower_bound(l)
it1--
cnt-=it1->second

```
---

# Code
* [Editorialist/Setter's Solution](sol.cpp)

---
