#include <bits/stdc++.h>
#define ll long long
using namespace std;

map<ll,ll> mp;
ll n,p,q,k;

ll cal(ll l,ll r){
    auto it=mp.lower_bound(r);
    if(it->first!=r)it--;
    ll cnt=it->second;
    auto it1=mp.lower_bound(l);
    it1--;
    cnt-=it1->second;
    if(cnt>0){
        if((l+r)%2){
            int mid=(l+r)/2;
            return min(cnt*(r-l+1)*p,cal(l,mid)+cal(mid+1,r));
        }
        else {
            return cnt*(r-l+1)*p;
        }
    }
    else {
        if((l+r)%2){
            int mid=(l+r)/2;
            return min(q,cal(l,mid)+cal(mid+1,r));
        }
        else {
            return q;
        }
    }
}

int main(){
    cin>>n>>p>>q>>k;
    ll x;
    for(int i=0;i<k;i++){
        cin>>x;
        mp[x]++;
    }
    mp[0]=0;
    ll prev=mp.begin()->second;
    auto it=(++mp.begin());
    for(;it!=mp.end();it++){
        it->second+=prev;
        prev=it->second;
    }
    mp[(1<<30)+1]=prev;
    cout<<cal(1,(1<<n));
    return 0;
}