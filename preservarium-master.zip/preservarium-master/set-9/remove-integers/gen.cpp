#include<bits/stdc++.h>
#include "testlib.h"
using namespace std;
/********************* Custom Inputs ***************************/
int n_low=1;
int n_high=30;
int p_low=1;
int p_high=1e4;
int q_low = 1;
int q_high = 1e4;
int size_low = 1;
int size_high = 1e5;
/********************* Custom Inputs ***************************/
#define endl '\n'
void generate();
void generateCustom();
int main(int argc, char* argv[]){
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";

	if(type == "small"){
		n_high = 5;
		p_high = 50;
		q_high = 50;
	}

	if(type == "extreme"){
		n_low = n_high;
	}

	if(type == "custom"){
		n_low = n_high;
		p_low = p_high;
		q_low = q_high;
		generateCustom();
		return 0;
	}
	generate();
	return 0;
}
void generate(){
	int n = rnd.next(n_low, n_high);
	int p = rnd.next(p_low, p_high);
	int q = rnd.next(q_low, q_high);
	unordered_set<int>special_int;
	
	int max_num = (int)pow(2,n);
	size_high = min(size_high, max_num / 2);
	//max_num / 2 to make the probabilility of new random number not being already in the special_int atleast 50%
	int K = rnd.next(1,size_high);

	while(special_int.size() < K)
		special_int.insert(rnd.next(1, max_num));
	
	cout << n << endl;
	cout << p << endl;
	cout << q << endl;
	cout << special_int.size() << endl;// i.e. K
	for(auto i:special_int)
		cout << i << endl;	
}

void generateCustom(){
	int n = rnd.next(n_low, n_high);
	int p = rnd.next(p_low, p_high);
	int q = rnd.next(q_low, q_high);
	unordered_set<int>special_int;
	
	int max_num = (int)pow(2,n);
	
	while(special_int.size() < size_high)
		special_int.insert(rnd.next(1, max_num));

	cout << n << endl;
	cout << p << endl;
	cout << q << endl;
	cout << special_int.size() << endl;// i.e. K
	for(auto i:special_int)
		cout << i << endl;	
}
