#include<bits/stdc++.h>
#include "testlib.h"
using namespace std;
/********************* Custom Inputs ***************************/
int n_low=1;
int n_high=1e6;
int m_low = 1;
int m_high = 1e6;
int onhand_low = 0;
int onhand_high = 1e6;
int supplier_low = 0;
int supplier_high = 1e6;
/********************* Custom Inputs ***************************/
#define endl '\n'
void generate();
void generateCustom();
int main(int argc, char* argv[]){
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small"){
		n_high = 50;
		m_high = 50;
		onhand_high = 10;
		supplier_high = 10;
	}

	if(type == "extreme"){
		n_low = n_high;
		m_low = m_high;
	}
	if(type == "custom"){
		generateCustom();
		return 0;
	}
	generate();
	return 0;
}
void generate(){
	int n = rnd.next(n_low, n_high);
	int m = rnd.next(m_low, m_high);
	vector<int>onhand(n);
	vector<int>supplier(m);
	for(int i=0;i<n;i++)
		onhand[i] = rnd.next(onhand_low, onhand_high);			
	for(int j=0;j<m;j++)
		supplier[j] = rnd.next(supplier_low, supplier_high);
	int demand = rnd.next(1, m+n);

	cout << n << endl;
	for(auto& x: onhand)
		cout << x << endl;
	cout << m << endl;
	for(auto& x:supplier)
		cout << x << endl;
	cout << demand << endl;	
}
void generateCustom(){
	cout << 5 << endl;
	cout << "0\n0\n1\n2\n2" << endl;
	cout << 1 << endl;
	cout << 1 << endl;
	cout << 2 << endl;
}

