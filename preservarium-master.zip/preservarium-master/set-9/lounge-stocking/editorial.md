# Lounge-Stocking

---

# Intuition
Here we will solve the problem using greedy approach. We will sort the expiry of supplier and whenever there is a slot for using creamer from the supplier(let's call it `C`) ,we will use it.That is we will iterate from all values of expiry-dates (0-1000000) and for each date we will find the maximum amount of `C` that we can use such that all the creamers on hand can also be completely used.This approach works because it's always optimal to use the creamers from the supplier as early as possible because they can't be used after the expiry dates.  
So the problem now reduces to finding `C`.For finding this we will calculate the number of free slots available after using all creamers on hand whose expiry is less than equal to `i` in `arr[i]`.  
Now we can see that `arr[i] =(i+1)*demand - (no of creamers on hand expiring <=i)`  
We can now observe that waste is guaranteed iff `arr[i]<0` for some `i`. Now we will find suffix minimum of this `arr[]` in `suf_mn[]` array.  
Now we will iterate `i` from (0-1000000) and will keep another variable `occ` initialised to 0 which stores the number of creamers used whose expiry is `<=i` . Now we can observe that maximum amount of `C` that we can use on day `i` such that all the creamers on hand can also be completely used is exactly `suf\_mn[i]-occ`.So now we will pick `suf\_mn[i]-occ` creamers from supplier and update the occ variable and exit once the creamers from supplier gets empty,and final answer will be `occ`. 

---

# Pseudocode
```py
# calculate arr[]
arr[i] =(i+1)*demand - (no of creamers on hand expiring <=i)

#calculate suf_mn[]
suf_mn[i]=min(suf_min[i+1],arr[i])

#b is the descending sorted creamers from supplier
#calculate occ
occ =0 
for i in range(1000001):
    if(b.empty())break
    #stores the number of creamers from the supplier used on this day
    temp=0
    for j in range(suf_min):
        if(b.empty())break
        if(b.back()>=i):
            temp=temp+1
        #can't use creamers that have expired before
        else j=j-1
        b.pop_back()
    occ+=temp
    return occ
```
---

# Code
* [Editorialist/Setter's Solution](sol.cpp)

---
