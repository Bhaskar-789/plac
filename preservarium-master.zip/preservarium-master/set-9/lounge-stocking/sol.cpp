#include <bits/stdc++.h>
#define ll long long
using namespace std;

int main(){
    ll n,m,x,dem;
    cin>>n;
    vector<ll> arr(1000002,0),suf_mn(1000002,1e9);
    for(int i=0;i<n;i++){
        cin>>x;
        arr[x]++;
    }
    cin>>m;
    vector<ll> b(m);
    for(int i=0;i<m;i++)cin>>b[i];
    sort(b.begin(),b.end(),greater<ll>());
    cin>>dem;
    ll sum=0;
    bool ok=true;
    for(int i=0;i<=1000000;i++){
        sum+=arr[i];
        arr[i]=(i+1)*dem - sum;
        if(arr[i]<0)ok=false;
    }
    if(!ok)cout<<-1;
    else {
        for(int i=1000000;i>=0;i--){
            suf_mn[i]=min(arr[i],suf_mn[i+1]);
        }
        ll occ=0;
        for(int i=0;i<=1000000;i++){
            if(b.empty())break;
            ll temp=0;
            for(int j=0;j<suf_mn[i]-occ;j++){
                if(b.empty())break;
                if(b.back()>=i){temp++;}
                else j--;
                b.pop_back();
            }
            occ+=temp;
        }
        cout<<occ;
    }
    return 0;
}