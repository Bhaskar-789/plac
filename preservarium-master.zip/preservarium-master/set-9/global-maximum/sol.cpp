#include <bits/stdc++.h>
#define ll long long
using namespace std;

int main(){
    int n,m;
    cin>>n;
    vector<ll> arr(n);
    for(int i=0;i<n;i++){
        cin>>arr[i]; 
    }
    cin>>m;
    ll st=1,end=1e9;
    while(st<end){
        ll mid=(st+end+1)/2;
        ll cnt=1,prev=arr[0];
        for(int i=1;i<n;i++){
            if(arr[i]>=prev+mid){
                cnt++;prev=arr[i];
            }
        }
        if(cnt>=m){
            st=mid;
        }
        else end=mid-1;
    }
    cout<<st;
    return 0;
}