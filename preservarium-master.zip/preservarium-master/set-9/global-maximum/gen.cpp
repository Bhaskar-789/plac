#include<iostream>
#include "testlib.h"
using namespace std;
/********************* Custom Inputs ***************************/
int n_low=2;
int n_high=1e5;
int number_low=1;
int number_high=1e9;
/********************* Custom Inputs ***************************/
#define endl '\n'
void generate();
int main(int argc, char* argv[]){
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";

	if(type == "small"){
		n_high = 10;
		number_high = 50;
	}

	if(type == "extreme"){
		n_low = n_high;
	}

	generate();
	return 0;
}
void generate(){
	int n = rnd.next(n_low, n_high);
	int m = rnd.next(2,n);
	set<int>a;
	while((int)a.size() != n){
		a.insert(rnd.next(number_low,number_high));
	} 
	cout << n << endl;
	set<int>::iterator iter = a.begin();
	for(;iter != a.end();iter++){
		cout << *iter << endl;
	}
	cout << m << endl;
}