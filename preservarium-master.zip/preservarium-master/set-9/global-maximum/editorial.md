# Global Maximum

---

# Intuition
Here we are asked to find the maximum of minimum of pairwise differences of all m length subsequences.We will use binary search to find this maximum value.If we know that there is a `m` length subsequence whose currentMinimum is greater than or equal to `val`,we can say that the answer for this problem will surely be greater than or equal to `val`.  
We will check whether there is a `m` length subsequence whose currentMinimum is greater than or equal to `val` greedily, we will start from the first element(`prev`) and find the next element which is greater than and nearest to `prev + val`,and then assign `prev` to this element and continue this process till the end of the array.If the count of elements we have encountered in this process `>=m` ,we can say that answer will be greater than or equal to `val`. 

---

# Pseudocode
```py
st=1,end=1e9
while st<end:
    val=(st+end+1)/2
    prev=arr[0]
    cnt=1
    for i in 1 to n:
        if prev+val>=arr[i]:
            prev=arr[i]
            cnt=cnt+1
    if cnt>=m:
        st=val
    else 
        end=val-1
```
---

# Code
* [Editorialist/Setter's Solution](sol.cpp)

---
