#include <bits/stdc++.h>
using namespace std;


/*
 * Complete the 'processLogs' function below.
 *
 * The function is expected to return a STRING_ARRAY.
 * The function accepts following parameters:
 *  1. STRING_ARRAY logs
 *  2. INTEGER maxSpan
 */


vector<string> processLogs(vector<string> logs, int maxSpan) {



}


int main()
{

    int logs_count; cin >> logs_count;

    vector<string> logs(logs_count);

    for (int i = 0; i < logs_count; i++) {
        string logs_item; cin >> logs_item;
        logs[i] = logs_item;
    }


    int maxSpan; cin >> maxSpan;

    vector<string> result = processLogs(logs, maxSpan);

    for (int i = 0; i < result.size(); i++) {
        cout << result[i];

        if (i != result.size() - 1) {
            cout << "\n";
        }
    }

    cout << "\n";

    return 0;
}