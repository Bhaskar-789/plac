#include<bits/stdc++.h>
#include "testlib.h"
using namespace std;
/********************* Custom Inputs ***************************/
int n_low=1;
int n_high=1e5;
int timeStamp_low=1;
int timeStamp_high=1e9 - 1;//To handle timestamp1 == timestamp2 cases smoothly by making timestamp2 = timestamp2 + 1
int userId_low = 1;
int userId_high = 1e9 - 1;
vector<string>action = {"sign-in", "sign-out"};
/********************* Custom Inputs ***************************/
#define endl '\n'
void generate();
void generateCorner();
void print(vector< vector<int> >& logs, int maxSpan);
int main(int argc, char* argv[]){
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small"){//All users have sign-in and sign-out time.
		n_high = 20;
		timeStamp_high = 500;
		userId_high = 50;
	}

	if(type == "extreme"){//All users have sign-in and sign-out time.
		n_low = n_high;
	}
	if(type == "corner"){
		generateCorner();
		return 0;
	}
	generate();
	return 0;
}
void generate(){
	int n = rnd.next(n_low, n_high);
	if(n % 2)
		n += 1;

	vector< vector<int> >logs(n,vector<int>(3,0));
	int userId, timeStamp1,timeStamp2;
	int minSpan = timeStamp_high;
	unordered_set<int>users;
	while(users.size() < n/2)
		users.insert(rnd.next(userId_low, userId_high));
	int i = 0;
	for(auto userId:users){
		logs[i][0] = userId;
		logs[i+1][0] = userId;
		timeStamp1 = rnd.next(timeStamp_low, timeStamp_high);
		timeStamp2 = rnd.next(timeStamp_low, timeStamp_high);
		if(timeStamp1 > timeStamp2)
			swap(timeStamp1, timeStamp2);
		timeStamp2 = (timeStamp1 == timeStamp2) ? timeStamp2+1 : timeStamp2;
		logs[i][1] = timeStamp1;
		logs[i+1][1] = timeStamp2;
		minSpan = min(minSpan, timeStamp2 - timeStamp1);
		logs[i][2] = 0;
		logs[i+1][2] = 1;
		i += 2;		
	}
	int maxSpan = rnd.next(minSpan, timeStamp_high);
	print(logs, maxSpan);
}
void generateCorner(){
	unordered_set<int>users;
	while(users.size() < 2)
		users.insert(rnd.next(userId_low, userId_high));
	vector< vector<int> >logs(3,vector<int>(3,0));
	unordered_set<int>::iterator iter = users.begin();
	int userId1 = *iter;
	iter++;
	int  userId2 = *iter;
	int timeStamp1 = rnd.next(timeStamp_low, timeStamp_high);
	int timeStamp2 = rnd.next(timeStamp_low, timeStamp_high);
	if(timeStamp1 > timeStamp2)
		swap(timeStamp1, timeStamp2);
	int maxSpan = timeStamp2 - timeStamp1;
	logs[0][0] = userId1;
	logs[1][0] = userId1;
	logs[0][1] = timeStamp1;
	logs[1][1] = timeStamp2;
	logs[0][2] = 0;
	logs[1][2] = 1;
	logs[2][0] = userId2;
	int timeStamp = rnd.next(timeStamp_low, timeStamp_high);
	logs[2][1] = timeStamp;
	logs[2][2] = rnd.next(0,1);
	print(logs, maxSpan);
}
void print(vector< vector<int> >& logs, int maxSpan){
	cout << logs.size() << endl;
	shuffle(logs.begin(), logs.end(), default_random_engine());
	for(int i=0;i<logs.size();i++)
		cout << logs[i][0] << " " << logs[i][1] << " " << action[ logs[i][2] ] << endl;
	cout << maxSpan << endl;
}
