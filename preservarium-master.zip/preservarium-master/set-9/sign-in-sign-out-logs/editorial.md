# Sign-in-Sign-out logs

---

# Intuition
 maintain two maps holding in and out time of the `id's` and output if their `session <=maxSpan`  
 
---

# Pseudocode
```py
if(out[id]-in[id]<=maxSpan):
    cout<<id<<" "
```
---

# Code
* [Editorialist/Setter's Solution](sol.cpp)

---
