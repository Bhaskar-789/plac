#include <bits/stdc++.h>
#define ll long long
using namespace std;

int main(){
    ll n,id,t,mx;
    string s;
    cin>>n;
    map<int,ll> in,out;
    for(int i=0;i<n;i++){
        cin>>id>>t>>s;
        if(s =="sign-in"){
            in[id]=t;
        }
        else if(s =="sign-out"){
            out[id]=t;
        }
    }
    cin>>mx;
    for(auto p:in){
        if(out[p.first]!=0){
            if(out[p.first]-in[p.first]<=mx)cout<<p.first<<" ";
        }
    }
    return 0;
}