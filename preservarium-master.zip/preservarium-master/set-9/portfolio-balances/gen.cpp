#include<iostream>
#include "testlib.h"
using namespace std;
/********************* Custom Inputs ***************************/
int n_low=3;
int n_high=1e7;
int row_low=1;
int row_high=2e5;
int contri_low = 0;
int contri_high = 1e9;
/********************* Custom Inputs ***************************/
#define endl '\n'
void generate();
void generateCustom();
int main(int argc, char* argv[]){
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";

	if(type == "small"){
		n_high = 20;
		row_high = 10;
		contri_high = 50;
	}

	if(type == "extreme"){
		n_low = n_high;
		row_low = row_high;
	}

	if(type == "custom"){
		n_low = n_high;
		row_low = row_high;
		contri_low = contri_high;
		generateCustom();
		return 0;
	}
	generate();
	return 0;
}
void generate(){
	int n = rnd.next(n_low, n_high);
	int row = rnd.next(row_low,row_high);
	vector< vector<int> >rounds(row,vector<int>(3,0));

	for(int i=0;i<rounds.size();i++){
		rounds[i][0] = rnd.next(1,n);
		rounds[i][1] = rnd.next(1,n);
		rounds[i][2] = rnd.next(contri_low,contri_high);
			
		if(rounds[i][0] > rounds[i][1])
			swap(rounds[i][0],rounds[i][1]);
	}
	cout << n << endl;
	cout << rounds.size() << endl;
	cout << rounds[0].size() << endl;
	for(int i = 0;i < rounds.size();i++){
		for(int j=0;j < rounds[0].size();j++)
			cout << rounds[i][j] << " ";
		cout << endl;
	}
}
void generateCustom(){
	int n = rnd.next(n_low, n_high);
	int row = rnd.next(row_low,row_high);
	vector< vector<int> >rounds(row,vector<int>(3,0));
	
	for(int i=0;i<rounds.size();i++){
		rounds[i][0] = 1;
		rounds[i][1] = n;
		rounds[i][2] = rnd.next(contri_low,contri_high);
	}
	cout << n << endl;
	cout << rounds.size() << endl;
	cout << rounds[0].size() << endl;
	for(int i = 0;i < rounds.size();i++){
		for(int j=0;j < rounds[0].size();j++)
			cout << rounds[i][j] << " ";
		cout << endl;
	}
}
