# Portfolio-Balances

---

# Intuition  

We can use prefix-sum + difference array method to add the contributions in  the range `[left,right]` in `O(1)` time.
We will maintain array-`A` initialised to 0 and when new contribution come in the range `[left,right]`,we will add the contribution to `A[left]` and subtract contribution from `A[right+1]`.  
Since we are taking prefix sum at the end we will get the correct total investment values and then we can take max among those.  

---

# Pseudocode
```py

for each (l,r,contribution) in the input:
    A[l]+=contribution
    A[r+1]-=contribution

ans=0
for i in range(1,size(A)):
    A[i]+=A[i-1]
    ans=max(ans,A[i])

```
---

# Code
* [Editorialist/Setter's Solution](sol.cpp)

---
