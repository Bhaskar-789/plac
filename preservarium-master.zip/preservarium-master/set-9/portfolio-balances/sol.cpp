#include <bits/stdc++.h>
#define ll long long
using namespace std;

int main()
{
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    ll n,rounds,dum;
    cin>>n>>rounds>>dum;
    ll l,r,contrib;
    vector<ll> A(n+1,0);
    for(int i=0;i<rounds;i++){
        cin>>l>>r>>contrib;
        A[l]+=contrib;
        A[r+1]-=contrib;
    }
    ll ans=0;
    for(int i=1;i<=n;i++){
        A[i]+=A[i-1];
        ans=max(ans,A[i]);
    }
    cout<<ans;
}