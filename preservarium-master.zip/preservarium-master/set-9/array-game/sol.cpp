#include <bits/stdc++.h>
#define ll long long
using namespace std;

int main(){
    int n;
    cin>>n;
    vector<ll> arr(n);
    ll sum=0,mn=1e9;
    for(int i=0;i<n;i++){
        cin>>arr[i];
        sum+=arr[i];
        mn=min(mn,arr[i]);
    }
    cout<<sum-n*mn;
    return 0;
}