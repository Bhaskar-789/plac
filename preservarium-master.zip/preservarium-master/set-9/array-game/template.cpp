#include <bits/stdc++.h>
using namespace std;


/*
 * Complete the 'countMoves' function below.
 *
 * The function is expected to return a LONG_INTEGER.
 * The function accepts INTEGER_ARRAY numbers as parameter.
 */

long countMoves(vector<int> numbers) {

}

int main()
{

    int numbers_count; cin >> numbers_count;

    vector<int> numbers(numbers_count);

    for (int i = 0; i < numbers_count; i++) {
        cin >> numbers[i];
    }

    long result = countMoves(numbers);

    cout << result << endl;

    return 0;
}