# Array Game

---

# Intuition  
Increasing all n-1 element except one element, is equivalent to decreasing a single element of array. So we have to finally make all elements equal to the min element of the array , and the number of moves required for that will give the answer.  

---

# Pseudocode
```py
ans= sum(array) -n*min(array)
```
---

# Code
* [Editorialist/Setter's Solution](sol.cpp)

---
