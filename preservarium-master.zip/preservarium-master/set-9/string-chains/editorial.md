# String Chains

---

# Intuition
 First sort the strings based on their length (can use custom comparator)  
 Iterate through this vector of strings and maintain a `map` which stores the maximum chain starting from the current string.
 To find this value we can check all the strings of one character less than the current string and take the maximum chain possible from those strings and update the map value for this string.And the maximum of the values present in the map will be our final answer.  
 
---

# Pseudocode
```py
# custom comparator
bool comp(string &a,string &b):
    return a.length()< b.length()
sort(inp.begin(),inp.end(),comp)

for v[i] in inp:
    if(v[i].length()==1)mp[v[i]]=1
    else {
        string s="";
        int x=0;
        for j in range(v[i].length()):
            x=max(x,mp[(s+v[i].substr(j+1,v[i].length()-j-1))]);
            s.push_back(v[i][j]);
        mp[s]=x+1
    }
    ans=max(ans,mp[v[i]])

return ans
```
---

# Code
* [Editorialist/Setter's Solution](sol.cpp)

---
