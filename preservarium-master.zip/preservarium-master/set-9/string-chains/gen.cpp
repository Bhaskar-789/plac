#include<bits/stdc++.h>
#include "testlib.h"
using namespace std;
/********************* Custom Inputs ***************************/
int n_low=1;
int n_high=50000;
int word_size_low = 1;
int word_size_high = 60;
int alpha_size_low = 1;
int alpha_size_high = 26;
/********************* Custom Inputs ***************************/
#define endl '\n'
void generate();

int main(int argc, char* argv[]){
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small"){
		n_high = 50;
		alpha_size_high = 5;
		word_size_high = 10;
	}
	if(type == "extreme"){
		n_low = n_high;
		alpha_size_high = 10;
	}
	generate();
	return 0;
}
void generate(){
	int n = rnd.next(n_low,n_high);
	cout << n << endl;
	int alpha_size = rnd.next(alpha_size_low, alpha_size_high);
	string s = "";
	int word_size = 0;
	for(int i=0;i<n;i++){
		s = "";
		word_size = rnd.next(word_size_low, word_size_high);
		for(int j=0;j<word_size;j++)
			s.push_back(rnd.next('a','a' + alpha_size - 1));
		cout << s << endl;
	}
}
