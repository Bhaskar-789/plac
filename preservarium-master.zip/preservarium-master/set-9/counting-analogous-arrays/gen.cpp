#include<iostream>
#include "testlib.h"
using namespace std;
/********************* Custom Inputs ***************************/
int n_low=1;
int n_high=1e5;
int bound_low=-1e9;
int bound_high=1e9;
int diff_low = -2e9;
int diff_high = 2e9;
/********************* Custom Inputs ***************************/
#define endl '\n'
void generate();
void generateCustom();
void generateCustomExtreme();
int main(int argc, char* argv[]){
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";

	if(type == "small"){
		n_high = 20;
		bound_low = -10;
		bound_high = 10;
		diff_low = -10;
		diff_high = 10;
	}

	if(type == "extreme"){
		n_low = n_high;
	}

	if(type == "custom"){
		n_low = n_high;
		generateCustom();
		return 0;
	}

	if(type == "customextreme"){
		n_low = n_high;
		diff_low = diff_high;
		generateCustomExtreme();
		return 0;
	}

	generate();
	return 0;
}
void generate(){
	int n = rnd.next(n_low, n_high);
	vector<int>diff(n);
	for(int i=0;i<diff.size();i++)
		diff[i] = rnd.next(diff_low,diff_high);
	
	int lb = rnd.next(bound_low,bound_high);//Lower_Bound
	int ub = rnd.next(bound_low,bound_high);//Upper_Bound
	
	if(lb > ub)
		swap(lb,ub);
	
	cout << n << endl;
	for(int i=0;i<diff.size();i++)
		cout << diff[i] << endl;
	cout << lb << endl;
	cout << ub << endl;
}
void generateCustom(){
	int n = rnd.next(n_low, n_high);
	vector<int>diff(n);

	for(int i=0;i<diff.size();i++)
		diff[i] = rnd.next(diff_low,diff_high);
	
	int lb = rnd.next(bound_low,bound_low);//Lower_Bound
	int ub = rnd.next(bound_high,bound_high);//Upper_Bound
	
	cout << n << endl;
	for(int i=0;i<diff.size();i++)
		cout << diff[i] << endl;
	cout << lb << endl;
	cout << ub << endl;
}
void generateCustomExtreme(){
	int n = rnd.next(n_low, n_high);
	vector<int>diff(n);
	
	for(int i=0;i<diff.size();i++)
		diff[i] = rnd.next(diff_low,diff_high);
	
	int lb = rnd.next(bound_low,bound_low);//Lower_Bound
	int ub = rnd.next(bound_high,bound_high);//Upper_Bound
	
	cout << n << endl;
	for(int i=0;i<diff.size();i++)
		cout << diff[i] << endl;
	cout << lb << endl;
	cout << ub << endl;
}
