#include <bits/stdc++.h>
#define ll long long
using namespace std;

int main(){
    int n;
    cin>>n;
    vector<ll> arr(n);
    ll pref_sum=0,l,r,mn=1e18,mx=-1e18;
    for(int i=0;i<n;i++){
        cin>>arr[i];
        pref_sum+=arr[i];
        mn=min(mn,pref_sum);
        mx=max(mx,pref_sum);
    }
    cin>>l>>r;
    cout<<max(0LL,min(r+mn,r)-max(l+mx,l)+1);
    return 0;
}