#include <bits/stdc++.h>
using namespace std;

/*
 * Complete the 'countAnalogousArrays' function below.
 *
 * The function is expected to return an INTEGER.
 * The function accepts following parameters:
 *  1. INTEGER_ARRAY consecutiveDifference
 *  2. INTEGER lowerBound
 *  3. INTEGER upperBound
 */

int countAnalogousArrays(vector<int> consecutiveDifference, int lowerBound, int upperBound) {

}

int main()
{
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);

    int n; cin >> n;
    vector<int> consecutiveDifference(n);
    for (auto i : consecutiveDifference)cin >> i;

    int lowerBound; cin >> lowerBound;
    int upperBound; cin >> upperBound;
    int ans = countAnalogousArrays(consecutiveDifference, lowerBound, upperBound);
    cout << ans << endl;
}
