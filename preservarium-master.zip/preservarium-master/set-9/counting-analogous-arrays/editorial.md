# Counting-Analogous-Arrays

---

# Intuition
If first element is `S` then the `ith` element will be  
`S-prefix_sum(sum of elements upto ith element of diff arr)`.  
So for each element `S-pref_sum>=l` and `S-pref_sum<=r` .
Min value `S-pref_sum` can take is when `pref_sum` is maximum,and max value happens when pref_sum is  minimum. So if we ensure that `S-mx>=l` and `S-mn<=r` and `S<=r ` and `S>=l`,we are done. Number of `S` satisying this are:  
 `max(0,min(r+mn,r)-max(l+mx,l)+1)`


---

# Pseudocode
```py
pref_sum=0 ,mx=-1e18,mn=1e18
for i 1 to n:
    pref_sum+=arr[i];
    mx=max(mx,pref_sum)
    mn=mn(mn,pref_sum)
return max(0,min(r+mn,r)-max(l+mn,l)+1)
```
---

# Code
* [Editorialist/Setter's Solution](sol.cpp)

---
