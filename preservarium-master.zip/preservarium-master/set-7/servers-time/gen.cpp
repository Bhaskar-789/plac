#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int n_low=2;
int n_high=(int)1e5;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();
int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
        n_high=10;
	}

	if(type == "extreme") {
        n_low=1e4;
	}
	generate();
	return 0;
}

void generate()
{
    int n=rnd.next(n_low,n_high);
    vector<int> a(n);
    int m=rnd.next(0,n);    //Randomly selecting indices from which we can directly reach the master server
    set<int> st;
    while(st.size( )!=m){
        int cur=rnd.next(1,n);
        st.insert(cur);
    }
    for(int i=0;i<m;++i){
        int cur=*st.begin( );   st.erase(st.begin( ));
        arr[cur-1]=n-cur;
    }
    for(int i=0;i<n;++i){
        if(arr[i])continue;
        arr[i]=rnd.next(n_low,n_high);
    }
    cout<<n<<endl;
    for(auto &e:a){
        cout<<e<<" ";
    }
    cout<<endl;
}