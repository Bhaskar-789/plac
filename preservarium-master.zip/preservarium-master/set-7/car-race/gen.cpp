#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int n_low=1;
int n_high=(int)1e5;
int val_low=1;
int val_high=(int)1e6;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();
int flag=0;
int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
        n_high=10;
        val_high=100;
	}

	if(type == "extreme") {
        n_low=n_high;
	}
    if(type=="increasing"){
        flag=1;
    }
    if(type=="decreasing"){
        flag=-1;
    }
	generate();
	return 0;
}

void generate()
{
    int n=rnd.next(n_low,n_high);
    vector<int> a(n);
    for(auto &e:a){
        e=rnd.next(val_low,val_high);
    }
    if(flag==-1){
        sort(a.begin( ),a.end( ),greater<int>());
    }
    if(flag==1){
        sort(a.begin( ),a.end( ));
    }
    cout<<n<<endl;
    for(auto &e:a){
        cout<<e<<" ";
    }
    cout<<endl;
}