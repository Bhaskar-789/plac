#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int n_low=1;
int n_high=(int)1e6;
int q_low=1;
int q_high=(int)1e6;
int alpha_size_low = 1;
int alpha_size_high = 26;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();
int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
        n_high=15;
        q_high=5;
        alpha_size_high=5;
	}

	if(type == "extreme") {
        n_low=1e6;
        q_low=1e6;
        alpha_size_low=10;
	}
    if(type == "corner"){
        alpha_size_high=2;
    }
	generate();
	return 0;
}

void generate()
{
    int n=rnd.next(n_low,n_high);
    int alpha_size = rnd.next(alpha_size_low, alpha_size_high)
    string s="";
    int ind=0;
    while(ind<n){
        int cur=rnd.next(0,min(ind,n-ind));
        if(cur==0)s+= rnd.next('a', 'a' + alpha_size - 1);
        else{
            int pref_length=rnd.next(1,cur);
            string pref=s.substr(0,pref_length);
            s+=pref;
            ind+=pref_length;
        }
    }
    cout<<s<<endl;
    int q=rnd.next(q_low,q_high);
    cout<<q<<endl;
    for(int i=0;i<q;++i){
        int l,r;    
        l=rnd.next(1,n);
        r=rnd.next(1,n);
        while(r==l){
            r=rnd.next(1,n);
        }
        cout<<l<<" "<<r<<endl;
    }
}