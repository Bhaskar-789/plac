#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int n_low=1;
int n_high=(int)2e5;
int q_low=1;
int q_high=(int)2e5;
int val_low=(int)-1e9;
int val_high=(int)1e9;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();

int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
        n_high=8;
        q_high=5;
        val_low=(int)-100;
        val_high=(int)100;
	}

	if(type == "extreme") {
        n_low=(int)1e5;
        q_low=(int)1e5;
	}
	generate();
	return 0;
}

void generate()
{
    int n=rnd.next(n_low,n_high);
    int q=rnd.next(q_low,q_high);
    cout<<n<<endl;
    vector<int> a(n),b(n);
    for(auto& e:a){
        e=rnd.next(val_low,val_high);
    }
    for(auto& e:b){
        e=rnd.next(val_low,val_high);
    }
    for(auto &e:a){
        cout<<e<<" ";
    }
    cout<<endl;
    for(auto &e:b){
        cout<<e<<" ";
    }
    cout<<endl;
    while(q--){
        int x,y;
        x=rnd.next(val_low,val_high);
        y=rnd.next(val_low,val_high);
        cout<<x<<" "<<y<<endl;
    }
}