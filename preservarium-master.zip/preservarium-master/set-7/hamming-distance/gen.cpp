#include <bits/stdc++.h>
#include <iostream>
#include "testlib.h"
 
using namespace std;
 
#define ll long long 
/********************* Custom Inputs ***************************/
int n_low=1;
int n_high=(int)1e5;
int m_low=1;
int m_high=(int)1e5;
ll val_low=1;
ll val_high=(ll)1e18;
/********************* Custom Inputs ***************************/
 
#define endl '\n'
void generate();
 
int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
        n_high=8;
        m_high=12;
        val_high=100;
	}
 
	if(type == "extreme") {
        n_low=1e5;
        val_low=(ll)1e15;
	}
	generate();
	return 0;
}
 
pair<int,int> gen_edge(int n){
    int x=rnd.next(1,n);
    int y=rnd.next(1,n);
    return make_pair(x,y);
}
 
void generate( ){
    int n=rnd.next(n_low,n_high);
    int m;
    m=rnd.next(1LL*n,min(1LL*m_high,1LL*(n*(n)));
    cout<<n<<" "<<m<<endl;
    vector<ll> a(n),b(n);
    for(int i=0;i<n;++i){
        b[i]=rnd.next(val_low,val_high);
    }
    int x=rnd.next((n+1)/2,n); //Number of elements of `b` we are to put in `a` so as to ensure matching of some elements
    shuffle(b.begin( ),b.end( ));
    for(int i=0;i<x;++i)a[i]=b[i];
    for(int i=x;i<n;++i)a[i]=rnd.next(val_low,val_high);
    set<pair<int,int> > g_edges;
    while(g_edges.size( )!=m){
        g_edges.insert(gen_edge(n));
    }
    for(auto &e:g_edges){
        cout<<e.first<<" "<<e.second<<endl;
    }
}