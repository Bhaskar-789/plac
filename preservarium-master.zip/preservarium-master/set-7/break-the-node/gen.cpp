#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int n_low=2;
int n_high=(int)1e5;
int m_low=1;
int m_high=(int)2e5;
int val_low=1;
int val_high=(int)1e9;
int t_low=1;
int t_high=10;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();
bool isTree=false;
int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
        n_high=8;
        m_high=12;
        val_high=100;
        t_high=1;
	}

	if(type == "extreme") {
        n_low=n_high;
        t_low=t_high;
	}
    if(type== "tree"){
        isTree=true;
    }
	generate();
	return 0;
}
pair<int,int> gen_edge(int n){
    int x=rnd.next(1,n);
    int y=rnd.next(1,n);
    while(x==y){
        x=rnd.next(1,n);
        y=rnd.next(1,n);
    }
    if(x>y)swap(x,y);
    return make_pair(x,y);
}
void generate()
{
    int t=rnd.next(t_low,t_high);
    cout<<t<<endl;
    while(t--){
        int n=rnd.next(n_low,n_high);
        int m;
        if(isTree)m=n-1;
        else m=rnd.next(1LL*n-1,min(1LL*m_high,1LL*(n*(n-1))/2));
        cout<<n<<" "<<m<<endl;
        vector<int> w(n);
        for(auto& e:w){
            w=rnd.next(val_low,val_high);
            cout<<w<<" ";
        }
        cout<<endl;
        vector<pair<int,int> > edges;
        vector<int> perm(n);
        for(int i=2;i<=n,++i){
            edges.push_back(make_pair(rnd.next(1,i-1),i));
        }
        for(int i=1;i<=n;++i)perm[i]=i;
        shuffle(perm.begin( ),perm.end( ));
        shuffle(edges.begin( ),edges.end( ));
        set<pair<int,int> > g_edges;
        for(auto &e:edges){
            int x,y;
            x=perm[e.first];
            y=perm[e.second];
            if(rnd.next(0,1)){
                swap(x,y);
            }
            g_edges.insert(make_pair(x,y));
        }
        while(g_edges.size( )!=m){
            g_edges.insert(gen_edge(n));
        }
        for(auto &e:g_edges){
            cout<<e.first<<" "<<e.second<<endl;
        }
    }
}