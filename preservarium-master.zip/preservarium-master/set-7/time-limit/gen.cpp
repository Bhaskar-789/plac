#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int n_low=2;
int n_high=1000;
int t_low=1;
int t_high=20;
int p_low=1;
int p_high=(int)1e9;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();
vector<int> near;

int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
        n_high=10;
        p_high=100;
        t_high=1;
	}

	if(type == "extreme") {
        t_low=20;
        n_low=1e5;
	}
    if(type=="increasing"){
        flag=1;
    }
    if(type=="decreasing"){
        flag=-1;
    }
    //When the zombie powers are almost equal
    if(type == "corner"){
        flag=0;
        int eq=rnd.next(4,p_high-3);
        near.push_back(eq);
        for(int i=1;i<=3;++i){
            near.push_back(eq-i);
            near.push_back(eq+i);
        }
    }
	generate();
	return 0;
}
void generate( ){
    int t;
    t=rnd.next(t_low,t_high);
    cout<<t<<endl;
    while(t--){
        int n=rnd.next(n_low,n_high);
        vector<int> a(n);
        for(auto &e:a){
            if(flag==0){
                e=near[rnd.next(0,6)];
            }
            else{
                e=rnd.next(p_low,p_high);
            }
        }
        if(flag==1)sort(a.begin( ),a.end( ));
        if(flag==-1)sort(a.begin( ),a.end( ),greater<int>( ));
        cout<<n<<endl;
        for(auto &e:a){
            cout<<e<<" ";
        }
        cout<<endl;
    }
}