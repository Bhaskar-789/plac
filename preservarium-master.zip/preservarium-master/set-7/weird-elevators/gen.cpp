#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int m_low=1;
int m_high=(int)1e6;
int t_low=1;
int t_high=100;
int val_low=1;
int val_high=(int)1e9;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();
int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
        m_low=10;
        m_high=m_low;
        val_high=100;
        t_high=1;
	}

	if(type == "extreme") {
        t_low=t_high;
        m_low=(int)1e4;
        val_low=(int)1e8;
	}
	generate();
	return 0;
}

void generate()
{
    int t=rnd.next(t_low,t_high);
    while(t--){
        
        int m=rnd.next(m_low,m_high);
        int x=rnd.next(m,val_high);
        int y=rnd.next(m,val_high);
        
        cout<<x<<" "<<y<<" "<<m<<endl;
    }
}