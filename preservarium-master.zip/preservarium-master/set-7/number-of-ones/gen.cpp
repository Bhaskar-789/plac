#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
long long n_low=1;
long long n_high=(long long)1e15;
int t_low=1;
int t_high=(int)1e5;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();

int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
        n_high=8;
        t_high=5;
	}

	if(type == "extreme") {
        n_low=(long long)1e12;
        t_low=t_high;
	}

	generate();
	return 0;
}

void generate()
{
    int t=rnd.next(t_low,t_high);
    cout<<t<<endl;
    for(int tt=0;tt<t;++tt){
        int n=rnd.next(n_low,n_high);
        cout<<n<<endl;
    }
}