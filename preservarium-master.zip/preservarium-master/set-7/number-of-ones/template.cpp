#include<bits/stdc++.h>
using namespace std;

long long Num_of_ones_sol (long long N) {
    // Write your code here

}

int main() {

    ios::sync_with_stdio(0);
    cin.tie(0);
    int T;
    cin >> T;
    for (int t_i = 0; t_i < T; t_i++)
    {
        long long N;
        cin >> N;

        long long out_;
        out_ = Num_of_ones_sol(N);
        cout << out_;
        cout << "\n";
    }
}