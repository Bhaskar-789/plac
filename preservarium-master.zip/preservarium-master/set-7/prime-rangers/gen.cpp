#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
long long l_low=1;
long long l_high=(long long)1e18;
long long r_low=1;
long long r_high=(long long)1e18;
int t_low=1;    //Number of test cases
int t_high=5;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();

int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
        l_high=20;
        r_high=20;
        t_high=2;
	}

	if(type == "extreme") {
        t_high=5;
	}
	generate();
	return 0;
}

void generate()
{
    int t=rnd.next(t_low,t_high);
    cout<<t<<endl;
    while(t--){
        long long l=rnd.next(l_low,l_high);
        long long r=rnd.next(l,r_high);
        cout<<l<<" "<<r<<endl;
    }
    cout<<endl;
}