# Contest 2

* [Maximum Reach](../../../set-1/maximum-reach/editorial.md)
* [The Minimum Difference](../../../set-6/the-minimum-difference/editorial.md)
* [Simple Game](../../../set-10/simple-game/editorial.md)

---

# Credits

| **Task**             | **Username**                        |
| -------------------- | ----------------------------------- |
| Model Solution       | `blankSeries`, `variety-jones`, TBA |
| Test Case Generation | `variety-jones`, `anonymous_cow`    |
| Testing              | `lord-voldemort`, TBA               |
| Contest Creation     | `anonymous_cow`, TBA                |
| Editorial            | TBA, `variety-jones`                |
| LaTeX Conversion     | `variety-jones`                     |

---
