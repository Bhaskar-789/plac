# Contest 1

In retrospect, 

> **Parking Dilemma** : LC Medium (Easier band)

> **Team Formation** : LC Hard

> **Modulo Arithmetic Equation** : LC Hard, but a bit on the tougher side.

* [Parking Dilemma](../../../set-1/parking-dilemma/editorial.md)
* [Team Formation](../../../set-1/team-formation/editorial.md)
* [Modulo Arithemetic Equation](../../../set-1/modulo-arithmetic-equation/editorial.md)

---

# Credits

| **Task**             | **Username**            |
| -------------------- | ----------------------- |
| Model Solution       | `blankSeries`           |
| Test Case Generation | TBA                     |
| Testing              | `lord-voldemort`, `TBA` |
| Contest Creation     | TBA, TBA                |
| Editorial            | TBA, `variety-jones`    |
| LaTeX Conversion     | `variety-jones`         |

---
