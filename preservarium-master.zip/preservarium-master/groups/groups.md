# G1 : 90
1. Maximum Partition
2. The Chemist

---

# G2 : 90
1. Friends and Candies
2. Counting Pairs
3. --Filler--

---

# G3 : 100
1. Balance the Tree
2. Charging Phone
3. Intelligent Robots

---
