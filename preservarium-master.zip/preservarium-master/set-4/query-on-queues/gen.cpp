#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int t_low = 1;
int t_high = 50;
int n_low = 1;
int n_high = 1e5;
int k_low = 1;
int k_high = 1e5;
int val_low = 1;
int val_high = 1e9;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();

int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
		t_high = 2;
		n_high = 15;
		k_high = 3;
		val_high = 3;
	}

	if(type == "mixed") {
		val_high = 9;
	}

	if(type == "extreme") {
		t_low = t_high;
		n_low = n_high;
		k_low = k_high;
	}

	generate();
	return 0;
}

void generate()
{
	int t = rnd.next(t_low, t_high);
	cout << t << endl;

	for(int ii = 0; ii < t; ii++) {
		int n = rnd.next(n_low, n_high);
		int k = rnd.next(k_low, k_high);
		vector<int> a(n);
		for(auto &ele : a) {
			ele = rnd.next(val_low, val_high);
		}
		cout << n << " " << k << endl;
		for(auto &ele : a) {
			cout << ele << " ";
		}
		cout << endl;
		for(int jj = 0; jj < k; jj++) {
			int x = rnd.next(1, n);
			cout << x << endl;
		}
	}
}
