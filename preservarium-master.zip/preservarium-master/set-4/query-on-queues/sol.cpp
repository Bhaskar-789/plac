#include<bits/stdc++.h>
using namespace std;

#define A(x) (x).begin(),(x).end()
#define sz(x) ((int)(x).size())
#define UNI(x) sort(A(x)); (x).erase(unique(A(x)),(x).end())
using i64 = long long;
void _read();

struct Solution {
      int n, q;
      vector<int> v, L, R;
      stack<int> st;
      void compress() {
            vector<int> b = v;
            UNI(b);
            for(int &x : v)
                  x = int(lower_bound(A(b), x) - b.begin());
      }
      Solution(int _n, int _q) : n(_n), q(_q), v(n), L(n, -1), R(n, n){
            for(int &x : v)
                  cin >> x;
            compress();
            process();
      };
      void _process(vector<int> &ref, int i) {
            while(!st.empty() && v[st.top()] < v[i]) {
                  ref[st.top()] = i;
                  st.pop();
            }
            st.emplace(i);
      }
      void process() {
            for(int i = 0; i < n; i++)
                  _process(R, i); 
            
            st = stack<int>();

            for(int i = n - 1; i >= 0; --i)
                  _process(L, i);
      }
      void get_queries() {
            while(q--) {
                  int i; cin >> i, --i;
                  int ans = (i - L[i]) + (R[i] - i) - 1;
                  cout << ans << '\n';
            }
      }

};

int main () { _read(); 

      int T = 1;
      cin >> T;
      for( int tt = 1; tt <= T; tt++) {
            int n, q;
            cin >> n >> q;
            Solution(n, q).get_queries();
      }
      return 0;
};

void _read() {
      ios_base :: sync_with_stdio(false);
      cin.tie(NULL);
      #ifdef LOCAL
      freopen("input.txt","r",stdin);
      #endif
}
