#include<bits/stdc++.h>
using namespace std;

int bmove(vector<vector<int>>&lu,vector<vector<int>>&ld,vector<vector<int>>&ru,vector<vector<int>>&rd,int i,int j)
{
    int n =lu.size();
    int m =lu[0].size();
    int ans =0;
    if(j!=0&&i!=0)
    {
        ans+=lu[i-1][j-1];
    }
    if(j!=m-1&&i!=0)
    {
        ans+=ru[i-1][j+1];
    }
    if(j!=0&&i!=n-1)
    {
        ans+=ld[i+1][j-1];
    }
    if(i!=n-1&&j!=m-1)
    {
        ans+=rd[i+1][j+1];
    }
    return ans;
}
int rmove(vector<vector<int>>&l,vector<vector<int>>&r,vector<vector<int>>&d,vector<vector<int>>&u,int i,int j)
{
    int n =l.size();
    int m =l[0].size();
    int ans =0;
    if(j!=0)
    {
        ans+=l[i][j-1];
    }
    if(j!=m-1)
    {
        ans+=r[i][j+1];
    }
    if(i!=0)
    {
        ans+=u[i-1][j];
    }
    if(i!=n-1)
    {
        ans+=d[i+1][j];
    }
    return ans;
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    
    int n,m;
    cin>>n>>m;
    vector<string>board(n);
    for(int i=0;i <n;i++)
    {
        cin>>board[i];
    }
    int ans =0;
    
    vector<vector<int>>l(n,vector<int>(m,0));
    vector<vector<int>>r(n,vector<int>(m,0));
    vector<vector<int>>d(n,vector<int>(m,0));
    vector<vector<int>>u(n,vector<int>(m,0));
    
    vector<vector<int>>ld(n,vector<int>(m,0));
    vector<vector<int>>ru(n,vector<int>(m,0));
    vector<vector<int>>rd(n,vector<int>(m,0));
    vector<vector<int>>lu(n,vector<int>(m,0));
    for(int i =0; i<n;i++)
    {
        for(int j =0;j<m;j++)
        {
            if(board[i][j]=='.')
            {
                if(j!=0)
                {
                    l[i][j] = l[i][j-1]+1;
                }else
                {
                    l[i][j]=1;
                }
                if(i!=0)
                {
                    u[i][j] =u[i-1][j]+1;
                }else
                {
                    u[i][j]=1;
                }
            }
            if(board[n-1-i][m-j-1]=='.')
            {
                if(j!=0)
                {
                    r[n-1-i][m-1-j] =r[n-i-1][m-j]+1;
                }else
                {
                    r[n-1-i][m-1-j]=1;
                }
                if(i!=0)
                {
                    d[n-1-i][m-j-1]=d[n-i][m-j-1]+1;
                }else
                {
                    d[n-1-i][m-1-j]=1;
                }
            }
        }
    }
    for(int j =0; j<m;j++)
    {
        if(board[0][j] =='.')
        {
            ru[0][j] =1;
            lu[0][j] =1;
        }
        if(board[n-1][j] =='.')
        {
            ld[n-1][j]=1;
            rd[n-1][j]=1;
        }
    }
    for(int i =0;i<n;i++)
    {
        if(board[i][0]=='.')
        {
            ld[i][0] =1;
            lu[i][0]=1;
        }if(board[i][m-1]=='.')
        {
            rd[i][m-1]=1;
            ru[i][m-1]=1;
        }
    }
    for(int i=1; i<n;i++ )
    {
        for(int j =1;j<m;j++)
        {
            if(board[i][j]=='.')
            {
                lu[i][j] =lu[i-1][j-1]+1;
                ld[n-1-i][j] =ld[n-i][j-1]+1;
                rd[n-1-i][m-j-1] =rd[n-i][m-j]+1;
                ru[i][m-j-1] =ru[i-1][m-j]+1;
            }
        }
    }
    for(int i =0; i<n;i++)
    {
        for(int j =0; j<m;j++)
        {
            if(board[i][j]=='B'||board[i][j]=='Q')
            {
                ans+=bmove(lu,ld,ru,rd,i,j);
                
            }if(board[i][j]=='Q'||board[i][j]=='R')
            {
                ans+=rmove(l,r,d,u,i,j);
               
            }
        }
    }
    cout<<ans<<'\n';
    return 0;
}
