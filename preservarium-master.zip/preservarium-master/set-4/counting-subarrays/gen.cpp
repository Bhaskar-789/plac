#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int t_low = 1;
int t_high = 20;
int n_low = 1;
int n_high = 1e5;
long long k_low = 1;
long long k_high = (long long)1e15;
long long val_low = 1;
long long val_high = 1e9;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();

int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
		t_high = 2;
		n_high = 15;
		k_high = 150;
		val_high = 10;
	}

	if(type == "mixed") {
		k_high = (long long)1e11;
	}

	if(type == "extreme") {
		t_low = t_high;
		n_low = n_high;
	}

	generate();
	return 0;
}

void generate()
{
	int t = rnd.next(t_low, t_high);
	cout << t << endl;

	for(int ii = 0; ii < t; ii++) {
		long long k = rnd.next(k_low, k_high);
		int n = rnd.next(n_low, n_high);
		vector<long long> a(n);
		for(auto &ele : a) {
			ele = rnd.next(val_low, val_high);
		}
		cout << k << " " << n << endl;
		for(auto &ele : a) {
			cout << ele << " ";
		}
		cout << endl;
	}
}
