#include<bits/stdc++.h>
using namespace std;

#define A(x) (x).begin(),(x).end()
#define sz(x) ((int)(x).size())
#define UNI(x) sort(A(x)); (x).erase(unique(A(x)),(x).end())
using i64 = long long;
void _read();

void test() {
      int n;
      i64 K;
      cin >> K >> n;
      vector<i64> v(n);
      for(auto &x : v)
            cin >> x;
      vector<int> L(n + 1);
      i64 sum = 0;
      for(int i = 0, j = 0; i < n; ++i) {
            sum += v[i];
            while(sum > K && j <= i) {
                  sum -= v[j];
                  j++;
            }
            L[i - j + 1]++;
      }
      for(int i = n - 1; i > 0; i--) {
            L[i] += L[i + 1];
      }
      for(int i = 1; i <= n; ++i) {
            cout << L[i] << ' ';
      }
      cout << '\n';
}

int main () { _read(); 

      int T;
      cin >> T;
      while(T--) {
            test();
      }
      return 0;
};

void _read() {
      ios_base :: sync_with_stdio(false);
      cin.tie(NULL);
      #ifdef LOCAL
      freopen("input.txt","r",stdin);
      #endif
}
