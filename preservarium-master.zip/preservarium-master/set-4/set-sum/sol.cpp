#include<bits/stdc++.h>
using namespace std;

long long power(long long a, long long b)
{
    if(b==0)
    {
        return 1LL;
    }else if(a==0)
    {
        return 0LL;
    }else if(a==1)
    {
        return 1LL;
    }else
    {
        long long ans  =power(a,b/2);
        ans = (ans*ans)%1000000007;
        if(b%2==1)
        {
            ans = (ans*a)%1000000007;
        }
        return ans;
    }
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    
    long long n,k;
    cin>>n>>k;
    vector<long long >a(n);
    for(int i =0; i<n;i++)
    {
        cin>>a[i];
    }
    vector<long long>pdp(k+1,0);
    vector<long long>cdp(k+1,0);
    cdp[0]=1;
    for(int i=0;i<n;i++)
    {
        pdp = cdp;
        for(long long j =0;j<=k;j++)
        {
            if((j+a[i])<=k)
            {
                cdp[j+a[i]] =(cdp[j+a[i]]+pdp[j])%1000000007;
            }
        }
    }
    long long temp = 0;
    for(long long i =0;i<=k;i++)
    {
        temp=(temp+cdp[i])%1000000007;
    }
    temp =(temp*2)%1000000007;
    long long ans = power(2,n);
    ans=(ans-temp+1000000007)%1000000007;
    cout<<ans<<"\n";
    return 0;
}