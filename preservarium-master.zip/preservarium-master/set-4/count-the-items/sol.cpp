#include<bits/stdc++.h>
using namespace std;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t;
    cin>>t;
    vector<vector<int>>factors(1001);
    for(int i =2;i<=1000;i++)
    {
        factors[i].push_back(i);
        for(int j =i+1;j<=1000;j++)
        {
            if(j%i==0)
            {
                factors[j].push_back(i);
                factors[i].push_back(j);
            }
        }
    }
    
    while(t--)
    {
        int n,k;
        cin>>n>>k;
        vector<long long int>pdp(k+1,0),cdp(k+1,0);
        for(int i =1; i<=k;i++)
        {
            pdp[i]=1;
        }
        long long prev =k;
        for(int i=1;i<n;i++)
        {
            long long curr =0;
            cdp[1] = prev;
            curr =cdp[1];
            for(int j =2; j<=k;j++)
            {
                cdp[j]=pdp[1];
                for(int l =0;l<factors[j].size();l++)
                {
                    if(factors[j][l]>=1&&factors[j][l]<=k)
                    cdp[j] =(pdp[factors[j][l]]+cdp[j])%1000000007;
                }
                curr =(curr+cdp[j])%1000000007;
            }
            prev =curr;
            pdp=cdp;
        }
        long long ans =0;
        for(int j =1;j<=k;j++ )
        {
            ans =(ans+cdp[j])%1000000007;
        }
        cout<<ans<<"\n";
    }
    return 0;
    
}
