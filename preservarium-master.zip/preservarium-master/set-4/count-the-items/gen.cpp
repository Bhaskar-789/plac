#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int t_low = 1;
int t_high = 100;
int n_low = 1;
int n_high = 1e3;
int k_low = 1;
int k_high = 1e3;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();

int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
		t_high = 2;
		n_high = 10;
		k_high = 10;
	}

	if(type == "extreme") {
		t_low = t_high;
	}

	generate();
	return 0;
}

void generate()
{
	int t = rnd.next(t_low, t_high);
	cout << t << endl;
	for(int ii = 0; ii < t; ii++) {
		int n = rnd.next(n_low, n_high);
		int k = rnd.next(k_low, k_high);
		cout << n << " " << k << endl;
	}
}
