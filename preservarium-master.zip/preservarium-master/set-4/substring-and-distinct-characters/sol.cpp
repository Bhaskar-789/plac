#include<bits/stdc++.h>
using namespace std;


int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    
    int n;
    cin>>n;
    string s;
    cin>>s;
    for(int l=1;l<=26;l++)
    {
        int j =0;
        int i =0;
        int ccnt =0;
        long long int ans=0;
        vector<int>f(26,0);
        
        for(j=0;j<n;j++)
        {
            f[s[j]-'a']++;
            if(f[s[j]-'a']==1)
            {
                ccnt++;
            }
            while(ccnt>=l)
            {
                ans+=(s.size()-j);
                f[s[i]-'a']--;
                if(f[s[i]-'a']==0)ccnt--;
                i++;
            }
            
        }
        cout<<ans<<" ";
    }
    cout<<"\n";
    
    
    return 0;
}