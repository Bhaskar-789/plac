#include<iostream>
#include "testlib.h"
#include <cassert>
using namespace std;
/********************* Custom Inputs ***************************/
int n_low=1;
int n_high=1e3;
int val_low=0;
int val_high=1e5;
/********************* Custom Inputs ***************************/
#define endl '\n'
void generate();

int main(int argc, char* argv[]){
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";

	if(type == "small"){
		n_high=10;
		val_high=30;
	}
	if(type == "extreme"){
		n_low=n_high;
	}

	generate();
	return 0;
}
void generate(){
	int n = rnd.next(n_low, n_high);
	cout << n << endl;

	vector<int> perm(n);
	for(int i = 0; i < n; ++i)
		perm[i] = i;
	shuffle(perm.begin(), perm.end());

	int k = rnd.next(n/2, n);
	vector<int> multarr(k);
	multarr[0]=rnd.next(1, 5);
	int co = 1;
	int high_range = 5;
	while(co<k) {
		int num= rnd.next(2, 5)*multarr[co- 1];
		if(num<=val_high) {
			multarr[co]=num;
		}
		else {
			high_range = min(val_high, high_range * 5);
			multarr[co] = rnd.next(1, high_range);
		}
		co++;
	}

	int a[n]={0};
	for (int i = 0; i < n-k;i++) {
		a[perm[i]] = rnd.next(val_low, val_high);
	}
	sort(perm.begin() + n - k, perm.end());
	for (int i = n - k; i < n;i++) {
		a[perm[i]] = multarr[i - (n - k)];
	}
	for(int i = 0; i < n; ++i)
	{
		assert((val_low <= a[i]) && (a[i]<= val_high));
		cout << a[i] << " ";
	}	
}
