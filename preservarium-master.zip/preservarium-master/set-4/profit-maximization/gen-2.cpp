#include<iostream>
#include "testlib.h"
#include <cassert>
using namespace std;

#define endl '\n'
void generate();
vector<long long> get_multiples(long long lim);
vector<long long> get_rand_perm(long long n);
vector<long long> gen_testcase(long long n, long long lim);
void print(vector<long long> v);
void solve();


int main(int argc, char* argv[]){
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";

	solve();
	return 0;
}

vector<long long> get_multiples(long long lim) {
	vector<long long> multiples;
	multiples.push_back(rnd.next(1LL, 10LL));

	while(true) {
		long long mult = rnd.next(1LL, 10LL);
		long long last = multiples[(int)multiples.size() - 1];
		last *= mult;
		if (last > lim) {
			break;
		}
		multiples.push_back(last);
	}
	return multiples;
}

vector<long long> get_rand_perm(long long n) {
	vector<long long> v;
	for(int i = 0; i < n; i++) {
		v.push_back(i);
	}

	long long lim = n;
	while(lim > 1) {
		long long ind = rnd.next(1LL, lim);
		swap(v[ind], v[lim - 1]);
		lim--;
	}
	return v;
}

vector<long long> gen_testcase(long long n, long long lim) {
	vector<long long> arr(n);
	vector<long long> rand_perm = get_rand_perm(n);

	long long ind = 0;
	while(ind < n) {
		vector<long long> multiples = get_multiples(lim);

		vector<long long> indices;
		for(int i = 0; i < (int)multiples.size() && ind < n; i++, ind++) {
			indices.push_back(rand_perm[ind]);
		}
		sort(indices.begin(), indices.end());

		for(int i = 0; i < (int)indices.size(); i++) {
			arr[indices[i]] = multiples[i];
		}
	}
	return arr;
}

void print(vector<long long> v) {
	cout << (int)v.size() << endl;
	for(int i = 0; i < (int)v.size(); i++) {
		cout << v[i] << " ";
	}
	cout << endl;
}

void solve() {
	auto v = gen_testcase(1000, 100000);
	print(v);
	return;
}
