#  Profit Maximization

---

# Intuition
This problem can be solved by Dynamic Programming. Let `dp[i]` denote the maximum profit gain for a sequence of villages ending at village `i`.
The recurrence for `dp[i]` is given as: `dp[i] = max(v[i], max(dp[pos[x]]+profit[i] for x in factors of profit[i]))`, where `pos[x]` denotes the position of last village (less than `i`) with profit `x`. For `N` upto `10^3`, the solution can be implemented in `O(n^2)` by iterating over all the indices less than `i`, and taking maximum of the above equation over all the indices `j` in which `profit[i]` is a multiple of `profit[j]`.

For the hard version (`N` upto `10^5`), we can optimize the above solution by precalculating all the factors of each element using Sieve of Eratosthenes. After each factor has been calculated, for calculation of `dp[i]`, we only iterate over the villages `j` that have `profit[j]` a factor of `profit[i]`. (Note: In case a factor `x` of `profit[i]` is present in `j1` and `j2` with `j1 < j2 < i`, it is sufficient to consider only `j2` for calculating the `dp[i]`, as `dp[j2] > dp[j1]`).


---

# Code
* [Setter's Solution](sol.cpp)

---
