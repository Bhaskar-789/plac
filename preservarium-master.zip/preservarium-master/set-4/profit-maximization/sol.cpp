#include<bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin>>n;
    vector<int>p(n);
    for(int i =0; i<n;i++)
    {
        cin>>p[i];
    }
    vector<int>dp(n,0);
    dp[0] = p[0];
    int ans =dp[0];
    for(int j =1;j<n;j++)
    {
        dp[j] =p[j];
        for(int i =0; i<j;i++)
        {
            if(p[i]!=0&&(p[j]%p[i])==0)
            {
                dp[j]=max(dp[j],dp[i]+p[j]);
            }
        }
        ans =max(ans,dp[j]);
    }
    cout<<ans<<"\n";
    return 0;
    
}