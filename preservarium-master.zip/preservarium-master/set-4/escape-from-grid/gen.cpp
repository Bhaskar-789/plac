#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int row_low = 1;
int row_high = 100;
int col_low = 1;
int col_high = 100;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();

int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
		row_high = 6;
		col_high = 6;
	}

	if(type == "extreme") {
		row_low = row_high;
		col_low = col_high/2;
	}

	generate();
	return 0;
}

void generate()
{
	int row = rnd.next(row_low, row_high);
	int col = rnd.next(col_low, col_high);

	vector<vector<int>> mat(row, vector<int>(col, 0));
	int thorns = rnd.next(0, (int)row*col);
	int cnt = 0;
	for(int i = 0; i < row; i++) {
		for(int j = 0; j < col; j++) {
			if(cnt < thorns) {
				int val = rnd.next(0, 1);
				if(val == 1) {
					cnt++;
				}
				mat[i][j] = val;
			}
			else {
				mat[i][j] = 0;
			}
		}
	}

	int row_ind = rnd.next(0, row - 1);
	int col_ind = rnd.next(0, col - 1);
	mat[row_ind][col_ind] = 2;

	cout << row << " " << col << endl;
	for(auto &row_vec : mat) {
		for(auto &ele : row_vec) {
			cout << ele << " ";
		}
		cout << endl;
	}
}
