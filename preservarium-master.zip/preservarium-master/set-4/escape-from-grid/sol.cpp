#include<bits/stdc++.h>
using namespace std;

int main()
{
    int n,m;
    cin>>n>>m;
    vector<vector<int>>grid(n,vector<int>(m));
    int sx,sy;
    for(int i =0; i<n;i++)
    {
        for(int j =0; j<m;j++)
        {
            cin>>grid[i][j];
            if(grid[i][j]==2)
            {
                sx=i;
                sy=j;
            }
        }
    }
    int ans =0;
    vector<vector<bool>>vstd(n,vector<bool>(m,false));
    queue<int>qx;
    queue<int>qy;
    qx.push(sx);
    qy.push(sy);
    vstd[sx][sy]=true;
    int f =0;
    while(!qx.empty())
    {
        int sz=qx.size();
        
        while(sz--)
        {
            int x=qx.front(),y=qy.front();
            qx.pop();
            qy.pop();
            if(x ==0||x ==n ||y==0||y==m)
            {
                f =1;
                break;
            }
            vector<int>dx ={0,0,-1,1};
            vector<int>dy ={1,-1,0,0};
            for(int l =0;l<4;l++)
            {
                if(x+dx[l]>=0&&x+dx[l]<n&&y+dy[l]>=0&&y+dy[l]<m)
                {
                    if(vstd[x+dx[l]][y+dy[l]]==false &&grid[x+dx[l]][y+dy[l]]==0)
                    {
                        vstd[x+dx[l]][y+dy[l]]=true;
                        qx.push(x+dx[l]);
                        qy.push(y+dy[l]);
                    }
                }
                
            }
        }
        if(f==1)break;
        ans++;
    }
    if(f==1)
    {
        cout<<ans<<'\n';
    }else
    {
        cout<<"-1\n";
    }
    return 0;
    
}