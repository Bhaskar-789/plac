#include <bits/stdc++.h>
using namespace std;

const int maxn = (int)1e5 + 5;
const int mod = 1e9 + 7;
vector<long long> fac;

inline long long mult(long long a, long long b) {
	return (a*b)%mod;
}

long long power(long long base, int exp) {
	if(exp == 0) {
		return 1;
	}

	auto half = power(base, exp/2);
	auto full = mult(half, half);

	if(exp%2 != 0) {
		full = mult(full, base);
	}

	return full;
}

void compute_factorials() {
	fac.resize(maxn + 1, 1);

	for(int num = 1; num < maxn; num++) {
		fac[num] = mult(num, fac[num - 1]);
	}
}

long long inverse(long long num) {
	return power(num, mod - 2);
}

long long binom(int n, int r) {
	assert(n >= r);
	auto numerator = fac[n];
	auto denom = mult(fac[r], fac[n - r]);
	return mult(numerator, inverse(denom));
}


long long arrange(map<char, int> &balls) {
	int total_count = 0;
	long long numerator, denom = 1;
	for(auto &ele : balls) {
		int cnt_now = ele.second;
		total_count += cnt_now;
		denom = mult(denom, fac[cnt_now]);
	}

	numerator = fac[total_count];
	return mult(numerator, inverse(denom));
}

long long solve(string str, string not_allowed_together) {
	set<char> restricted_set;
	for(auto &ele : not_allowed_together) {
		restricted_set.insert(ele);
	}

	map<char, int> white_balls, black_balls;
	int white_count = 0, black_count = 0;
	for(auto &ele : str) {
		if(restricted_set.count(ele)) {
			black_balls[ele]++;
			black_count++;
		} else {
			white_balls[ele]++;
			white_count++;
		}
	}

	auto arrange_white = arrange(white_balls);
	auto arrange_black = arrange(black_balls);

	int free_slots = white_count + 1;
	if(free_slots >= black_count) {
		auto pick_slots = binom(free_slots, black_count);
		return mult(mult(arrange_white, pick_slots), arrange_black);
	} else {
		return -1;
	}
}
	
int main() {
	compute_factorials();
	int t; cin >> t;
	for(int ii = 0; ii < t; ii++) {
		string str, not_allowed_together;
		cin >> str >> not_allowed_together;
		auto res = solve(str, not_allowed_together);
		cout << res << endl;
		cerr << res << endl;
	}
	return 0;
}
