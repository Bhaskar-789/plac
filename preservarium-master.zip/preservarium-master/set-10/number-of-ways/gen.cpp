#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int t_low = 1;
int t_high = 5;
int n_low = 2;
int n_high = 1e5;
int dist_size_low = 2;
int dist_size_high = 26;
int alpha_size_low = 2;
int alpha_size_high = 26;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();

int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
		t_high = 2;
		n_high = 10;
		dist_size_high = 7;
	}

	if(type == "extreme") {
		t_low = t_high;
		n_low = n_high;
	}

	generate();
	return 0;
}

void generate()
{
	int t = rnd.next(t_low, t_high);
	cout << t << endl;
	for(int ii = 0; ii < t; ii++) {
		int n = rnd.next(n_low, n_high);
		string str = "";
		int alpha_size = rnd.next(alpha_size_low, alpha_size_high);
		for(int i = 0; i < n; i++) {
			str += rnd.next('a', 'a' + alpha_size - 1);
		}
		// Let's change the alphabet size
		alpha_size = rnd.next(alpha_size_low, alpha_size_high);
		set<char> dist_set;
		int dist_size = rnd.next(dist_size_low, min(dist_size_high, alpha_size));
		while((int)dist_set.size() != dist_size) {
			dist_set.insert(rnd.next('a', 'a' + alpha_size - 1));
		}

		cout << str << endl;
		for(auto &ele : dist_set) {
			cout << ele;
		}
		cout << endl;
	}
}
