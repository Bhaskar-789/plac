/******************READ-ONLY PART BEGINS*****************/
#include <bits/stdc++.h>
using namespace std;
/*******************READ-ONLY PART ENDS******************/

long long get_sum(vector<long long> &pref, int i, int j) {
	return pref[j] - (i ? pref[i - 1] : 0);
}

long long solve(vector<long long> &a) {
	int n = a.size();
	vector<long long> pref(n);
	pref[0] = a[0];
	for(int i = 1; i < n; i++) {
		pref[i] += pref[i - 1] + a[i];
	}

	// dp[i][j] is the maximum profit that the players who goes first can
	// take when the game starts with a[i...j]
	vector<vector<long long>> dp(n, vector<long long>(n, 0));

	// Since it is subarray, j >= i
	for(int i = n - 1; i >= 0; i--) {
		for(int j = i; j < n; j++) {
			int len = j - i + 1;
			if(len == 1) {
				dp[i][j] = a[i];
				continue;
			}
			auto take_from_left = get_sum(pref, i, j) - dp[i + 1][j];
			auto take_from_right = get_sum(pref, i, j) - dp[i][j - 1];
			auto best_move = max(take_from_left, take_from_right);
			dp[i][j] = best_move;
		}
	}

	// Make sure to return difference.
	auto score_first = dp[0][n - 1];
	auto score_second = pref.back() - score_first;
	return score_first - score_second;
}


int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);

	int n; cin >> n;
	vector<long long> a(n);
	for(auto &ele : a) {
		cin >> ele;
	}
	auto res = solve(a);
	cout << res << endl;

	return 0;
}
