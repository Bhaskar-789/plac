// You should print (score_1 - score_2) and not abs(score_1 - score_2)
#include <bits/stdc++.h>
using namespace std;

long long get_sum(vector<long long> &pref, int left, int right) {
	return pref[right] - (left > 0 ? pref[left - 1] : 0);
}

long long solve(vector<int> a) {
	int n = a.size();
	vector<long long> pref(n, 0);
	pref[0] = a[0];
	for(int i = 1; i < n; i++) {
		pref[i] = pref[i - 1] + a[i];
	}

	// dp[i][j] is the maximum score that the player with next move
	// would get when the game has elements a[i...j]
	vector<vector<long long>> dp(n, vector<long long>(n, 0));
	for(int i = n - 1; i >= 0; i--) {
		for(int j = i; j < n; j++) {
			int segment_length = j - i + 1;
			long long segment_sum = get_sum(pref, i, j);

			if(segment_length == 1) {
				dp[i][j] = segment_sum;
				continue;
			}

			auto take_left = segment_sum - dp[i + 1][j];
			auto take_right = segment_sum - dp[i][j - 1];
			auto best_take = max(take_left, take_right);
			dp[i][j] = best_take;
		}
	}

	long long total_sum = pref.back();
	long long first_player = dp[0][n - 1];
	long long second_player = total_sum - first_player;
	return (first_player - second_player);
}

int main() {
	int n; cin >> n;
	vector<int> a(n);
	for(auto &ele : a) {
		cin >> ele;
	}

	auto res = solve(a);
	cout << res << endl;

	return 0;
}
