# Simple Game

---

# Intuition
This is a textbook DP problem.

> Define `dp[i][j]` to be the maximum points that the player with the first move can collect, when the game starts with only the subarray `[i...j]`. 

**Note**: Player with the first move should not be confused with Player 1.

For the transitions, let us explore the possibilities. The player with the first move can either pick an element from the left or from the right.

Suppose he picks `arr[i]`, then the remaining array elements are `[i + 1, ....j]`, and the control is passed over to the other player. The other player would try to maximize his points with what he has been provided. By definition, he can get a benefit of `dp[i + 1][j]`, because in the reduced game, he is the one who would be making the first move. The amount left for the original player would then be
```py
take_left = sum(arr[i...j]) - dp[i + 1][j]
```

Simlary, suppose the player going first decides to pick the element from the back. Then, the control would pass over to the other player, and he would optimize his possibilities via `dp[i][j - 1]`, leaving the original player with:
```py
take_right = sum(arr[i...j]) - dp[i][j - 1]
```

No matter what the player with the first move does, he can only make a profit of 

```py
max(take_left, take_right)
```

This gives us the DP transitions. To determine the filling order, notice that `dp[i][j]` needs the help of `dp[i + 1][j]`. This means, that `i` should be iterated in decreasing order. `dp[i][j]` would also need the help of `dp[i][j - 1]`, implying that `j` should be iterated in increasing order.

Our DP definition also implies that `[i...j]` should be a subarray. Hence, `j >= i`.

Finally, for the base case, notice that as long as the subarray has length `>= 2`, neither `dp[i + 1[j]` nor `dp[i][j - 1]` goes out of bound. Hence, the base case only happens when the subarray is of length exactly equal to 1. In that case, `dp[i][j] = a[i]`.

For the time complexity, there are `N*N` states. If we can perform the transitions in `O(1)`, we can get a time complexity of `O(N^2)`. To do transitions in `O(1)`, we need to quickly compute the sum of a subarray in `O(1)`. This can be done either via **Prefix Sum** technique or a simple DP on the subarray sum to precompute all values.

---

# Pseudocode
```py
# Subarray sum in O(1)
def get_sum(pref, left, right):
    return pref[right] - (left ? pref[left - 1] : 0)

def solve(arr):
    # Conver to prefix array
    pref = arr
    for i in [1, n):
        pref[i] += pref[i - 1]
    
    # Fill DP table
    for i = n - 1 downto 0:
        for j in [i, n):
            len = j - i + 1
            segment_sum = get_sum(pref, i, j)
            if len is 1:
                dp[i][j] = segment_sum
                continue
            
            take_left = segment_sum - dp[i + 1][j]
            take_right = segment_sum - dp[i][j - 1]
            dp[i][j] = max(take_left, take_right)

    # Problem specific calculations
    total_sum = pref.back
    first_player = dp[0][n - 1]
    second_player = total_sum - first_player
    print(first_player - second_player)
```

---

# Code
* [Setter/Editorialist's Solution](sol.cpp)

---
