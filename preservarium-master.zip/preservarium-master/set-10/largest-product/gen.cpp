#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int t_low = 1;
int t_high = 5;
int n_low = 1;
int n_high = (int)1e5;
int val_low = 1;
int val_high = (int)1e6;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();

int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
		t_low = t_high;
		n_high = 9;
		val_high = 9;
	}

	if(type == "extreme") {
		t_low = t_high;
		n_low = n_high;
	}

	generate();
	return 0;
}

void generate()
{
	int t = rnd.next(t_low, t_high);
	cout << t << endl;
	for(int ii = 0; ii < t; ii++) {
		int n = rnd.next(n_low, n_high);
		cout << n << endl;

		vector<int> a(n), b(n);
		for(int i = 0; i < n; i++) {
			a[i] = rnd.next(val_low, val_high);
			b[i] = rnd.next(val_low, val_high);
			if(rnd.next(0, 1)) {
				a[i] = 1;
			}
			if(rnd.next(0, 1)) {
				b[i] = 1;
			}
		}
		for(auto &ele : a) {
			cout << ele << " ";
		}
		cout << endl;
		for(auto &ele : b) {
			cout << ele << " ";
		}
		cout << endl;
	}
}
