#include <bits/stdc++.h>
using namespace std;

const int mod = 1e9 + 7;

int solve(vector<int> a, vector<int> b) {
	priority_queue<int, vector<int>, greater<int>> mutable_heap, buffer_heap;
	for(auto &ele : a) {
		mutable_heap.push(ele);
	}
	for(auto &ele : b) {
		buffer_heap.push(ele);
	}

	// At each stage, the size of buffer heap decreases by 1
	// The size of mutable_heap always remains n
	while(not buffer_heap.empty()) {
		if(mutable_heap.top() == 1 or buffer_heap.top() == 1) {
			auto mutable_min = mutable_heap.top();
			auto buffer_min = buffer_heap.top();

			mutable_heap.pop();
			buffer_heap.pop();

			mutable_heap.push(mutable_min + buffer_min);
		} else {
			// The minimum value is > 1.
			// So, we won't use any plus operations now.
			break;
		}
	}


	long long res = 1;
	while(not mutable_heap.empty()) {
		res *= mutable_heap.top();
		res %= mod;
		mutable_heap.pop();
	}
	while(not buffer_heap.empty()) {
		res *= buffer_heap.top();
		res %= mod;
		buffer_heap.pop();
	}

	return res;
}

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);

	int t; cin >> t;
	for(int ii = 0; ii < t; ii++) {
		int n; cin >> n;
		vector<int> a(n), b(n);
		for(auto &ele : a) {
			cin >> ele;
		}
		for(auto &ele : b) {
			cin >> ele;
		}
		auto res = solve(a, b);
		cout << res << endl;
	}
	return 0;
}
