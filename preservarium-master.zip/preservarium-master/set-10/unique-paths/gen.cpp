#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int t_low = 1;
int t_high = 10;
int dim_low = 1;
int dim_high = 100;
int val_low = 1;
int val_high = 30;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();

int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
		t_high = 2;
		val_high = 9;
		dim_high = 7;
	}

	if(type == "extreme") {
		t_low = t_high;
		dim_high = 90;
	}

	generate();
	return 0;
}

void generate()
{
	int t = rnd.next(t_low, t_high);
	cout << t << endl;
	for(int ii = 0; ii < t; ii++) {
		int row = rnd.next(dim_low, dim_high);
		int col = rnd.next(dim_low, dim_high);

		cout << row << " " << col << endl;
		for(int i = 0; i < row; i++) {
			for(int j = 0; j < col; j++) {
				cout << rnd.next(val_low, val_high);
				cout << " ";
			}
			cout << endl;
		}
	}
}
