#include <bits/stdc++.h>
using namespace std;

const int max_val = 30;
const int num_primes = 10;
const int full_mask = (1 << num_primes) - 1;
const int mod = 1e9 + 7;

void add(int &a, int b) {
	a = (a + b) % mod;
}

vector<int> precompute_masks() {
	vector<int> prime_list = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29};
	vector<int> create_mask(max_val + 1, 0);

	// Use a copy for divison
	for(int num = 1; num <= max_val; num++) {
		int mask = 0, num_copy = num;
		for(int i = 0; i < num_primes; i++) {
			int prime_now = prime_list[i];
			int parity = 0;
			while(num_copy % prime_now == 0) {
				num_copy /= prime_now;
				parity ^= 1;
			}
			if(parity == 1) {
				mask = mask | (1 << i);
			}
		}
		create_mask[num] = mask;
	}
	return create_mask;
}

int solve(vector<vector<int>> mat) {
	int row = mat.size(), col = mat[0].size();

	vector<vector<vector<int>>> dp(row);
	for(auto &vec_2d : dp) {
		vec_2d.resize(col, vector<int>(full_mask + 1, 0));
	}

	vector<int> create_mask = precompute_masks();
	int exit_mask = create_mask[mat[row - 1][col - 1]];
	dp[row - 1][col - 1][exit_mask] = 1;

	for(int i = row - 1; i >= 0; i--) {
		for(int j = col - 1; j >= 0; j--) {
			int current_mask = create_mask[mat[i][j]];
			for(int visited_mask = 0; visited_mask <= full_mask; visited_mask++) {
				int combined_mask = current_mask xor visited_mask;
				if(i + 1 < row) {
					add(dp[i][j][combined_mask], dp[i + 1][j][visited_mask]);
				}
				if(j + 1 < col) {
					add(dp[i][j][combined_mask], dp[i][j + 1][visited_mask]);
				}
			}
		}
	}
	return dp[0][0][0];
}

int main() {
	int t; cin >> t;
	for(int ii = 0; ii < t; ii++) {
		int row, col;
		cin >> row >> col;
		vector<vector<int>> mat(row, vector<int>(col, 0));
		for(auto &row_vec : mat) {
			for(auto &ele : row_vec) {
				cin >> ele;
			}
		}
		
		auto res = solve(mat);
		cout << res << endl;
	}
	return 0;
}
