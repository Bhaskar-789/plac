#include <bits/stdc++.h>
using namespace std;

const int mod = 1e9 + 9;
const int pval = 31;

inline long long mult(long long a, long long b) {
	return (a*b)%mod;
}

long long power(long long base, long long exp) {
	if(exp == 0) {
		return 1;
	}

	auto half = power(base, exp/2);
	auto full = mult(half, half);

	if(exp%2 != 0) {
		full = mult(full, base);
	}
	return full;
}

vector<long long> compute_prefix_hash(string &str) {
	int n = str.length();
	vector<long long> prefix_hash(n, 0);
	
	long long pval_power = 1, prev_hash = 0;
	for(int i = 0; i < n; i++) {
		prefix_hash[i] = (prev_hash + mult(str[i] - 'a' + 1, pval_power))%mod;
		prev_hash = prefix_hash[i];

		pval_power = mult(pval_power, pval);
	}
	return prefix_hash;
}

long long substring_hash(vector<long long> &prefix_hash, int i, int j) {
	// Difference can become negative
	auto diff = (prefix_hash[j]  - (i > 0 ? prefix_hash[i - 1] : 0))%mod;
	diff += mod; diff %= mod;

	auto factor = power(pval, i);
	auto inv = power(factor, mod - 2);

	return mult(diff, inv);
}

int solve(string str, int shifting_factor) {
	int n = str.length();
	auto prefix_hash = compute_prefix_hash(str);

	int count = 1;
	for(int i = shifting_factor; i < n; i += shifting_factor) {
		auto suff_hash = substring_hash(prefix_hash, i, n - 1);
		int suff_len = n - i;
		assert(suff_len >= 1);

		auto pref_hash = prefix_hash[suff_len - 1];
		if (pref_hash == suff_hash) {
			return count;
		}
		count++;
	}
	return count;
}

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);

	int t; cin >> t;
	for(int ii = 0; ii < t; ii++) {
		int n, k; string str;
		cin >> n >> k >> str;
		auto res = solve(str, k);
		cout << res << "\n";
	}
	return 0;
}
