#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int t_low = 1;
int t_high = 10;
int n_low = 1;
int n_high = 1e5;
int alpha_size_low = 1;
int alpha_size_high = 26;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();
bool tle_type;

int main(int argc, char* argv[])
{
	tle_type = false;
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
		t_high = 2;
		n_high = 20;
		alpha_size_high = 4;
	}

	if(type == "mixed") {
		t_low = t_high;
		alpha_size_high = 2;
	}

	if(type == "extreme") {
		t_low = t_high;
		n_low = n_high;
		alpha_size_high = 3;
	}

	if(type == "purely_random") {
		t_low = t_high;
		n_low = n_high;
		alpha_size_high = 26;
	}

	if(type == "tle") {
		t_low = t_high;
		n_low = n_high;
		alpha_size_high = 26;
		tle_type = true;
	}

	generate();
	return 0;
}

void generate()
{
	int t = rnd.next(t_low, t_high);
	cout << t << endl;
	for(int ii = 0; ii < t; ii++) {
		int alpha_size = rnd.next(alpha_size_low, alpha_size_high);
		int n = rnd.next(n_low, n_high);
		int k = rnd.next(1, max(1, n/5));

		if(n <= 20) {
			k = rnd.next(1, n);
		}

		if(tle_type) {
			k = 1;
		}

		string str = "";
		for(int i = 0; i < n; i++) {
			str += 'a' + rnd.next(0, alpha_size - 1);
		}

		cout << n << " " << k << endl;
		cout << str << endl;
	}
}
