#include<bits/stdc++.h>
#define ll long long
using namespace std ;
 
ll z =  1000000007 ;
ll inf = 100000000000000000 ;
ll gcd(ll a , ll b){ if(b > a) return gcd(b , a) ; if(b == 0) return a ; return gcd(b , a%b) ;}
ll power(ll a ,ll b , ll p){if(b == 0) return 1 ; ll c = power(a , b/2 , p) ; if(b%2 == 0) return ((c*c)%p) ; else return ((((c*c)%p)*a)%p) ;}
ll inverse(ll a ,ll n){return power(a , n-2 , n) ;}
ll max(ll a , ll b){if(a > b) return a ; return b ;}
ll min(ll a , ll b){if(a < b) return a ; return b ;}
#define rep(i , n) for(int i = 0 ; i < n ; i++)
 
vector<ll> prefix_function(string& s) {
    ll n = s.size() ;
    vector<ll> pre(n);
 
    for (int i = 1; i < n; i++) {
        int j = pre[i-1];
        while (j > 0 && s[i] != s[j])
            j = pre[j-1];
        if (s[i] == s[j])
            j++;
        pre[i] = j;
    }
    return pre;
}
 
void solve()
{
    ll n , k ;
    cin >> n >> k ;
    string str ;
    cin >> str ;
    vector<ll> pre = prefix_function(str) ;
    ll len = pre[n-1] ;
    while(len > 0 && (n - len)%k != 0)
        len = pre[len-1] ;
    //cout << "len = " << len << endl ;
    len = (n - len) ;
    //cout << "len = " << len << endl ;
    ll ans = (len + k - 1)/k ;
    cout << ans << endl ;
    return ;    
 
}
 
 
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    #ifndef ONLINE_JUDGE
    freopen("inputf.txt" , "r" , stdin) ;
    freopen("outputf.txt" , "w" , stdout) ;
    freopen("error.txt" , "w" , stderr) ;
    #endif
    
    ll t ;
    cin >> t ;
    //t = 1 ;
 
    while(t--)
    {
        solve() ;
    }
 
    return 0;
}
