# String Shifting

---

# Intuition

We are given a string of `N` characters. Let’s call this original string `str`. 
Each second, the string shifts by `K` characters to the left, and `K new characters` are added at the end of the string.
Suppose the answer is `A`. Let’s see what will happen at the end of A<sup>th</sup> second. For now, assume that `A*K <= N` for the following discussion. 

After A<sup>th</sup> second, we will have `A*K new characters` at the end as the suffix, and `N - A*K = M` old characters in the beginning as the prefix. Let’s denote this new string as `new_str`.


We know that `new_str = str`. This means that `new_str[1...M] = str[1...M]`, where `str[i...j]` denotes the substring starting at index i and ending at index j. 
We will prove that for the string str, **the prefix of length M is equal to the suffix of length M**. 

```py
new_str[1…M] = str[A*K + 1 … A*K + M] = str[A*K + 1 … N]
So, str[1…M] = str[A*k+1 … N].
```

**Updated Problem:**  
Find the largest `M` such that `N - M` is divisible by `K`, and the property that the prefix of length M is equal to the suffix of length M holds. 
Also, if no such prefix exists, than we can have `M = 0`, and basically replace all the characters in `ceil(N/K)` seconds, and this covers our original assumption of `A*K <= N`.

The Updated Problem can be efficiently solved using either **KMP Algorithm**, or **String Hashing**.

**Using KMP Algorithm:**  
We will require a good understanding of **Prefix Functions** to solve this problem efficiently. The following [link](https://cp-algorithms.com/string/prefix-function.html) provides a very good explanation of the same. 

Now, we can start with the longest prefix which is also a suffix. Let's say it’s length is `len`. 
If `N - len` is divisible by `K`, then we are done, otherwise we will look at the next shorter prefix which is also a suffix, and continue the process.
How to find the next shorter prefix? This is exactly what is explained in the **Second Optimization** in the attached link. 

Finally, the problem is solved in `O(N)` time and `O(N)` space.


---

# Pseudocode

```py
def solve(): 


pi[n] <- prefix_function(str) # Calculate the prefix function
len <- pi[n-1]  # length of the largest prefix which is also a suffix

# iterate until all the properties are satisfied
while(len > 0 and (n - len) % K is not 0) do
    len = pre[len-1] ; # length of next shorter prefix which is also a suffix

m <- n - len
ans <- ceil(m/k)

return ans
```

---

# Code
* [Setter's Solution](sol.cpp)

---
