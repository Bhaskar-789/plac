#  Alphabet Ordering

---

# Intuition
A greedy strategy works here, i.e, if the current substring is a non-increasing (or non-decreasing) and it is possible to include the current character in the current substring, it should be included. Note that going this way, the number of substrings obtained is precisely equal to 1+total number of local maximas and minimas in the string. 

Time complexity: `O(n)`.

---

#PseudoCode

```py
ans=1  # Monotone subsequence
n = s.length()
for i in range(1,n):
	ans+= (s[i] > s[i-1] && s[i] > s[i+1]) || (s[i] < s[i-1] && s[i] < s[i+1])
```

---

# Code
* [Setter's Solution](sol.cpp)

---
