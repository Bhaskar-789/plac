#include<bits/stdc++.h>
using namespace std;

#define A(x) (x).begin(),(x).end()
#define sz(x) ((int)(x).size())
#define UNI(x) sort(A(x)); (x).erase(unique(A(x)),(x).end())
using i64 = long long;
void _read();

// Sequence is monotone

int main () { _read(); 

      string s;
      cin >> s;
      int n = sz(s);
      int ans = 1;
      for(int i = 1; i + 1 < n; ++i) {
            bool maxima = (s[i] > s[i - 1]) && (s[i] > s[i + 1]);
            bool minima = (s[i] < s[i - 1]) && (s[i] < s[i + 1]);
            ans += (maxima || minima);
      }
      cout << ans << '\n';
      return 0;
};

void _read() {
      ios_base :: sync_with_stdio(false);
      cin.tie(NULL);
      #ifdef LOCAL
      freopen("input.txt","r",stdin);
      #endif
}
