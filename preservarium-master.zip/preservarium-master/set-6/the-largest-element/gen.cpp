#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int t_low = 1;
int t_high = 100;
int n_low = 1;
int n_high = 1e5;
int val_low = 1;
// deliberately keeping it 10^5 instead of 10^6
int val_high = (int)1e5;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();

int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
		t_high = 2;
		n_high = 15;
		val_high = 15;
	}

	// No need to keep high ranges as we are dealing with gcd
	if(type == "mixed") {
		val_high = 100;
	}

	if(type == "extreme") {
		t_low = t_high;
		n_low = n_high;
	}

	generate();
	return 0;
}

void generate()
{
	int t = rnd.next(t_low, t_high);
	cout << t << endl;
	
	for(int ii = 0; ii < t; ii++) {
		int n = rnd.next(n_low, n_high);
		vector<int> a(n);
		for(auto &ele : a) {
			ele = rnd.next(val_low, val_high);
		}
		// Now multiply all by a common element to enable gcd > 1
		if(rnd.next(0, 1)) {
			int pick = rnd.next(2, 10);
			for(auto &ele : a) {
				ele *= pick;
			}
		}
		int k = rnd.next(1, n);

		cout << n << endl;
		for(auto &ele : a) {
			cout << ele << " ";
		}
		cout << endl;
		cout << k << endl;
	}
}
