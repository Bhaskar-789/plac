#include<bits/stdc++.h>
using namespace std;

#define ll long long

void solve(){
    ll n, k;
    cin >> n;
    vector<ll> v(n);
    ll g = 0;
    for(auto &x: v){
        cin >> x;
        g = __gcd(g, x);
    }
    cin >> k;
    ll mn = *min_element(v.begin(), v.end());
    ll mx = *max_element(v.begin(), v.end());
    mn = min(mn, g);
    ll tott = (mx - mn)/g + 1;
    if(k > tott){
        cout << -1 << "\n";
    } else {
        cout << mx - (k - 1) * g << "\n";
    }
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    
    ll TC;
    cin >> TC;

    for(ll TT = 0; TT < TC; TT++){
        solve();
    } 
}

