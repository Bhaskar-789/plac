#  Highly Profitable Months 

---

# Intuition
This problem can be solved by considering each index as a possible middle element of the triplet. If `i` is the middle element of the triplet, then we need a `j < i` such that `arr[j]` is the maximum element less than or equal to `arr[i]` and a `k > i` with maximum element greater than or equal to `arr[i]`. `j` can be obtained by maintaining a `set` (containing pair of `arr[i] and i`) or a `map`(such that `mp[arr[i]] = i`, where `i` is the lowest index corresponding to `arr[i]`) and by using `upper_bound` function in STL, while `k` can be obtained by maintaining a max-suffix array, which also contains the lowest index corresponding the maximum of the suffix.  

Time complexity : `O(n log n)`.

---

# Code
* [Setter's Solution](sol.cpp)

---
