#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int t_low = 1;
int t_high = 10;
int n_low = 1;
int n_high = 1e5;
int val_low = -1e9;
int val_high = 1e9;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();
bool rev_sorted, sorted;

int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	rev_sorted = false;
	sorted = false;
	
	if(type == "small") {
		t_high = 2;
		n_high = 15;
		val_low = -10;
		val_high = 10;
	}

	if(type == "mixed") {
		// keep values in small range to enable same sum triplets
		// Let's keep values even smaller to enable same sum triplets,
		// because the correctness of the algorithm isn't influenced much
		val_low = -10;
		val_high = 10;
	}

	if(type == "extreme") {
		t_low = t_high;
		n_low = n_high;
	}

	if(type == "rev_sorted") {
		rev_sorted = true;
	}

	if(type == "sorted") {
		sorted = true;
	}

	if(type == "purely_random") {
	}

	if(type == "overflow") {
		t_low = t_high;
		n_low = n_high;
		val_low = val_high;
	}

	generate();
	return 0;
}

void generate()
{
	int t = rnd.next(t_low, t_high);
	cout << t << endl;
	for(int ii = 0; ii < t; ii++) {
		int n = rnd.next(n_low, n_high);
		vector<int> a(n);
		for(auto &ele : a) {
			ele = rnd.next(val_low, val_high);
		}

		if(rev_sorted) {
			sort(a.begin(), a.end(), greater<int>());
		}
		if(sorted) {
			sort(a.begin(), a.end());
		}

		cout << n << endl;
		for(auto &ele : a) {
			cout << ele << " ";
		}
		cout << endl;
	}
}
