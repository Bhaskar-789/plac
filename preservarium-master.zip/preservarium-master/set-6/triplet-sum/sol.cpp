#include<bits/stdc++.h>
using namespace std;

#define ll long long
#define pll pair<ll, ll>

void solve(){
    ll n;
    cin >> n;
    vector<ll> v(n);
    ll i = 0;
    map<ll, ll> fst;
    for(auto &x: v){
        cin >> x;
        if(!fst.count(x)){
            fst[x] = i;
        }
        i++;
    }
    
    vector<pll> sufmax(n);
    sufmax[n-1] = make_pair(v[n-1], n-1);
    for(ll i = n - 2; i >= 0; i--){
        if(v[i] >= sufmax[i+1].first){
            sufmax[i].first = v[i];
            sufmax[i].second = i;
        } else {
            sufmax[i] = sufmax[i + 1];
        }
    }
    vector<ll> ans(3);
    ll mxs = LLONG_MIN;
    set<ll> seen;
    seen.insert(v[0]);
    for(ll i = 1; i < n-1; i++){
        auto it = seen.upper_bound(v[i]);
        if(it != seen.begin() && sufmax[i + 1].first >= v[i]){
            --it;
            ll sum = sufmax[i+1].first + v[i] + *it;
            vector<ll> tmp = {fst[*it], i, sufmax[i+1].second};
            
            if(sum > mxs){
                mxs = sum;
                ans = tmp;
            } else if(sum == mxs){
                if(tmp[0] < ans[0]){
                    ans = tmp;
                } else if(tmp[0] == ans[0] && tmp[1] < ans[1]){
                    ans = tmp;
                } else if(tmp[0] == ans[0] && tmp[1] == ans[1] && tmp[2] < ans[2]){
                    ans = tmp;
                }
            }
        }
        seen.insert(v[i]);
    }
    if(mxs == LLONG_MIN){
        cout << -1 << "\n";
    } else {
        cout << ans[0]+1 << " " << ans[1]+1 << " " << ans[2]+1 << "\n";
    }
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    
    ll TC;
    cin >> TC;

    for(ll TT = 0; TT < TC; TT++){
        solve();
    } 
}

