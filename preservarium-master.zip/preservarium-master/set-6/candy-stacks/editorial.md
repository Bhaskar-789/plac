#  Candy Stacks

---

# Intuition
Note that we can only increase the number of candies in a stack. So if we sort the array, then for the answer to be `arr[i]`, only stacks with candies less than `i` need to be considered. Moreover, it can be easily seen that to maximize the number stacks having same value as `arr[i]`, it is better to first make stacks with index closer to `i`, as they require less candies to be added to become equal to `arr[i]`. 
So for each index `i`, there is a leftmost index `j` such that each stack in `[j,i]` can be made equal to `arr[i]` using atmost `K` candies. This index `j` can be binary searched for each index `i` in `O(log n)`, as we need the leftmost `j` for which `v[i] * (i-j+1) - (v[j]+v[j+1]+...+v[i]) <= K`.
The final answer is obtained by taking maximum value of `i-j+1`, and if there are multiple `i`for which this quantity is same, we take the earliest `i` as it has the lowest number of candies in each stack.

---

# Code
* [Setter's Solution](sol.cpp)

---
