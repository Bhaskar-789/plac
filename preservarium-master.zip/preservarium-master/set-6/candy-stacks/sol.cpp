#include<bits/stdc++.h>
using namespace std;

#define ll long long

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    
    ll n, k;
    cin >> n >> k;
    vector<ll> v(n);

    for(ll &x: v){
        cin >> x;
    }

    sort(v.begin(), v.end());

    vector<ll> pref(n);
    pref[0] = v[0];
    for(ll i = 1; i < n; i++){
        pref[i] += pref[i-1] + v[i];
    }

    ll mxs = -1, candy = -1;
    for(ll i = 0; i < n; i++){
        ll mini = i?pref[i-1]:0; //starting of the stacks: i
        ll j = i;
        ll l = i, r = n-1;
        while(l <= r){ //binary search for the last stack: j
            ll mid = l + (r - l) / 2;
            ll have = pref[mid] - mini;
            ll need = v[mid] * (mid - i + 1) - have;
            if(need <= k){
                l = mid + 1;
                j = mid;
            } else {
                r = mid - 1;
            }
        }
        if(j - i + 1 > mxs){
            mxs = j-i+1; // number of stacks = j - i + 1
            candy = v[j];
        }
    }
    cout << mxs << " " << candy;
}