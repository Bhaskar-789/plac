#include <iostream>
#include <cassert>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int n_low = 1;
int n_high = 1e5;
int k_low = 1;
int k_high = 1e8;
int val_low = 1;
int val_high = 1e6;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();
void generate_special(int value_of_k);

int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
		n_high = 10;
		k_high = 20;
		val_high = 9;
	}

	if(type == "extreme") {
		n_low = n_high;
		k_low = 1e5;
		val_low = 1e5;
	}

	if(type == "corner_1") {
		n_high = 50;
		val_high = 10;
		k_high = 5;
	}

	if(type == "corner_2") {
		n_low = n_high;
		val_high = 100;
		k_high = 200;
	}

	if(type == "corner_special") {
		assert(argc > 2);
		int value_of_k = atoi(argv[3]);
		generate_special(value_of_k);
		return 0;
	}

	generate();
	return 0;
}

void generate()
{
	int n = rnd.next(n_low, n_high);
	int k = rnd.next(k_low, k_high);
	vector<int> a(n);
	for(auto &ele : a) {
		ele = rnd.next(val_low, val_high);
	}

	cout << n << " " << k << endl;
	for(auto &ele : a) {
		cout << ele << " ";
	}
	cout << endl;
}

void generate_special(int value_of_k) {
	vector<int> a = {5, 2, 1, 3, 2, 5, 3, 5, 2, 5};
	cout << (int)a.size() << " " << value_of_k << endl;
	for(auto &ele : a) {
		cout << ele << " ";
	}
	cout << endl;
}



