#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int n_low = 1;
int n_high = 4*(int)1e5;
int val_low = 1;
int val_high = 1e9;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();

int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
		n_high = 10;
		val_high = 9;
	}

	if(type == "extreme") {
		n_low = n_high;
		// no need to limit val
	}

	generate();
	return 0;
}

void generate()
{
	int n = rnd.next(n_low, n_high);
	vector<int> a(n);
	for(auto &ele : a) {
		ele = rnd.next(val_low, val_high);
	}

	int x = rnd.next(1, n);
	int y = rnd.next(1, n);
	int z = rnd.next(x, n);
	int t = rnd.next(y, n);

	cout << n << " " << x << " " << y << " " << z << " " << t << endl;
	for(auto &ele : a) {
		cout << ele << " ";
	}
	cout << endl;
}
