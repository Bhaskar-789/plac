#include<bits/stdc++.h>
using namespace std;

#define ll long long

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    
    ll n, x, y, z, t;
    cin >> n >> x >> y >> z >> t;
    vector<ll> v(n);
    for(auto &a: v){
        cin >> a;
    }

    ll a = 0, b = 0;
    for(ll i = x - 1; i < z; i++){
        a ^= v[i];
    }   
    for(ll i = y - 1; i < t; i++){
        b ^= v[i];
    }
    cout << (a & b);
}

