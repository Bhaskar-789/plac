# Super Matrix

---

# Intuition

This problem requires a simple application of the fact that bitwise AND is distributive over XOR. Note that we need to calculate `(A_x & A_y) ^ (A_x & A_{y+1}) ^ ... (A_x & A_t) ^ (A_{x+1} & A_y) ^ (A_{x+1} & A_{y+1})...`, which is equal to `(A_x & (A_y ^ A_{y+1} ^A_{y+2}..)) ^ (A_{x+1} & (A_y ^ A_{y+1} ^A_{y+2}..)) ^ ...   = (A_x ^ A_{x+1} ^ A_{x+2} ...A_z) & (A_y ^ A_{y+1} ^A_{y+2}..A_t)`. This term can be easily calculated in linear time.

---



# Code
* [Editorialist/Setter's Solution](sol.cpp)

---
