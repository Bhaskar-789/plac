/******************READ-ONLY PART BEGINS*****************/
#include <bits/stdc++.h>
using namespace std;
/*******************READ-ONLY PART ENDS******************/

int solve(string &str) {
	string concat = str + str;
	int n = str.length();

	int overall_cost = 1e9;

	// Construct 2 different alternative 
	string target_a, target_b;
	for(int i = 0; i < n; i++) {
		target_a += (i%2 ? 'w' : 'b');
		target_b += (i%2 ? 'b' : 'w');
	}
	vector<string> collection = {target_a, target_b};
	int match = 0, mismatch = 0;
	for(string target : collection) {
		int match = 0, mismatch = 0;
		for(int i = 0; i < n; i++) {
			target[i] == concat[i] ? match++ : mismatch++;
		}
		overall_cost = min(overall_cost, mismatch);

		// Now, for n - 1 times, remove the oldest and add newest
		for(int i = n; i < 2*n - 1; i++) {
			// Remove the oldest element
			// Typo: (i - n), and not (n - i). Cost me a WA.
			int old = i - n;
			// Remove their contribution
			// Comparison would always happen with the first element?
			concat[old] == target[0] ? match-- : mismatch--;

			// Invert match and mismatch
			swap(match, mismatch);
			

			// Add the contribution of the incoming element.
			// Incoming element is always the last element of target?
			concat[i] == target[n - 1] ? match++ : mismatch++;
			overall_cost = min(overall_cost, mismatch);
		}
	}

	return overall_cost;
}

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);

	int t; cin >> t;
	for(int zz = 0; zz < t; zz++) {
		string str; cin >> str;
		auto res = solve(str);
		cout << res << endl;
	}
	return 0;
}
