#include<bits/stdc++.h>
using namespace std;

#define ll long long

void solve() { 
    string s;
    cin >> s;

    ll n = s.length();

    ll dpp[n][2], dps[n][2];
    dpp[0][0] = (s[0] == 'w')?0:1;
    dpp[0][1] = dpp[0][0] ^ 1;
    dps[n-1][0] = (s[n-1] == 'w')?0:1;
    dps[n-1][1] = dps[n-1][0] ^ 1;

    string wb = "wb";

    for(ll i = 1; i < n; i++){
        for(ll j = 0; j < 2; j++){
            char req = wb[j^(i&1)];
            dpp[i][j] = dpp[i-1][j] + (req != s[i]);
        }
    }

    for(ll i = n - 2; i >= 0; i--){
        for(ll j = 0; j < 2; j++){
            char req = wb[j^((n-i-1)&1)];
            dps[i][j] = dps[i+1][j] + (req != s[i]);
        }
    }
    ll ans = 1e15;
    for(ll i = 0; i < n - 1; i++){
        ans = min({dpp[i][0] + dps[i+1][1], dpp[i][1] + dps[i+1][0], ans});
    }
    ans = min({ans, dpp[n-1][0], dpp[n-1][1]});
    cout << ans << "\n";
}
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    
    ll TC;
    cin >> TC;

    for(ll TT = 0; TT < TC; TT++){
        solve();
    } 
}

