# The minimum difference

---

# Intuition
The given problem can be solved by careful case analysis and prefix sum technique.

Note that there can only be 2 types of final answers: either `wbwbwwb...` or `bwbwbw...` - Let's call them **Type 1**and **Type 2** respectively. 

If we have the string which needs to be converted into final string of either type, the number of color reversals can be calculated in `O(1)` time if we know the number of white boxes in the odd positions and number of white boxes in even position in the string (the number of black boxes in odd and even positions can be derived as the total number of positions are fixed). 

This is due to the fact that answer of any type has same color of box at odd positions and even positions respectively. So what remains is just to find the information about number of white balls in even and odd positions in the string obtained by cutting a prefix and appending it to the suffix of the string. 

The required information can be calculated by maintaining 2 prefix sum array, 

```
w_odd[i] -> number of white boxes in odd positions in [0,i]
```

```
w_even[i] -> number of white boxes in even positions among [0,i]
```

So, the final solution is to consider all prefixes of the given string (including the zero length prefix), and in `O(1)` time calculate the minimum of the number of boxes whose color needs to be reversed to convert the string obtained by operation into type 1 or type 2 answer.

Time Complexity = `O(n)`.
 
---

# Alternate Approach
For problems that talk about cutting a prefix and appending it as a suffix, the first intuition that comes to mind is **cyclic shifts**. An easily verifiable fact is that all cyclic shifts of `str` is present in the concatenated string `str + str` as substrings of length `n` (and they are exhaustive as well).

The rules in the problem boils down to: You can start with any cyclic shift of `str`. Once you've fixed the cyclic shift, you need to convert that string into alternating characters. What is the minimum cost to do so?

Since cyclic shifts are substrings of `str + str`, we can simplify it further:

> You can choose any substring of length `n` from the string `str + str`. What is the minimum cost of converting that substring to an alternating sequence?

As discussed in the first approach, the target alternating string can start with either `w` or `b`. Let's fix the target string, and pick a random subarray of length `n` from `str + str`. How to find out the cost to convert this subarray to the target string?

For each `i`, we can check if `chosen[i] == target[i]`. If it is, we have a match, if not, we have a mismatch. The cost would then be the number of mismatches that has occurred.

So far so good, but what if we modify the chosen substring? Suppose we delete the first character of the chosen substring and append a new one (essentially, slide the window to get the next cyclic shift). How to quickly determine the new cost? (Note that the target string is still fixed, only the chosen string went through a left shift).

To do so, first, we remove the contribution of `chosen.front`, since its counterpart is leaving the window, i.e, if `chosen.front == target.front`, we decrease the `match` count (because it no longer exists), and if `chosen.front != target.front`, we decrease the mismatch count.

Next, notice **a very crucial observation**: If `chosen[i]` was being compared to `target[i]` in the first iteration, upon left shift, `chosen[i]` would then be compared to `target[i - 1]`. Since `target[i] != target[i - 1]`, the contribution of `chosen[i]` would be reversed. In other words, if `chosen[i]` and `target[i]` were a match, upon left shift, they would now be a mismatch, and vice versa. In short,

> `match` and `mismatch` count would be swapped.

Finally, consider the new element that is entering the window. We update it's contribution to match/mismatch count by comparing it to `target.back`.

This way, for each shift, we can calculate the cost in `O(1)` using data from previous shifts. The overall minimum over both the targets is the optimal answer.

---

# Pseudocode
```py
# Each cyclic shift is now present as a substring of length n.
concat = str + str

# Create the 2 possible target string (wbw.. and bwb...)
target_w, target_b
for i in [0, n):
    target_w += i is odd  ? "w" : "b"
    target_b += i is even ? "b" : "w"

# Perform the algorithm on both the targets
for target in [target_w, target_b]:
    # First window
    for i in [0, n):
        concat[i] == target[i] ? match++ : mismatch++
    
    # Answer for first window
    ans = mismatch

    # Repeat for the remaining (n - 1) windows
    for i in [n, 2n - 1):
        # Find the leaving element's index
        oldest = i - n

        # Remove its contribution
        conact[oldest] == target.front ? match-- : mismatch--
        
        # Due to left shift, all match and mistach would be swapped
        swap(match, mismatch)

        # Now add contribution of the incoming element
        concat[i] == target.back ? match++ : mismatch++

        # Calculate the answer for this shift
        ans = min(ans, mismatch)

print(ans)
```


---

# Code
* [Setter's Solution](sol.cpp)
* [Alternate Solution (Variety Jones)](sol-vj.cpp)

---
