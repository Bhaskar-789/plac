#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int t_low = 1;
int t_high = 10;
int n_low = 1;
int n_high = 1e5;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();

int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
		t_high = 2;
		n_high = 15;
	}

	if(type == "extreme") {
		t_low = t_high;
		n_low = n_high;
	}

	generate();
	return 0;
}

void generate()
{
	int t = rnd.next(t_low, t_high);
	cout << t << endl;
	for(int k = 0; k < t; k++) {
		int n = rnd.next(n_low, n_high);
		string str = "";
		for(int i = 0; i < n; i++) {
			if(rnd.next(0, 1)) {
				str += 'w';
			}
			else {
				str += 'b';
			}
		}
		cout << str << endl;
	}
}
