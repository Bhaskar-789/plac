#include<bits/stdc++.h>
using namespace std;

#define ll long long

void solve(){
    ll n, k;
    cin >> n >> k;

    vector<ll> v(n);
    for(ll i = 0; i < n; i++){
        ll x;
        cin >> x;
        if(x < k)v[i] = -1;
        else if(x > k)v[i] = 1;
    }
    vector<vector<ll>> pos(3*n + 1);
    pos[v[0]+2*n].push_back(0);
    for(ll i = 1; i < n; i++){
        v[i] += v[i-1];
        pos[v[i] + 2*n].push_back(i);
    }

    ll sum = v[n-1];
    ll mn = n;
    if(sum == 0){
        cout << n << "\n";
        return;
    }
    if(pos[sum + 2*n].size()){
        mn = pos[sum + 2*n][0] + 1;
    }
    for(int i = 0; i < n-1; i++){
        ll a = v[i];
        if(a+sum > n)continue;
        auto it = lower_bound(pos[a + sum + 2*n].begin(), pos[a + sum + 2*n].end(), i);
        if(it != pos[a+sum+2*n].end())mn = min(mn, *it - i);
    }
    cout << n - mn << "\n";
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);

    ll TC;
    cin >> TC;

    for(ll TT = 0; TT < TC; TT++){
        solve();
    } 
}

