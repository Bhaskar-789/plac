# Maximum Subarray

---

# Intuition
In this problem, we require maximum length of prefix and suffix such that combining them we get an equal number of elements in the array which are strictly greater and strictly lesser than `K`. So let us simply modify the given array such that `A_i= sign(A_i - K) if A_i != K, 0 otherwise`. So `A_i` is 1 if it is greater than `K`, and -1 if lesser. So now the given problem is modified to finding the largest prefix and suffix combination which yields the sum zero. Hence, it is equivalent to finding the minimum length subarray which has sum equal to the sum of whole array (so on removing the subarray, the remainder has sum zero). Now it is a standard problem, which can be solved in `O(n log n)` using `std::map` in C++.

---

# Pseudocode

```py
s = sum(A)
n = A.length()
if s==0:
	ans=n
else:
	map<int,int> pos;
	pos[0]=-1
	prefix_sum=0
	for i in range(n):
		prefix_sum += A[i]
		if pos.find(prefix_sum - s)!= pos.end():
			subarray_size=min(subarray_size,i - pos[prefix_sum-s])
		pos[prefix_sum] = i
	ans= n - subarray_size
```

---


# Code
* [Setter's Solution](sol.cpp)

---
