#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int t_low = 1;
int t_high = 10;
int n_low = 1;
int n_high = 1e5;
int val_low = 1;
int val_high = 100;
// We are keeping the range low to allow variety of testcases
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();

int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
		t_high = 2;
		n_high = 15;
		val_high = 15;
	}

	if(type == "extreme") {
		t_low = t_high;
		n_low = n_high;
	}

	generate();
	return 0;
}

void generate()
{
	int t = rnd.next(t_low, t_high);
	cout << t << endl;
	for(int ii = 0; ii < t; ii++) {
		int n = rnd.next(n_low, n_high);
		int k = rnd.next(val_low, val_high);
		vector<int> a(n);
		for(auto &ele : a) {
			ele = rnd.next(val_low, val_high);
		}
		cout << n << " " << k << endl;
		for(auto &ele : a) {
			cout << ele << " ";
		}
		cout << endl;
	}
}
