#include<bits/stdc++.h>
using namespace std;

#define ll long long
#define pll pair<ll, ll>

pll go(ll x, vector<ll>& v, vector<pll>& dp){
    if(dp[x].second != -1){
        return dp[x];
    }
    pll res = make_pair(LLONG_MAX, -1);
    vector<ll> bits;
    for(ll i = 0; i < 32; i++){
        if((x >> i) & 1){
            bits.push_back(i);
        }
    }
    for(ll i = 0; i+1 < bits.size(); i++){
        for(ll j = i + 1; j < bits.size(); j++){
            ll y = x^(1LL << bits[i])^(1LL << bits[j]); //ans for bitmask y
            ll val = v[bits[i]]^v[bits[j]]; // ans for the removed 2 bits which are a pair
            pll got = go(y, v, dp);
            res.first = min(res.first, val + got.first);
            res.second = max(res.second, val + got.second);
        }
    }
    return dp[x] = res;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    
    ll n;
    cin >> n;
    vector<ll> v(n);
    for(auto &x: v){
        cin >> x;
    }

    vector<pll> dp(1LL << n, make_pair(-1, -1)); //bitmask dp 

    for(ll i = 0; i < n; i++){
        for(ll j = i+1; j < n; j++){
            ll val = v[i] ^ v[j];
            //first value is minimum sum, second value is maximum sum
            dp[((1LL << i) | (1LL << j))] = make_pair(val, val);
        }
    }

    pll ans = go((1LL<<n)-1, v, dp);
    cout << ans.first << " " << ans.second;
}