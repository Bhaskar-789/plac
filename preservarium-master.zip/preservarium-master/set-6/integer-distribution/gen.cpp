#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int half_n_low = 1;
int half_n_high = 10;
int val_low = 0;
int val_high = 1e9;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();
void generate_corner();

int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
		half_n_high = 5;
		val_high = 23;
	}

	if(type == "extreme") {
		half_n_low = half_n_high;
		// no need to limit val
	}

	// Add corner case suggested by darklord
	if(type == "corner") {
		generate_corner();
		return 0;
	}

	generate();
	return 0;
}

void generate()
{
	int half_n = rnd.next(half_n_low, half_n_high);
	int n = half_n*2;

	vector<int> a(n);
	for(auto &ele : a) {
		ele = rnd.next(val_low, val_high);
	}

	cout << n << endl;
	for(auto &ele : a) {
		cout << ele << endl;
	}
}

void generate_corner() {
	int n = 20;
	vector<long long> a(n);

	// 10 numbers should be zero
	for(int i = 0; i < n/2; i++) {
		a[i] = 0;
	}

	// other 10 numbers are 2^31 - 1
	for(int i = n/2; i < n; i++) {
		a[i] = (1LL << 31) - 1;
	}

	shuffle(a.begin(), a.end());
	cout << n << endl;
	for(auto &ele : a) {
		cout << ele << endl;
	}
}
