#include<bits/stdc++.h>
using namespace std;

void solve(){
    string s;
    cin>>s;
    int n = s.size();
    vector<int> count(26,0);
    for(int i=0; i<n; i++){
        count[s[i]-'a']++;
        if( n%(i+1) == 0 ){
            int flag = 1;
            for( int k = 0; k < n; k += i+1 ){
                vector<int> temp( 26, 0 );
                for( int l=0;l< i+1; l++ )  temp[s[l+k]-'a']++;
                if( temp != count ){
                    flag = 0;
                    break;
                }
            }
            if( flag ){
                cout<<i+1;
                return;
            }
        }
    }
    cout<<n;
       
}

int main(){

    solve();
    return 0;
    
}