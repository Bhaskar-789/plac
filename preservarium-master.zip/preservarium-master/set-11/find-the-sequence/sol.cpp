#include<bits/stdc++.h>
using namespace std;

void solve(){
    string s;
    cin>>s;
    int n = s.length(), l = 0, r = n-1;
    int num = 1, i = 0, ans[n];
    while(l<=r){
        if(s[i] == 'R')ans[l++] = num++;
        else ans[r--] = num++;
        i++;
    }       
    for(int i=0;i<n;i++)cout<<ans[i]<<" ";
}


int main(){

    solve();
    return 0;
}