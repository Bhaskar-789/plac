#include<bits/stdc++.h>
using namespace std;

void solve(){
    string s;
    cin>>s;
    int n = s.length();
    map<char,vector<int>  > m;
    for(int i = 0; i < n; i++){
        m[s[i]].push_back(i);
    }
    int tot_ltr = m.size();
    int tmp = -1;
    string ans = "";
    for(int j = 0; j < tot_ltr; j++){
        for (auto i = m.rbegin(); i != m.rend(); ++i) {
            int tmp1 = lower_bound(i->second.begin(),i->second.end(),tmp ) - i->second.begin();
            int flag = 1;
            for(auto it : m){
                if(it.first!=i->first){
                    if(lower_bound(it.second.begin(),it.second.end(),i->second[tmp1]) == it.second.end())flag = 0;
                }
            }
            if(flag == 1){
                tmp = i->second[tmp1];
                ans += i->first;
                m.erase(i->first);
                break;
            }
        }
    }
    cout<< ans;
       
}


int main(){

    solve();
    return 0;
}