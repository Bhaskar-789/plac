#include<bits/stdc++.h>
using namespace std;

#define ll long long
const ll mod = 1000000007;

ll po(ll x, ll n ){ 
    ll ans=1;
     while(n>0){
         if(n&1) ans=(ans*x)%mod;
         x=(x*x)%mod;
         n/=2;
     }
     return ans;
}

ll fac[200005];
ll ncr(ll n, ll r){
    if(n < r)return 0;
    ll ret = fac[n];
    ret*=po(fac[r],mod-2);
    ret%=mod;
    ret*=po(fac[n-r],mod-2);
    ret%=mod;
    return ret;
}

void solve(){
    string s;
    cin>>s;
    map<char,int> m;
    int mx=0,n =s.size();
    for(int i=0;i<n;i++){
        m[s[i]]++;
        mx = max(m[s[i]],mx);
    }
    fac[0]=1;
    for(int i=1;i<=n;i++){
        fac[i] = fac[i-1]*i;
        fac[i] %= mod;
    }
    ll ans = 0;
    for(int i=1;i<=mx;i++){
        ll temp =1;
        for(auto it: m){
            temp *= ncr(it.second, i) + 1;
            temp %= mod;
        }
        ans += temp-1;
        ans %= mod;
        ans += mod;
        ans %= mod;

    }
    cout<< ans;


}


int main(){

    solve();
    return 0;

}