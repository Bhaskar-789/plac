#include<bits/stdc++.h>
using namespace std;

void solve(){
    ll a,b,c,n;
    cin>>a>>b>>c>>n;
    if(n == 0){
        cout<< a;
        return ;
    }
    if(n == 1){
        cout<< b;
        return ;
    }
    if(n == 2){
        cout<< c;
        return ;
    }
    n-=2;
    int tmp[] = {1, 3, 7, 6, 4};
    ll ans = 0;
    for(int i=0;i<64;i++){
        ll val = 0;
        if((1LL<<i)&c)val += 1;
        if((1LL<<i)&b)val += 2;
        if((1LL<<i)&a)val += 4;
        if( val == 2 && n%2 == 1)ans +=  (1LL<<i);
        else if( val == 5 && n%2 == 0) ans += (1LL<<i);
        else if(val == 1) ans += (tmp[n%5]%2)*(1LL<<i);
        else if(val == 3) ans += (tmp[(n+1)%5]%2)*(1LL<<i);
        else if(val == 7) ans += (tmp[(n+2)%5]%2)*(1LL<<i);
        else if(val == 6) ans += (tmp[(n+3)%5]%2)*(1LL<<i);
        else if(val == 4) ans += (tmp[(n+4)%5]%2)*(1LL<<i);
    }
    cout << ans;

       
}


int main(){

    solve();
    return 0;

}