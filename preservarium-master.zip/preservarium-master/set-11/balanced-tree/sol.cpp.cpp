#include<bits/stdc++.h>
using namespace std;

void solve(){
    int n,m;
    cin>>n>>m;
    long long stone[n+1];
    vector<int>graph[n+1];
    for(int i=0;i<m;i++){
        int x,y;
        cin>>x>>y;
        graph[x].push_back(y);
        graph[y].push_back(x);
    }
    int mx=0,mx_node=0;
    long long w = 0;
    priority_queue<pair<long long,int> > q;
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>stone[i];
        w += stone[i];
        q.push({stone[i],i});
        if(stone[i]>mx){
            mx=stone[i];
            mx_node=i;
        }
    }
    vector<int>visit(n+1,0);
    long long sum = 0;
    while(!q.empty()){
        int stn = q.top().first;
        int x = q.top().second;
        q.pop();
        if(visit[x])continue;
        visit[x]=1;
        sum += stn;
        for(auto it:graph[x]){
            if(stone[it]<stn-1){
                stone[it]=stn-1;
                q.push({stn-1,it});
            }
        }
    }
    cout<< sum - w;
       
}


int main(){
    
    solve();
    return 0;

}