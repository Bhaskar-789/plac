#include<bits/stdc++.h>
using namespace std;

vector<int>graph[200005];
int cost[200005];
vector<int>visit(200005,0),dp(200005,0);
int k;
int ans=0;
map<int,int>m;
void dfs(int x){
    visit[x]=1;
    for(auto it:graph[x]){
        if(!visit[it]){
            dp[it]=dp[x]+cost[it];
            m[dp[it]%k]++;
            ans+=m[dp[it]%k]-1;
            if(dp[it]%k==0){
                ans++;
            }
            dfs(it);
            m[dp[it]%k]--;
        }
    }

}
void solve(){
    int n;
    cin>>n;
    for(int i=1;i<=n;i++)cin>>cost[i];
    for(int i=0;i<n-1;i++){
        int x,y;
        cin>>x>>y;
        graph[x].push_back(y);
        graph[y].push_back(x);
    }
    
    cin>>k;
    dp[1]=cost[1];
    m[dp[1]%k]++;
    if(dp[1]%k==0)ans++;
    dfs(1);

    cout<<ans;
}

int main(){

    solve();
    return 0;
    
}