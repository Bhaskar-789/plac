#include<bits/stdc++.h>
using namespace std;

struct trie{
    string str = "#";
    struct trie *left;
    struct trie *right;
};
void solve(){
    struct trie *head = new trie();
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        string c;
        cin>>c;
        string s;
        cin>>s;
        struct trie *temp = head;
        for(int j=0;j<s.size();j++){
            if(s[j]=='1'){
                if(temp->right==NULL){
                    temp->right = new trie();
                }
                temp = temp->right;
            }
            else{
                if(temp->left==NULL){
                    temp->left = new trie();
                }
                temp = temp->left;
            }
        }
        temp->str = c;
    }
    string s,ans;
    cin>>s;
    struct trie *temp = head;   
    for(int i=0;i<s.size();i++){
        if(s[i]=='1'){

            temp=temp->right;
            if(temp->str != "#"){
                if(temp->str == "[newline]")ans+="\\n";
                else ans+=temp->str;
                temp=head;
            }
        }
        else{
            temp=temp->left;
            if(temp->str != "#"){
                if(temp->str == "[newline]")ans+="\\n";
                else ans+=temp->str;
                temp=head;
            }
        }
    }
    cout<<ans;
}


int main(){

    solve();
    return 0;
}