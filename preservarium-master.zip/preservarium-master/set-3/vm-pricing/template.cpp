#include <bits/stdc++.h>
using namespace std;

/*
 * Complete the 'interpolate' function below.
 *
 * The function is expected to return a STRING.
 * The function accepts following parameters:
 *  1. INTEGER n
 *  2. INTEGER_ARRAY instances
 *  3. FLOAT_ARRAY price
 */

string interpolate(int n, vector<int> instances, vector<float> price) {

}

int main()
{
    ios_base::sync_with_stdio(0); cin.tie(0);

    int n; cin >> n;
    int m; cin >> m;
    vector<int> instances(m);
    for (auto &i : instances)cin >> i;

    cin >> m;
    vector<float> price(m);
    for (auto &i : price)cin >> i;

    auto ans = interpolate(n, instances, price);
    cout << ans << endl;
}