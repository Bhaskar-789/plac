#include<bits/stdc++.h>
using namespace std;


vector<vector<int>> calculateIdealDistribution(vector<int> demand)
{
}

int32_t main()
{
	ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);

	int n; cin >> n;
	vector<int> a(n);
	for (auto &i : a)cin >> i;

	auto ans = calculateIdealDistribution(a);

	for (auto i : ans) {
		for (auto j : i) {
			cout << j << " ";
		}
		cout << endl;
	}

	return 0;
}
