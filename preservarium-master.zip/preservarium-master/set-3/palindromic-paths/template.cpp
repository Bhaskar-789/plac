#include <bits/stdc++.h>
using namespace std;


/*
 * Complete the 'numNicePairs' function below.
 *
 * The function is expected to return a LONG_INTEGER.
 * The function accepts WEIGHTED_INTEGER_GRAPH g as parameter.
 */

/*
 * For the weighted graph, <name>:
 *
 * 1. The number of nodes is <name>_nodes.
 * 2. The number of edges is <name>_edges.
 * 3. An edge exists between <name>_from[i] and <name>_to[i]. The weight of the edge is <name>_weight[i].
 *
 */

long numNicePairs(int g_nodes, vector<int> g_from, vector<int> g_to, vector<int> g_weight) {

}


int main()
{
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);

    int n; cin >> n;

    vector<int> from(n - 1), to(n - 1), weight(n - 1);
    for (int i = 0; i < n - 1; i++) {
        cin >> from[i] >> to[i] >> weight[i];
    }


    auto res = numNicePairs(n, from, to, weight);
    cout << res << endl;

    return 0;

}