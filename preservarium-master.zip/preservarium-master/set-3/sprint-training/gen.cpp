#include<iostream>
#include "testlib.h"
using namespace std;
/********************* Custom Inputs ***************************/
int n_low=1;
int n_high=1e5;
int size_low=1;
int size_high=1e5;
int pos_low=1;
int pos_high=1e5;
/********************* Custom Inputs ***************************/
#define endl '\n'
void generate();
void gen_decreasing();
void gen_increasing();
int main(int argc, char* argv[]){
    registerGen(argc, argv, 1);
    string type = argc > 1 ? argv[1] : "unexpected";

    if(type == "small"){
        n_high = 10;
        size_high=10;
        generate();
    }

    if(type == "mixed"){
        generate();
    }

    if(type == "custom"){
        n_low=n_high;
        size_low=size_high;
        pos_high=20;
        generate();
    }

    if(type == "extreme"){
	n_low = n_high;
        size_low=size_high;
        generate();
    }

    if(type == "decreasing"){
        n_low = n_high;
        gen_decreasing();
    }

    if(type == "increasing"){
        n_low = n_high;
        gen_increasing();
    }
	
    return 0;
}
void generate(){
    int total = rnd.next(n_low, n_high);
    int n = rnd.next(size_low,size_high);
    vector<int>a;
    while((int)a.size()!=n){
        a.push_back(rnd.next(pos_low,min(pos_high,total)));
    }
    cout << total << endl;
    cout << n << endl;
    for(auto &ele : a) 
    cout << ele << endl;
}

void gen_decreasing(){
    int total = rnd.next(n_low, n_high);
    int n = rnd.next(size_low, size_high);
    set<int>a;
    while((int)a.size()!=n){
        a.insert(rnd.next(pos_low,pos_high));
    }
    cout << total << endl;
    cout << n << endl;
    vector<int>hold;
    for(auto &ele : a) 
        hold.push_back(ele);
    reverse(hold.begin(),hold.end());
    for(auto &ele : hold) 
    cout << ele << endl;
}
void gen_increasing(){
    int total = rnd.next(n_low, n_high);
    int n = rnd.next(size_low, size_high);
    set<int>a;
    while((int)a.size()!=n){
        a.insert(rnd.next(pos_low,pos_high));
    }
    cout << total << endl;
    cout << n << endl;
    for(auto &ele : a) 
    cout << ele << endl;
}
