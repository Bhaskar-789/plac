#  Sprint Training.

---

# Intuition
We can consider sprints as ranges from the given array as `min(arr[i-1],arr[i]) to max(arr[i-1],arr[i])`. Now the problem reduces to finding the point which appears in maximum number of ranges. This is a standard problem which can be done with `O(n)` time complexity in the following way:

- Create an array `cnt[MAX_SIZE]` with `MAX_SIZE` as the maximum value of a point occuring in the range.
- For each range `[l,r]` , do `cnt[l]++` and `cnt[r+1]--`. This essentially creates a boundary for the range `[l,r]`.
- Take prefix sum of the array. (For a particular `[l,r]`, this step adds 1 to each of the points in `[l,r]`, thus updating the contribution by range `[l,r]`).

Now `cnt[i]` gives the number of ranges in which `i` occurs.

---

# Code
* [Setter's Solution](sol.cpp)

---
