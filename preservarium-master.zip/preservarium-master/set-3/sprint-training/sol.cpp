#include<bits/stdc++.h>
using namespace std;

#define A(x) (x).begin(),(x).end()
#define sz(x) ((int)(x).size())
#define UNI(x) sort(A(x)); (x).erase(unique(A(x)),(x).end())
using i64 = long long;
void _read();


int main () { _read(); 

      int n;
      cin >> n;
      vector<int> d(n + 1);
      int N; cin >> N;
      vector<int> v(N);
      for(int &x : v)
            cin >> x;
      for(int i = 0; i + 1 < sz(v); ++i) {
            int a = v[i], b = v[i + 1];
            --a, --b;
            if(a > b)
                  swap(a, b);
            d[a]++;
            d[b + 1]--;
      }
      for(int i = 1; i < n; ++i) {
            d[i] += d[i - 1];
      }
      cout << int(max_element(A(d)) - d.begin()) + 1 << '\n';
      return 0;
};

void _read() {
      ios_base :: sync_with_stdio(false);
      cin.tie(NULL);
      #ifdef LOCAL
      freopen("input.txt","r",stdin);
      #endif
}
