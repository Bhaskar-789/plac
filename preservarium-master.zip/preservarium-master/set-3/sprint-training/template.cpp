#include<bits/stdc++.h>
using namespace std;


int getMostVisited(int n, vector<int> sprints)
{

}

int main()
{
	ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);

	int n; cin >> n;
	int sz; cin >> sz;

	vector<int> arr(sz);
	for (auto &i : arr)cin >> i;

	int ans = getMostVisited(n, arr);
	cout << ans << endl;

	return 0;
}