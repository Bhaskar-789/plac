#  Highly Profitable Months 

---

# Intuition
For `k=1`, the answer is `n`.Otherwise, to check for k-sized subarrays, we maintain a sliding window (implemented using deque q). When processing an element at index `i`, following cases arise:
- Window is empty : In this case append the element to the queue.
- `q.back() < arr[i]`: In this case also `arr[i]` can be appended to back of the queue. Now if `q.size()==k`, we have obtained a highly profitable k-sized subarray. Thus we incerase the answer by 1. Now we remove the front element of the q and continue.
-  `q.back() >= arr[i]`: In this case, no k-sized subarray with `arr[i]` not in the beginning can be possible, as it would contain the index (i-1) and i-th pair. So we empty the deque and place `arr[i]` in it and continue. 

---

# Pseudocode
```cpp
 for (int i = 0; i < n; ++i)
    {
        if(q.empty()){
            q.push_back(v[i]);
            continue;
        }
        if(q.back() < v[i]){
            q.push_back(v[i]);
        }
        else{
            q.clear();
            q.push_back(v[i]);
        }
        if(q.size()==k){
            ans++;
            q.pop_front();
        }
    }

```

---

# Code
* [Setter's Solution](sol.cpp)

---
