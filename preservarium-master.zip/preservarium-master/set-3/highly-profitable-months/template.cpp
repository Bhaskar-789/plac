#include <bits/stdc++.h>
using namespace std;



/*
 * Complete the 'countHighlyProfitableMonths' function below.
 *
 * The function is expected to return an INTEGER.
 * The function accepts following parameters:
 *  1. INTEGER_ARRAY stockPrices
 *  2. INTEGER k
 */

int countHighlyProfitableMonths(vector<int> stockPrices, int k) {

}

int main()
{
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);

    int n; cin >> n;
    vector<int> arr(n);
    for (auto &i : arr)cin >> i;

    int k; cin >> k;

    int ans = countHighlyProfitableMonths(arr, k);
    cout << ans << endl;

    return 0;
}