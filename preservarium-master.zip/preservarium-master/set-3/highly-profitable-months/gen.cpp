#include<iostream>
#include "testlib.h"
using namespace std;
/********************* Custom Inputs ***************************/
int n_low=1;
int n_high=2e5;
int val_low=1;
int val_high=1e9;
/********************* Custom Inputs ***************************/
#define endl '\n'
void generate();
void gen_dec();
void gen_inc();
int main(int argc, char* argv[]){
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
    if(type=="small"){
        n_high=10;
        val_high=1e3;
        generate();
    }
    else if(type=="mixed"){
        generate();
    }
    else if(type=="extreme"){
        n_low=n_high;
        generate();
    }
    else if(type=="inc"){
        n_low=n_high;
        gen_inc();
    }
    else if(type=="dec"){
        n_low=n_high;
        gen_dec(); 
    }

    return 0;
}
void generate(){
    int n=rnd.next(n_low,n_high);
    cout<<n<<endl;
    vector<int>a;
    int rem=n;
    while(rem!=0){
        int how=rnd.next(1,rem);
        rem-=how;
        int sorted=rnd.next(0,1);
        if(sorted){
            vector<int>hold;
            for(int i=0;i<how;i++){
                hold.push_back(rnd.next(val_low,val_high));
            }
            sort(hold.begin(),hold.end());
            for(auto &ele:hold)
                a.push_back(ele);
        }
        else{
            for(int i=0;i<how;i++){
                a.push_back(rnd.next(val_low,val_high));
            }
        }
    }
    for(auto &ele:a) 
        cout<<ele<<endl;
    int k=rnd.next(1,n);
    cout<<k<<endl;
}
void gen_dec(){
    int n=rnd.next(n_low,n_high);
    cout<<n<<endl;
    vector<int>a;
    for(int i=0;i<n;i++){
        a.push_back(rnd.next(val_low,val_high));
    }
    sort(a.rbegin(),a.rend());
    for(auto &ele:a) 
        cout<<ele<<endl;
    int k=rnd.next(1,n);
    cout<<k<<endl;
}
void gen_inc(){
    int n = rnd.next(n_low, n_high);
    cout<<n<<endl;
    vector<int>a;
    for(int i=0;i<n;i++){
        a.push_back(rnd.next(val_low,val_high));
    }
    sort(a.begin(),a.end());
    for(auto &ele:a) 
        cout<<ele<<endl;
    int k=rnd.next(1,n);
    cout<<k<<endl;
}
