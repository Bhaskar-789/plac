#include <bits/stdc++.h>
using namespace std;


/*
 * Complete the 'countHighlyProfitableMonths' function below.
 *
 * The function is expected to return an INTEGER.
 * The function accepts following parameters:
 *  1. INTEGER_ARRAY stockPrices
 *  2. INTEGER k
 */

int countHighlyProfitableMonths(vector<int> a, int k) {

    int n = a.size();
    vector<int> dp(n, 1);

    int ans = 0;

    for (int i = 1; i < n; i++) {
        if (a[i] > a[i - 1]) {
            dp[i] = dp[i - 1] + 1;
        }

        if (dp[i] >= k)ans++;
    }

    return ans + (k == 1);
}

int main()
{
    int n; cin >> n;

    vector<int> a(n);
    for (auto &i : a)cin >> i;

    int k; cin >> k;

    int ans = countHighlyProfitableMonths(a, k);
    cout << ans << endl;
}