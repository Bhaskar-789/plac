#include<bits/stdc++.h>
using namespace std;


int snackArrangement(int n, vector<int> &a)
{

}


int main()
{

	ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);

	int n; cin >> n;
	vector<int> arr(n);
	for (auto &i : arr)cin >> i;

	int ans = snackArrangement(n, arr);
	cout << ans << endl;

	return 0;
}
