#include <bits/stdc++.h>
using namespace std;

/*
 * Complete the 'vowelsubstring' function below.
 *
 * The function is expected to return an INTEGER.
 * The function accepts STRING s as parameter.
*/

long long vowelsubstring(string s) {

}

int main()
{
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);

    string s; cin >> s;
    long long ans = vowelsubstring(s);
    cout << ans << endl;
}