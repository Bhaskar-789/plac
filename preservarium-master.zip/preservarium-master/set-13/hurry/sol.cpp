#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define int ll
#define oo (int)(1e17)

int32_t main() {
    cin.sync_with_stdio(false);
    cin.tie(0); cout.tie(0);
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("out1.txt", "w", stdout);
#endif
    int n, T;
    cin >> n >> T;
    pair<int, int> tasks[n + 4];
    for (int i = 1; i <= n; i++) {
        cin >> tasks[i].first >> tasks[i].second;
    }
    sort(tasks + 1, tasks + n + 1);
    multiset<int> least_tms;
    int alr = 0;
    int ans = 0;
    for (int i = 1; i <= n; i++) {
        int rem_time = T - 2 * tasks[i].first;
        if (rem_time >= 0) {
            least_tms.insert(tasks[i].second);
            alr += tasks[i].second;
            while ((int)(least_tms.size()) > 0 && alr > rem_time) {
                auto it = least_tms.end();
                it--;
                alr -= *it;
                least_tms.erase(it);
            }
            ans = max(ans, (int)(least_tms.size()));
        }
        else {
            break;
        }
    }
    cout << ans;
}
