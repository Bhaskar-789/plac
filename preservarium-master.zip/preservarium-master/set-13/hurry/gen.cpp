#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int n_low = 1;
int n_high = (int)1e5;
int T_low = 0;
int T_high = (int)1e8;
int li_low = 0;
int li_high = (int)1e9;
int ti_low = 0;
int ti_high = (int)1e9;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();

int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
		n_high = 15;
		T_high = 99;
		li_high = 15;
		ti_high = 15;
	}

	if(type == "extreme") {
		n_low = n_high;
		T_low = (int)1e7;
	}

	generate();
	return 0;
}

void generate()
{
	int n = rnd.next(n_low, n_high);
	int T = rnd.next(T_low, T_high);
	cout << n << " " << T << endl;

	for(int i = 0; i < n; i++) {
		int li = rnd.next(li_low, li_high);
		int ti = rnd.next(ti_low, ti_high);
		cout << li << " " << ti << endl;
	}
}
