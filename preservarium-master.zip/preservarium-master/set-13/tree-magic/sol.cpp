#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define int ll
#define oo (int)(1e17)

void sieve(int n, int*pr) { //pr in the array of size n initialised with all //ones
    for (int p = 2; p * p <= n; p++) {
        if (pr[p] == 1) {
            for (int i = p * p; i <= n; i += p) {
                pr[i] = 0;
            }
        }
    }
    pr[1] = 0;
}//the above sieve marks the non primes in the array pr as 0 in n (log^2(n))

int tot ;
const int N = 2000009;
int pr[N];
int ans[N];
int vis[N];
int val[N];
vector<int> adj[N];
void dfs(int curr) {
    vis[curr] = 1;
    int v_curr = 0;
    if (pr[val[curr]]) {
        v_curr = val[curr];
    }
    for (auto el : adj[curr]) {
        if (!vis[el]) {
            dfs(el);
            v_curr = v_curr ^ ans[el];
        }
    }
    ans[curr] = v_curr;
}
int fctrs[N];
int32_t main() {
    cin.sync_with_stdio(false);
    cin.tie(0); cout.tie(0);
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("out1.txt", "w", stdout);
#endif
    for (int i = 0; i <= N; i++) {
        fctrs[i] = 0;
        pr[i] = 1;
        vis[i] = 0;
    }
    sieve(N - 4, pr);
    for (int i = 1; i <= N; i++) {
        int j = 1;
        while (i * j <= N) {
            fctrs[i * j]++;
            j++;
        }
    }
    int n;
    cin >> n;
    tot = 0;
    for (int i = 1; i <= n; i++) {
        cin >> val[i];
        if (pr[val[i]]) {
            tot = tot ^ val[i];
        }
    }
    for (int i = 1; i < n; i++) {
        int a;
        cin >> a;
        adj[a].push_back(i + 1);
        adj[i + 1].push_back(a);
    }
    dfs(1);
    for (int i = 1; i <= n; i++) {
        cout << fctrs[tot ^ ans[i]] << " ";
    }

}
