#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int n_low = 1;
int n_high = (int)1e5;
int val_low = 1;
int val_high = (int)1e6;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();
vector<pair<int, int>> generate_tree(int n);

vector<int> parent;
vector<vector<int>> adj;

void dfs(int src, int par) {
	parent[src] = par;

	for (auto &child : adj[src]) {
		if (child != par) {
			dfs(child, src);
		}
	}
}


int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
		n_high = 9;
		val_high = 99;
	}

	if(type == "extreme") {
		n_low = n_high;
	}

	generate();
	return 0;
}

void generate()
{
	int n = rnd.next(n_low, n_high);
	auto edges_vec = generate_tree(n);

	parent.clear();
	parent.resize(n);
	adj.clear();
	adj.resize(n);
	for (auto &edge : edges_vec) {
		int x = edge.first;
		int y = edge.second;
		x--;
		y--;
		adj[x].push_back(y);
		adj[y].push_back(x);
	}

	dfs(0, -1);

	cout << n << endl;
	for(int i = 0; i < n; i++) {
		cout << rnd.next(val_low, val_high) << " ";
	}
	cout << endl;

	for(int i = 1; i < n; i++) {
		cout << parent[i] + 1 << " ";
	}
	cout << endl;
}

// Returns the (n - 1) edges of a 1-indexed random tree with n nodes..
vector<pair<int, int>> generate_tree(int n) {
	vector<pair<int, int>> edges;
	for (int i = 2; i <= n; i++) {
		edges.emplace_back(rnd.next(1, i - 1), i);
	}

	// Rename vertices.
	vector<int> perm(n + 1);
	for (int i = 1; i <= n; i++) {
		perm[i] = i;
	}

	shuffle(perm.begin() + 1, perm.end());
	shuffle(edges.begin(), edges.end());

	vector<pair<int, int>> result;
	for (auto edge : edges) {
		int a = edge.first, b = edge.second;
		if (rnd.next(0, 1)) {
			swap(a, b);
		}
		result.push_back(make_pair(perm[a], perm[b]));
	}
	return result;
}
