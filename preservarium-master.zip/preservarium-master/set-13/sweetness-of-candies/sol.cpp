


#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define int ll
#define oo (int)(1e17)
const int M = 1000009;
int fen[1000009];
void update(int ind, int b, int*fen) {
    int i = ind;
    while (i <= M - 2 && i > 0) {
        fen[i] += b;
        i = i + (i & (-i));
    }
}
int sum(int ind, int*fen) {
    int sum = 0;
    int i = ind;
    while (i > 0) {
        sum += fen[i];
        i = i - (i & (-i));
    }
    return sum;
}
int ele(int pos, int *fen) {
    int l = 1;
    int r = M - 1;
    while (l != r) {
        int m = (l + r  ) / 2;
        if (sum(m, fen) >= pos) {
            r = m;
        }
        else {
            l = m + 1;
        }
    }
    return l;
}// returns the element at position pos if there is a unique element at each position. in log(n)*log(n) time;




int32_t main() {
    cin.sync_with_stdio(false);
    cin.tie(0); cout.tie(0);
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("out1.txt", "w", stdout);
#endif
    int n;
    cin >> n;
    int arr[n + 3];
    for (int i = 0; i < M; i++) {
        fen[i] = 0;
    }
    for (int i = 1; i <= n; i++) {
        int a;
        cin >> a;
        arr[i] = a;
        update(a, 1, fen);
    }
    int q, r;
    cin >> q >> r;
    while (q--) {
        int ind, val, pos;
        cin >> ind >> val >> pos;
        update(arr[ind], -1, fen);
        arr[ind] = val;
        update(arr[ind], 1, fen);
        cout << ele(pos, fen) << " ";
    }
}