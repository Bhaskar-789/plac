#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int t_low = 1;
int t_high = 1*(int)1e5;
int number_low = 1;
int number_high = (int)1e9;
int inc_or_dec_cost_low = 1;
int inc_or_dec_cost_high = (int)1e9;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();

int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
		t_high = 5;
		number_high = 99;
		inc_or_dec_cost_high = 9;
	}

	if(type == "extreme") {
		t_low = t_high;
	}

	generate();
	return 0;
}

void generate()
{
	int t = rnd.next(t_low, t_high);
	cout << t << endl;
	for(int zz = 0; zz < t; zz++) {
		int number = rnd.next(number_low, number_high);
		int dec_cost = rnd.next(inc_or_dec_cost_low, inc_or_dec_cost_high);
		int inc_cost = rnd.next(inc_or_dec_cost_low, inc_or_dec_cost_high);
		cout << number << endl;
		cout << dec_cost << endl;
		cout << inc_cost << endl;
	}
}
