#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define int ll
#define oo (int)(1e18) + 8
ll power(ll a, ll b)    //a is base, b is exponent
{
    if (b == 0)
        return 1;
    if (b == 1)
        return a;
    if (b % 2 == 1)
        return (power(a, b - 1) * a) ;
    ll q = power(a, b / 2);
    return (q * q) ;
}
pair<int, int> get(int a, int b, int n) {
    int i = 1;
    int ch = 0;
    int l = -oo;
    int h = oo;
    for (int i = 1;; i++) {
        if (power(a, i) > n) {
            ch = 1;
        }
        for (int j = 1;; j++) {
            if (power(a, i) + power(b, j) >= n) {
                h = min(h, power(a, i) + power(b, j));
                if (j != 1) {
                    l = max(l, power(a, i) + power(b, j - 1));
                }
                break;
            }
        }
        if (ch == 1) {
            break;
        }
    }
    return make_pair(l, h);
}
int32_t main() {
    cin.sync_with_stdio(false);
    cin.tie(0); cout.tie(0);
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("out1.txt", "w", stdout);
#endif
    int t;
    cin >> t;
    while (t--) {
        int n, l, h;
        cin >> n >> l >> h;
        int mn = oo;
        int arr[3] = {3, 5, 7};
        for (int i = 0; i < 3; i++) {
            for (int j = i + 1; j < 3; j++) {
                pair<int, int> p = get(arr[i], arr[j], n);
                if (p.first > -oo) {
                    mn = min(mn, l * (n - p.first));
                }
                if (p.second < oo) {
                    mn = min(mn, h * (p.second - n));
                }
            }
        }
        cout << mn << "\n";
    }
}
