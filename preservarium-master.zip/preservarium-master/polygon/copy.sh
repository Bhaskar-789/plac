# Compile and execute the file
g++ tc-rule.cpp && ./a.out > tc-rule.txt

# Copy to clipboard
xclip -sel c < tc-rule.txt

# Print the confirmation message
echo 'The test-cases have been copied to clipboard'
