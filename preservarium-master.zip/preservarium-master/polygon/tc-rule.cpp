#include <bits/stdc++.h>
using namespace std;

int rand(int a, int b)
{
    return a + rand() % (b - a + 1);
}

int main()
{
	srand(time(0));
	int curr = 2;

	/* TC-2 to TC-50 is small test-cases */
	for(; curr <= 50; curr++)
		cout << "gen small " << rand() << " > " << curr << endl;

	/* TC-51 to TC-200 is normal test-cases */
	for(; curr <= 200; curr++)
		cout << "gen mixed " << rand() << " > " << curr << endl;

	/* TC-201 to TC-210 is extreme test-cases */
	for(; curr <= 210; curr++)
		cout << "gen extreme " << rand() << " > " << curr << endl;

	return 0;
}
