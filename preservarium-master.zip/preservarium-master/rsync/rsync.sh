# Add this folder to your PATH.
# After that, you can just run rsync.sh from anywhere.

# Terminate the script if any step fails
set -e

# Make a mirror of preservarium repo to equinox repo.
# Ignore all the git related files and only move incremental changes.
rsync -avr --cvs-exclude --exclude='/.gitignore' --exclude='/.gitattributes' ~/preservarium/ ~/equinox
