# Set 5
- [ ] **Beautiful Subarrays**
    - [x] Solution
    - [ ] Test Cases
    - [ ] Testing
    - [ ] Editorial
- [ ] **Counting Binary Numbers**
    - [ ] Solution
    - [ ] Test Cases
    - [ ] Testing
    - [ ] Editorial
- [ ] **Photo Album**
    - [x] Solution
    - [ ] Test Cases
    - [ ] Testing
    - [ ] Editorial

---
