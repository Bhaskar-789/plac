#include<bits/stdc++.h>
using namespace std;


int beautifulSubarrays(vector<int> &a, int m)
{

}

int main()
{

	ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);

	int n; cin >> n;
	vector<int> arr(n);
	for (auto &i : arr)cin >> i;

	int m; cin >> m;

	int ans = beautifulSubarrays(arr, m);
	cout << ans << endl;

	return 0;
}
