#include<bits/stdc++.h>
using namespace std;

#define A(x) (x).begin(),(x).end()
#define sz(x) ((int)(x).size())
#define UNI(x) sort(A(x)); (x).erase(unique(A(x)),(x).end())
using i64 = long long;
void _read();


int main () { _read(); 

      int n;
      cin >> n;
      vector<int> ve = {-1};
      for(int i = 0; i < n; ++i) {
            int x; cin >> x;
            if(x & 1)
                  ve.push_back(i);
      }
      ve.push_back(n);
      int w; cin >> w;
      i64 ans = 0;
      for(int i = 1; i + w < sz(ve); ++i) {
            ans += 1LL * (ve[i] - ve[i - 1]) * (ve[i + w] - ve[i + w - 1]);
      }
      cout << ans << '\n';
      return 0;
};

void _read() {
      ios_base :: sync_with_stdio(false);
      cin.tie(NULL);
      #ifdef LOCAL
      freopen("input.txt","r",stdin);
      #endif
}
