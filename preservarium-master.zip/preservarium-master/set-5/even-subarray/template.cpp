#include <bits/stdc++.h>
using namespace std;


/*
 * Complete the 'evenSubarray' function below.
 *
 * The function is expected to return an INTEGER.
 * The function accepts following parameters:
 *  1. INTEGER_ARRAY numbers
 *  2. INTEGER k
 */

int evenSubarray(vector<int> numbers, int k) {

}

int main()
{
    int n; cin >> n;

    vector<int> a(n);
    for (auto &i : a)cin >> i;

    int k; cin >> k;

    int ans = evenSubarray(a, k);
    cout << ans << endl;
}