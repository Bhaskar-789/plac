#include <bits/stdc++.h>
using namespace std;


/*
 * Complete the 'evenSubarray' function below.
 *
 * The function is expected to return an INTEGER.
 * The function accepts following parameters:
 *  1. INTEGER_ARRAY numbers
 *  2. INTEGER k
 */

int evenSubarray(vector<int> nums, int k) {

    int n = nums.size();
    map<int, int> mp;
    int p = 263;
    int m = 1e9 + 9;

    for (int i = 0; i < n; i++) {

        int count = 0;
        long long power_of_p = 1;
        long long hash_val = 0;

        for (int j = i; j < n; j++) {
            hash_val = (hash_val + (nums[j]) * power_of_p) % m;
            power_of_p = (power_of_p * p) % m;

            if (nums[j] % 2)count++;

            if (count <= k)
                mp[hash_val]++;
        }

    }

    return (int)mp.size();
}

int main()
{
    int n; cin >> n;

    vector<int> a(n);
    for (auto &i : a)cin >> i;

    int k; cin >> k;

    int ans = evenSubarray(a, k);
    cout << ans << endl;
}