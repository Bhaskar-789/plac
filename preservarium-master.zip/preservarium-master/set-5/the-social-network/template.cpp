#include <bits/stdc++.h>
using namespace std;

/*
 * Complete the 'socialGraphs' function below.
 *
 * The function accepts INTEGER_ARRAY counts as parameter.
 */


void socialGraphs(vector<int> counts) {

}


int main()
{
    int counts_count; cin >> counts_count;

    vector<int> counts(counts_count);

    for (int i = 0; i < counts_count; i++) {
        int counts_item; cin >> counts_item;
        counts[i] = counts_item;
    }

    socialGraphs(counts);

    return 0;
}