#include <bits/stdc++.h>
using namespace std;

/*
 * Complete the 'maximalPermutation' function below.
 *
 * The function is expected to return an INTEGER_ARRAY.
 * The function accepts following parameters:
 *  1. INTEGER_ARRAY container
 *  2. INTEGER_ARRAY firstPositions
 *  3. INTEGER_ARRAY secondPositions
 *  4. INTEGER_ARRAY slides
 */


vector<int> maximalPermutation(vector<int> container, vector<int> firstPositions, vector<int> secondPositions, vector<int> slides) {



}


int main()
{
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);

    int n; cin >> n;

    vector<int> container(n);
    for (auto &i : container)cin >> i;

    int m; cin >> m;

    vector<int> firstPositions(m);
    for (auto &i : firstPositions)cin >> i;



    cin >> m;

    vector<int> secondPositions(m);
    for (auto &i : firstPositions)cin >> i;


    cin >> m;

    vector<int> slides(m);
    for (auto &i : firstPositions)cin >> i;


    auto ans = maximalPermutation(container, firstPositions, secondPositions, slides);

    for (auto i : ans)cout << i << endl;

}