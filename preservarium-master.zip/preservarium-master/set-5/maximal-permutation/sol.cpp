#include <bits/stdc++.h>
using namespace std;

/*
 * Complete the 'maximalPermutation' function below.
 *
 * The function is expected to return an INTEGER_ARRAY.
 * The function accepts following parameters:
 *  1. INTEGER_ARRAY container
 *  2. INTEGER_ARRAY firstPositions
 *  3. INTEGER_ARRAY secondPositions
 *  4. INTEGER_ARRAY slides
 */


const int N = 1e5 + 2;
vector<int> gr[N];
int vis[N];

vector<int> dfs(int curr)
{
    vector<int> out;
    out.push_back(curr);

    vis[curr] = 1;
    for (auto nxt : gr[curr]) {
        if (!vis[nxt]) {
            auto ret = dfs(nxt);
            for (auto i : ret)out.push_back(i);
        }
    }

    return out;
}

vector<int> maximalPermutation(vector<int> container, vector<int> firstPositions, vector<int> secondPositions, vector<int> slides) {


    int n = firstPositions.size();
    int m = container.size();

    for (int i = 0 ; i < n ; i++) {

        int u = (firstPositions[i] - slides[i]) % m;
        u = (u + m) % m ;
        int v = (secondPositions[i] + slides[i]) % m;

        gr[u].push_back(v);
        gr[v].push_back(u);
    }

    memset(vis, 0, sizeof(vis));

    vector<int> ans = container;

    for (int i = 0 ; i < container.size() ; i++) {
        if (!vis[i]) {
            auto curr = dfs(i);
            sort(curr.begin(), curr.end());
            vector<int> values;

            for (auto idx : curr)values.push_back(container[idx]);
            sort(values.begin(), values.end());
            reverse(values.begin(), values.end());

            for (int j = 0; j < curr.size(); j++) {
                ans[curr[j]] = values[j];
            }
        }
    }

    return ans;
}


int main()
{
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);

    int n; cin >> n;

    vector<int> container(n);
    for (auto &i : container)cin >> i;

    int m; cin >> m;

    vector<int> firstPositions(m);
    for (auto &i : firstPositions)cin >> i;



    cin >> m;

    vector<int> secondPositions(m);
    for (auto &i : firstPositions)cin >> i;


    cin >> m;

    vector<int> slides(m);
    for (auto &i : firstPositions)cin >> i;


    auto ans = maximalPermutation(container, firstPositions, secondPositions, slides);

    for (auto i : ans)cout << i << endl;

}