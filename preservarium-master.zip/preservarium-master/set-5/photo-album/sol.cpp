#include<bits/stdc++.h>
using namespace std;

#define A(x) (x).begin(),(x).end()
#define sz(x) ((int)(x).size())
#define UNI(x) sort(A(x)); (x).erase(unique(A(x)),(x).end())
using i64 = long long;
void _read();

struct fenwick {
      int n;
      vector<int> ft;
      fenwick(int _n) : n(_n), ft(n + 1) {};
      void update(int p, int x) {
            for(++p; p <= n; p += p & -p)
                  ft[p] += x;
      }
      int sum(int p) {
            int res = 0;
            ++p;
            while(p > 0) {
                  res += ft[p];
                  p -= (p & -p);
            }
            return res;
      }
};

int main () { _read(); 

      int n;
      cin >> n;
      vector<int> in(n), id(n);
      for(int &x : in)
            cin >> x;
      cin >> n;
      for(int &x : id)
            cin >> x;
      
      fenwick ft(n);
      vector<int> pos(n);
      for(int i = n - 1; i >= 0; --i) {
            int x = in[i];
            int p = x + ft.sum(x);
            pos[p] = id[i];
            ft.update(x, 1);
      }
      for(int &x : pos)
            cout << x << ' ';
      cout << '\n';
      return 0;
};

void _read() {
      ios_base :: sync_with_stdio(false);
      cin.tie(NULL);
      #ifdef LOCAL
      freopen("input.txt","r",stdin);
      #endif
}
