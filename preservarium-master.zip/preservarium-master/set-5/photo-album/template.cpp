#include<bits/stdc++.h>
using namespace std;


int photoAlbum(vector<int> index, vector<int> identity)
{

}

int main()
{

	ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);

	int n; cin >> n;
	vector<int> index(n);
	for (auto &i : index)cin >> i;

	cin >> n;

	vector<int> identity(n);
	for (auto &i : identity)cin >> i;


	int ans = photoAlbum(index, identity);
	cout << ans << endl;

	return 0;
}
