#include<iostream>
#include "testlib.h"
using namespace std;
/********************* Custom Inputs ***************************/
int n_low=1;
int n_high=1e5;
int val_low=-1e9;
int val_high=1e9;
/********************* Custom Inputs ***************************/
#define endl '\n'
void generate();
int main(int argc, char* argv[]){
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";

	if(type == "small"){
		n_high=10;
		val_low=-20;
		val_high=20;
	}

	if(type == "extreme"){
		n_low=n_high;
	}

	generate();
	return 0;
}
void generate(){
	int n=rnd.next(n_low,n_high);
	cout << n << endl;
	vector<int>a;
	while((int)a.size()!=n){
		a.push_back(rnd.next(val_low,val_high));
	}
	for(auto &ele : a) 
	cout << ele << " ";
}
