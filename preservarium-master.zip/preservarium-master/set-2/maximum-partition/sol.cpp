#include<bits/stdc++.h>
using namespace std;

int main () {

      int n;
      cin >> n;
      int nf = n;
      long long answer = 0;
      cin >> answer; n--;
      while(n--) {
            long long x;
            cin >> x;
            if(n == nf - 1) 
                  answer += x;
            else
                  answer += abs(x);
      }
      cout << answer << '\n';
      return 0;
};
