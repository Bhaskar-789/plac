# Maxmium Partition 

---

# Intuition

Note that, except for the first element, it is always possible to partition the given array such that all elements of the array have a positive contribution to the sum. This can be proven as follows: Consider array as blocks of positive and negative numbers.
There are two cases (`N` denotes the negative blocks and `P` denotes the positive blocks): 
- For configuration of type `P1 N1 P2 N2..`, put `P1` into first partition, `N1` in the second partition and so on. 
- For configuration of type `N1 P1 N2 P2..`, just put first element in the first partiton, and rest of the elements of `N1` as second partition. Distribute the remaining elements similar to the previous configuration. In case `N1` contains only 1 element, then group `N1 P1` as the first partition. Now `N1` and `P1` combined act as `P1` in the previous configuration.

So the final answer is `First element + sum(abs(Remaining Elements))`.

---

# Code
* [Setter's Solution](sol.cpp)

---
