# Pairwise Summation 

---

# Intuition
Note that the given sum is just sum of product of all pairs of `a_i` taken two at a time. This can be calculated as a difference of square of the sum with sum of the square(and is equal to `(sum(a_i))^2 - sum(a_i ^ 2)`). Thus for all queries of type 1, we have to calculate the above sum efficiently in `O(log N)`. This can be done by maintaining a data structure supporting range sum queries and point updates. Both Fenwick Tree and Segment Trees can be used for this. 
So we maintain two segment trees, one with array elements on it and other with square of the array elements on it. On receiving a type 1 query, the above expression can be calculated in `O(log N)`, and on recieving type 2 queries, we have to update the corresponding values in both segment trees.
Time complexity : `O(N log N + Q log N)`.
---

# Pseudocode
```cpp

segtree st1,st2;

for(int i=0;i<n;i++){
    int elm;
    cin>>elm;
    st1.update(i+1,elm);
    st2.update(i+1,elm*elm);
}

while(q--){
    int x;
    cin>>x;
    if(x==0){
        int l,r;
        cin>>l>>r;
        int z = st1.query(l,r);
        cout<<(z*z - st2.query(l,r))/2<<endl;
    }
    else{
        int x,v;
        cin>>x>>v;
        st1.update(x,v);
        st2.update(x,v*v);
    }
}
 
```

---

# Code
* [Setter's Solution](sol.cpp)

---
