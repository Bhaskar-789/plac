#include<bits/stdc++.h>
using namespace std;
void _read();

using i64 = long long;
template<typename T = int> struct fenwick {
    int n;
    vector<T> ft;
    vector<T> v;
    fenwick(int _n) : n(_n), ft(n + 1), v(n + 1) {};
    fenwick() {};
    void update(int p, T x) {
        ++p;
        x = x - v[p];
        v[p] += x;
        while(p <= n) {
            ft[p] += x;
            p += (p & -p);
        }
    }
    T sum(int p) {
        T res = 0;
        for(++p; p > 0; p -= (p & -p))
            res += ft[p];
        return res;
    }
};

class Solution {
    int n;
    vector<int> v;
    vector<fenwick<i64>> ft;
public:
    Solution(int _n) : n(_n), v(n), ft(2) {
          ft[0] = ft[1] = fenwick<i64>(n);
    };
    void getVec() {
        for(int i = 0; i < n; i++) {
              int x; cin >> x;
              v[i] = x;
              update(i, x);
        }
    }
    i64 getSum(int L, int R) {
        i64 r = ft[0].sum(R) - ft[0].sum(L - 1);
        r = r * r;
        r -= ft[1].sum(R) - ft[1].sum(L - 1);
        r >>= 1;
        return r;
    }
    void update(int p, i64 x) {
        ft[0].update(p, x);
        ft[1].update(p, x * x);
    }
};

int main () { _read();
    int n,q;
    cin >> n >> q;
    Solution S(n);
    S.getVec();
    while(q--) {
        int t; cin >> t;
        if(t) {
            int l,v;
            cin >> l >> v;
            S.update(l - 1, v);
        } else {
            int l, r;
            cin >> l >> r;
            cout << S.getSum(l - 1, r - 1) << '\n';
        }
    }
    return 0;
}

void _read() {
      ios_base :: sync_with_stdio(false);
      cin.tie(NULL);
      #ifdef LOCAL
      freopen("input.txt","r",stdin);
      #endif
}
