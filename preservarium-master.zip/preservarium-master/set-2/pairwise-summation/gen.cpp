#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int n_low = 1;
int n_high = 1e5;
int q_low = 1;
int q_high = 1e5;
int val_low = 1;
int val_high = 1e4;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();

int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
		n_high = 15;
		q_high = 7;
		val_high = 9;
	}

	if(type == "extreme") {
		n_low = n_high;
		q_low = q_high;
	}
	
	generate();

	return 0;
}

void generate()
{
	int n = rnd.next(n_low, n_high);
	int q = rnd.next(q_low, q_high);
	cout << n << " " << q << endl;

	for(int i = 0; i < n; i++) {
		cout << rnd.next(val_low, val_high) << " ";
	}

	for(int i = 0; i < q; i++) {
		int type = rnd.next(0, 1);
		if(i == q - 1) {
			type = 0;
		}
		cout << type << " ";

		if(type == 0) {
			int L = rnd.next(1, n);
			int R = rnd.next(1, n);
			if(L > R) {
				swap(L, R);
			}
			cout << L << " " << R << endl;
		}
		else {
			int X = rnd.next(1, n);
			cout << X << " ";
			cout << rnd.next(val_low, val_high) << endl;
		}
	}
}
