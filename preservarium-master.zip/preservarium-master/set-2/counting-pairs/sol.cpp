#include<bits/stdc++.h>
using namespace std;

#define A(x) (x).begin(),(x).end()
#define sz(x) ((int)(x).size())
#define UNI(x) sort(A(x)); (x).erase(unique(A(x)),(x).end())
using i64 = long long;
void _read();


struct Tree {
      int n;
      vector<vector<int>> adj;
      vector<int> co, vis;
      Tree(int _n) : n(_n), adj(n + 1), co(n + 1), vis(n + 1) {};
      void add_edge(int a, int b) {
            adj[a].push_back(b);
            adj[b].push_back(a);
      }
      void set(int i) { cin >> co[i]; };
      int get_size(int u) {
            if(vis[u] == 1 || co[u] == 1)
                  return 0;
            vis[u] = 1;
            int ret = 1;
            for(int v : adj[u])
                  ret += get_size(v);
            return ret;
      }

};

int main () { _read(); 

      int n;
      cin >> n;
      Tree T(n);
      for(int i = 0; i < n; i++)
            T.set(i + 1);
      for(int i = 1; i < n; ++i) {
            int a,b;
            cin >> a >> b;
            T.add_edge(a, b);
      }
      i64 ans = 0;
      i64 run = 0;
      for(int i = 1; i <= n; ++i) {
            int g = T.get_size(i);
            ans += g * run;
            run += g;
      }
      cout << ans << '\n';
      return 0;
};

void _read() {
      ios_base :: sync_with_stdio(false);
      cin.tie(NULL);
      #ifdef LOCAL
      freopen("input.txt","r",stdin);
      #endif
}

