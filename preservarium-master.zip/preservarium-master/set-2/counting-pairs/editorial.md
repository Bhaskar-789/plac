# Counting Pairs

---

# Intuition
Since a tree is connected, there exists a path between all pairs of black nodes `U` and `V`. To find the number of pairs with atleast one white node on a path between them, we can instead find the number of pairs of black nodes with only black nodes on the path between them, and subtract this number from the total number of pairs of black nodes. If there are `b` black nodes, then total number of pairs = `binom(b,2)`

Now, note that to find the number of black pairs having no white node on path between them, we can simply remove the white nodes from the tree. This results in a graph with multiple connected components, and any two nodes from the same component have a path between them with no white nodes on it. The number of nodes in a connected component can be easily found using `DFS`. 
The final ans is `binom(b,2) - sum(binom(c.size),2)`, where c.size is the size of a connected component in the resulting graph.

---

# Code
* [Setter's Solution](sol.cpp)
* [Editorialist's Solution](ed_sol.cpp)

---
