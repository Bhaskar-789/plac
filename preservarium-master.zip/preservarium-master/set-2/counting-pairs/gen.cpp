#include<iostream>
#include "testlib.h"
using namespace std;
/********************* Custom Inputs ***************************/
int n_low=1;
int n_high=2e5;
/********************* Custom Inputs ***************************/
#define endl '\n'
void generate();
int par[200005];
int find(int a){
    if(par[a]==a) return a;
    return par[a]=find(par[a]);
}
void merge(int a,int b){
    a=find(a);
    b=find(b);
    int minn=min(a,b);
    int maxx=max(a,b);
    par[maxx]=minn;
}
int main(int argc, char* argv[]){
    registerGen(argc, argv, 1);	
    string type = argc > 1 ? argv[1] : "unexpected";
	
    if(type=="small"){
        n_high=10;
    }
    else if(type=="extreme"){
        n_low=n_high;
    }

    generate();
    return 0;
}
void generate(){
    int n=rnd.next(n_low,n_high);
    cout<<n<<endl;
    vector<int>a;
    for(int i=0;i<n;i++){
        a.push_back(rnd.next(0,1));
    }
    for(auto &ele:a) cout<<ele<<" ";
    cout<<endl;
    set<pair<int,int>>s;
    for(int i=1;i<=n;i++) par[i]=i;
    while((int)s.size()!=n-1){
        pair<int,int>curr={rnd.next(1,n),rnd.next(1,n)};
        int u=find(curr.first);
        int v=find(curr.second);
        if(u!=v){
            merge(curr.first,curr.second);
            s.insert({curr.first,curr.second});
        }
    }
    for(auto x:s){
        cout<<x.first<<" "<<x.second<<endl;
    }
}
