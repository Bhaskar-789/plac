#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
#define int long long

void solve(){
    int n;
    cin>>n;
    vector<int> v(n);
    for (int i = 0; i < n; ++i)
    {
        cin>>v[i];
    }

    vector<vector<int>> adj(n);

    for(int i=0;i<n-1;i++){
        int a,b;
        cin>>a>>b;
        a--;b--;
        if(v[a] | v[b]) continue;
        adj[a].push_back(b);
        adj[b].push_back(a);
    }
    int b=n-accumulate(v.begin(),v.end(),0LL);
    int comp=0;
    vector<bool> vis(n,false);
    function<void(int)> dfs = [&](int v){
        if(vis[v])
            return;
        vis[v]=true;
        comp++;
        for(int to:adj[v]){
            if(!vis[to])
                dfs(to);
        }
    };   
    int ans=(b*(b-1))/2;
    for (int i = 0; i < n; ++i)
    {
        if(!vis[i]){
            dfs(i);
            ans-=(comp *(comp-1))/2;
            comp=0;
        }

    }

    cout<<ans<<endl;


    
 
}

int32_t main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.precision(17);
    int t=1;
    // cin>>t;
    while(t--)
    solve();

    return 0;
}