# Sub and Super Arrays. 

---

# Intuition

Note that any super array is a comibnation of two strictly increasing subarrays such that the ending element of first subarray is lesser than the starting element of second subarray, and the second subarray is ahead of first one. Let us first calculate two arrays:
- `inc_till[i]` : Contains the size of largest strictly increasing subarray ending at index `i`. Can be calculated in linear time easily by : `inc_till[i]=inc_till[i-1]+1 if arr[i] > arr[i-1] else inc_till[i]=1`.
- `inc_from[i]`: Similar to `inc_till[i]`, contains largest strictly increasing subarray starting from index `i`.

Now, the maximum size of super array would be `max(inc_till[i] + inc_from[j])` such that `i<j` and `v[i] < v[j]`. To calculate this efficiently for each `i`, we mantain a Segment Tree with max-range queries and point updates, in which at index `arr[i]`, we store`inc_from[i]`. So to find the maximum for any index `i`, we iterate the array in reverse, and for each index `i` we query the max value in the range from `arr[i]+1` to `max(arr[i])`. This gives the optimal `j` for each `i` in `O(log n)` per iteration. We get the final answer by taking maximum over all the indices.

Time complexity : `O(n log n)`. 

---

# Pseudocode
```py

for i in [1,n):
    if arr[i] > arr[i-1]:
        inc_till[i] = inc_till[i-1] + 1
segtree st
ans=0
inc_from[n-1]=1
for i in (n-1,1]:
    if arr[i] < arr[i+1]:
        inc_from[i] = inc_from[i+1] + 1
    else:
        inc_from[i] = 1
    v = st.query(arr[i]+1,max)
    if v is not zero:
        ans=max(ans,inc_till[i] + v)
    st.update(arr[i],inc_from[i])
```

---

# Code
* [Setter's Solution](sol.cpp)

---
