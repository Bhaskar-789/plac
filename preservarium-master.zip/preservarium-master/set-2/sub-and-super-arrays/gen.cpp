#include<iostream>
#include "testlib.h"
using namespace std;
/********************* Custom Inputs ***************************/
int n_low=1;
int n_high=1e5;
int val_low=1;
int val_high=1e5;
/********************* Custom Inputs ***************************/
#define endl '\n'
void generate();
void gen_small();
void gen_inc();
void gen_dec();
int main(int argc, char* argv[]){
  registerGen(argc, argv, 1);
  string type = argc > 1 ? argv[1] : "unexpected";

  if(type=="small"){
        n_high=10;
        val_high=50;
        gen_small();
  }

  if(type=="mixed"){
        generate();
  }

  if(type=="extreme"){
        n_low=n_high;
        generate();
  }
	
  if(type=="dec"){
        n_low=n_high;
        gen_dec();
  }

  if(type=="inc"){
        n_low=n_high;
        gen_inc();
  }

  return 0;
}

void gen_small(){
    int t=1;
    cout<<t<<endl;
    int n=rnd.next(n_low,n_high);
    cout<<n<<endl;
    vector<int>a;
    map<int,bool>mp;
    while((int)a.size()!=n){
        int curr=rnd.next(val_low,val_high);
        if(mp[curr]) ;
        else{
            mp[curr]=true;
            a.push_back(curr);
        }
    }
    for(auto &ele:a) cout<<ele<<" ";
    cout<<endl;
}

void generate(){
    int t=20;
    cout<<t<<endl;
    for(int i=1;i<=t;i++){
        int n=rnd.next(n_low,n_high);
        cout<<n<<endl;
        vector<int>a;
        map<int,bool>mp;
        while((int)a.size()!=n){
            int curr=rnd.next(val_low,val_high);
            if(mp[curr]) ;
            else{
                mp[curr]=true;
                a.push_back(curr);
            }
        }
        for(auto &ele:a) cout<<ele<<" ";
        cout<<endl;
    }
}

void gen_inc(){
    int t=20;
    cout<<t<<endl;
    for(int i=1;i<=t;i++){
        int n=rnd.next(n_low,n_high);
        cout<<n<<endl;
        set<int>a;
        while((int)a.size()!=n){
            a.insert(rnd.next(val_low,val_high));
        }
        for(auto &ele:a) cout<<ele<<" ";
        cout<<endl;
    }
}

void gen_dec(){
    int t=20;
    cout<<t<<endl;
    for(int i=1;i<=t;i++){
        int n=rnd.next(n_low,n_high);
        cout<<n<<endl;
        set<int>a;
        while((int)a.size()!=n){
            a.insert(rnd.next(val_low,val_high));
        }
        vector<int>hold;
        for(auto &ele:a) hold.push_back(ele);
        reverse(hold.begin(),hold.end());
        for(auto &ele:hold) cout<<ele<<" ";
        cout<<endl;
    }
}
