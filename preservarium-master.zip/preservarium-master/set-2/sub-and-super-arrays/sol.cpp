#include<bits/stdc++.h>
using namespace std;

#define A(x) (x).begin(),(x).end()
#define sz(x) ((int)(x).size())
#define UNI(x) sort(A(x)); (x).erase(unique(A(x)),(x).end())
using i64 = long long;
void _read();


void compress(vector<int> &v) {
      vector<int> b = v;
      sort(A(b));
      for(int &x : v)
            x = int(lower_bound(A(b), x) - b.begin());
}

struct fenwick {
      int n;
      vector<int> ft;
      fenwick(int _n) : n(_n), ft(_n + 1) {};
      fenwick() {};
      void update(int p, int x) {
            for(++p; p <= n; p += (p & -p)) {
                  ft[p] = max(x, ft[p]);
            }
      }
      int Max(int p) {
            int res = 0;
            for(++p; p > 0; p -= (p & -p)) {
                  res = max(res, ft[p]);
            }
            return res;
      }
};

struct Solution {
      int n;
      vector<int> v, r;
      vector<vector<int>> Q;
      Solution(int _n) : n(_n), v(_n), r(_n, 1), Q(n) {
            for(int &x : v)
                  cin >> x;
            compress(v);
            process();
      }
      void process() {
            for(int i = n - 2; i >= 0; i--) {
                  if(v[i] < v[i + 1])
                        r[i] = 1 + r[i + 1];
            }
      }
      int get_answer() {
            fenwick ft(n);
            int prev = 0;
            int ans = 1;
            for(int i = 0; i < n; i++) {
                  ans = max(ans, ft.Max(v[i] - 1) + r[i]);
                  int cur = 1 + (i > 0 && v[i] > v[i - 1]) * prev;
                  prev = cur;
                  ft.update(v[i], cur);
            }
            return ans == 1 ? 0 : ans;
      }

};

int main () { _read(); 

      int T;
      cin >> T;
      while(T--) {
            int n;
            cin >> n;
            cout << Solution(n).get_answer() << '\n';
      }
      return 0;
};

void _read() {
      ios_base :: sync_with_stdio(false);
      cin.tie(NULL);
      #ifdef LOCAL
      freopen("input.txt","r",stdin);
      #endif
}
