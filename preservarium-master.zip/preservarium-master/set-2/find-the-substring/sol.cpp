#include <bits/stdc++.h>
using namespace std;
/*
Not sure if it is correct though -- someone can recheck
*/
vector<int> pref_func(string s){
	vector<int> lp(s.size(), 0);
	int i = 1;
	int k = 0;
	while(i < s.size()){
		if(s[i] == '$'){
			lp[i] = 0;
			k = 0;
			i++;
			continue;
		}
		if(s[i] == s[k] || s[k] == '*'){
			lp[i] = ++k;
			i++;
		}
		else{
			if(k == 0){
				lp[i] = 0;
				i++;
			}else{
				k = lp[k - 1];
			}
		}
	}
	return lp;
}

void solve(){
	string s, x; cin >> s >> x;
	int res = 0;
	string t = x + "$" + s;
	vector<int> lp = pref_func(t);
	int i;
	for(i = 0; i < (int)lp.size(); i++){
		if(lp[i] == (int)x.size()){
			break;
		}
	}
	if(i < lp.size()){
		cout << i - 2 * (int)x.size() << "\n";
	}else{
		cout << -1 << "\n";
	}
}

int main(){
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	solve();
}
