#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int text_len_low = 1;
int text_len_high = 5*(int)1e5;
int pat_len_low = 1;
int pat_len_high = 1e3;
int alpha_size_low = 1;
int alpha_size_high = 26;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();

int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
		text_len_high = 20;
		pat_len_high = 5;
		alpha_size_high = 3;
	}

	if(type == "mixed") {
		alpha_size_high = 4;
	}

	if(type == "extreme") {
		text_len_low = text_len_high;
		pat_len_low = pat_len_high;
		alpha_size_high = 6;
	}

	//TODO : Refine it
	if(type == "tle") {
		alpha_size_high = 2;
		text_len_low = text_len_high;
	}

	if(type == "minus_one") {
	}

	generate();
	return 0;
}

string create_str(int alpha_size, int len) {
	string str = "";
	for(int i = 0; i < len; i++) {
		str += rnd.next('a', 'a' + alpha_size - 1);
	}
	return str;
}

void generate()
{
	int text_len = rnd.next(text_len_low, text_len_high);
	int pat_len = rnd.next(pat_len_low, pat_len_high);
	if(pat_len >= text_len) {
		pat_len = rnd.next(1, text_len);
	}

	int alpha_size = rnd.next(alpha_size_low, alpha_size_high);
	auto text = create_str(alpha_size, text_len);
	auto pattern = create_str(alpha_size, pat_len);

	/* Make a random character as wildcard character */
	int index = rnd.next(0, (int)pat_len - 1);
	pattern[index] = '*';

	cout << text << endl;
	cout << pattern << endl;
}
