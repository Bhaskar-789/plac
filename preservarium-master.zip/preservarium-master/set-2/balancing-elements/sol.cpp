#include<bits/stdc++.h>
using namespace std;

#define A(x) (x).begin(),(x).end()
#define sz(x) ((int)(x).size())
#define UNI(x) sort(A(x)); (x).erase(unique(A(x)),(x).end())
using i64 = long long;
void _read();


int main () { _read(); 

      int n;
      cin >> n;
      if(n == 1) {
            return cout << "0\n", 0;
      }
      vector<int> v(n);
      for(int &x : v) {
            cin >> x;
      }
      vector<int> p_odd(n), p_even(n), s_odd(n), s_even(n);
      p_even[0] = v[0];
      for(int i = 1; i < n; ++i) {
            p_even[i] = p_even[i - 1] + (i & 1 ^ 1) * v[i];
            p_odd[i] = p_odd[i - 1] + (i & 1) * v[i];
      }
      (n & 1 ? s_even[n - 1] : s_odd[n - 1]) = v.back();
      for(int i = n - 2; i >= 0; i--) {
            s_even[i] = s_even[i + 1] + (i & 1 ^ 1) * v[i];
            s_odd[i] = s_odd[i + 1] + (i & 1) * v[i];
      }
      int ans = (p_odd[n - 2] == p_even[n - 2]) + (s_odd[1] == s_even[1]);
      for(int i = 1; i + 1 < n; ++i) {
            ans += (p_odd[i - 1] + s_even[i + 1]) == (p_even[i - 1] + s_odd[i + 1]);
      }
      cout << ans << '\n';
      return 0;
};

void _read() {
      ios_base :: sync_with_stdio(false);
      cin.tie(NULL);
      #ifdef LOCAL
      freopen("input.txt","r",stdin);
      #endif
}
