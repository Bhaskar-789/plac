#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pii> vii;
typedef vector<vi> vvi;
typedef vector<pll> vll;
typedef vector<vl> vvl;

#define fori(i, n) for (int i = 0; i < n; i++)
#define ford(i, n) for (int i = n - 1; i >= 0; i--)
#define rep(i, a, b) for (int i = a; i <= b; i++)
#define repd(i, a, b) for (int i = a; i >= b; i--)
#define trav(x, a) for (auto &x : a)
#define all(x) (x).begin(), (x).end()
#define pb push_back
#define eb emplace_back
#define endl '\n'
#define sz(a) (int)(a).size()
#define fi first
#define se second

clock_t time_p = clock();
void time_taken()
{
    time_p = clock() - time_p;
    cerr << "Time Taken : " << (float)(time_p) / CLOCKS_PER_SEC << "\n";
}

const ll mod = 1e9 + 7;
const ll INF = 1e18;

ll modinv(ll a, ll m)
{
    assert(m > 0);
    if (m == 1)
        return 0;
    a %= m;
    if (a < 0)
        a += m;
    assert(a != 0);
    if (a == 1)
        return 1;
    return m - modinv(m, a) * m / a;
}

template <int MOD_>
struct modnum
{
private:
    int v;

public:
    static const int MOD = MOD_;

    modnum() : v(0) {}
    modnum(ll v_) : v(int(v_ % MOD))
    {
        if (v < 0)
            v += MOD;
    }
    explicit operator int() const { return v; }
    friend bool operator==(const modnum &a, const modnum &b) { return a.v == b.v; }
    friend bool operator!=(const modnum &a, const modnum &b) { return a.v != b.v; }

    modnum operator~() const
    {
        modnum res;
        res.v = modinv(v, MOD);
        return res;
    }

    modnum &operator+=(const modnum &o)
    {
        v += o.v;
        if (v >= MOD)
            v -= MOD;
        return *this;
    }
    modnum &operator-=(const modnum &o)
    {
        v -= o.v;
        if (v < 0)
            v += MOD;
        return *this;
    }
    modnum &operator*=(const modnum &o)
    {
        v = int(ll(v) * ll(o.v) % MOD);
        return *this;
    }
    modnum &operator/=(const modnum &o)
    {
        return *this *= (~o);
    }

    friend modnum operator+(const modnum &a, const modnum &b) { return modnum(a) += b; }
    friend modnum operator-(const modnum &a, const modnum &b) { return modnum(a) -= b; }
    friend modnum operator*(const modnum &a, const modnum &b) { return modnum(a) *= b; }
    friend modnum operator/(const modnum &a, const modnum &b) { return modnum(a) /= b; }
};

using num = modnum<mod>;

vector<num> fact;
vector<num> ifact;

void init()
{
    fact = {1};
    for (int i = 1; i < 300005; i++)
        fact.push_back(i * fact[i - 1]);
    for (num x : fact)
        ifact.push_back(1 / x);
}

num ncr(int n, int k)
{
    if (k < 0 || k > n)
        return 0;
    return fact[n] * ifact[k] * ifact[n - k];
}

num powmod(num x, int a)
{
    if (a == 0)
        return 1;
    if (a & 1)
        return x * powmod(x, a - 1);
    return powmod(x * x, a / 2);
}

int main()
{
    ios_base::sync_with_stdio(false), cin.tie(nullptr);

    int n;
    cin >> n;

    vi a(n - 1);
    fori(i, n - 1) cin >> a[i];

    if (n == 2)
    {
        cout << 1 << endl;
        return 0;
    }

    cout << int(powmod(a[n - 3], n / 2 - 1) * a[n - 2]) << endl;

    time_taken();
    return 0;
}