#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pii> vii;
typedef vector<vi> vvi;
typedef vector<pll> vll;
typedef vector<vl> vvl;

#define fori(i, n) for (int i = 0; i < n; i++)
#define ford(i, n) for (int i = n - 1; i >= 0; i--)
#define rep(i, a, b) for (int i = a; i <= b; i++)
#define repd(i, a, b) for (int i = a; i >= b; i--)
#define trav(x, a) for (auto &x : a)
#define all(x) (x).begin(), (x).end()
#define pb push_back
#define eb emplace_back
#define endl '\n'
#define sz(a) (int)(a).size()
#define fi first
#define se second

clock_t time_p = clock();
void time_taken()
{
    time_p = clock() - time_p;
    cerr << "Time Taken : " << (float)(time_p) / CLOCKS_PER_SEC << "\n";
}

const ll mod = 1e9 + 7;
const ll INF = 1e18;

void solve()
{
    int n, k, m;
    cin >> n >> k >> m;

    vvi a(n, vi(n));
    fori(i, n) fori(j, n) cin >> a[i][j];

    vvi row_mx(n, vi(n - k + 1));
    fori(i, n)
    {
        deque<int> q;
        fori(j, k - 1)
        {
            while (!q.empty() and a[i][q.back()] <= a[i][j])
            {
                q.pop_back();
            }
            q.push_back(j);
        }

        for (int j = k - 1; j < n; j++)
        {
            while (!q.empty() and a[i][q.back()] <= a[i][j])
            {
                q.pop_back();
            }
            q.push_back(j);
            row_mx[i][j - k + 1] = a[i][q.front()];
            if (q.front() == j - k + 1)
            {
                q.pop_front();
            }
        }
    }

    vi foo;
    fori(j, n - k + 1)
    {
        deque<int> q;
        fori(i, k - 1)
        {
            while (!q.empty() and row_mx[q.back()][j] <= row_mx[i][j])
            {
                q.pop_back();
            }
            q.push_back(i);
        }
        for (int i = k - 1; i < n; i++)
        {
            while (!q.empty() and row_mx[q.back()][j] <= row_mx[i][j])
            {
                q.pop_back();
            }
            q.push_back(i);
            foo.pb(row_mx[q.front()][j]);
            if (q.front() == i - k + 1)
            {
                q.pop_front();
            }
        }
    }
    sort(all(foo));
    cout << foo.end() - upper_bound(all(foo), m) << ' ' << *lower_bound(all(foo), m) << ' ' << foo.back() << endl;
}

int main()
{
    ios_base::sync_with_stdio(false), cin.tie(nullptr);

    int t;
    cin >> t;

    while (t--)
    {
        solve();
    }

    time_taken();
    return 0;
}