#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pii> vii;
typedef vector<vi> vvi;
typedef vector<pll> vll;
typedef vector<vl> vvl;

#define fori(i, n) for (int i = 0; i < n; i++)
#define ford(i, n) for (int i = n - 1; i >= 0; i--)
#define rep(i, a, b) for (int i = a; i <= b; i++)
#define repd(i, a, b) for (int i = a; i >= b; i--)
#define trav(x, a) for (auto &x : a)
#define all(x) (x).begin(), (x).end()
#define pb push_back
#define eb emplace_back
#define endl '\n'
#define sz(a) (int)(a).size()
#define fi first
#define se second

clock_t time_p = clock();
void time_taken()
{
    time_p = clock() - time_p;
    cerr << "Time Taken : " << (float)(time_p) / CLOCKS_PER_SEC << "\n";
}

const ll mod = 1e9 + 7;
const ll INF = 1e18;

const int N = 46;
bool vis[N][N][64][N][2];
int dp[N][N][64][N][2];

int main()
{
    ios_base::sync_with_stdio(false), cin.tie(nullptr);

    string s;
    ll k;
    cin >> s >> k;

    if (k > 63)
    {
        cout << -1 << endl;
        return 0;
    }

    int n = sz(s);
    vi one, zero;
    fori(i, n)
    {
        if (s[i] == '0')
        {
            zero.pb(i);
        }
        else
            one.pb(i);
    }

    function<int(int, int, int, int, int)> f = [&](int ones, int zeroes, int cur_xor, int lastlen, int lastchar) -> int
    {
        if (ones + zeroes == sz(s))
        {
            if (cur_xor == k)
            {
                return 0;
            }
            else
                return mod;
        }

        int &ans = dp[ones][zeroes][cur_xor][lastlen][lastchar];
        bool &visited = vis[ones][zeroes][cur_xor][lastlen][lastchar];
        if (visited)
            return ans;

        visited = 1;
        ans = mod;
        if (ones < sz(one))
        {
            int cost = max(one[ones] - (ones + zeroes), 0);
            if (lastchar == 1)
            {
                ans = min(ans, cost + f(ones + 1, zeroes, cur_xor ^ lastlen ^ (lastlen + 1), lastlen + 1, lastchar));
            }
            else
            {
                ans = min(ans, cost + f(ones + 1, zeroes, cur_xor ^ 1, 1, 1));
            }
        }
        if (zeroes < sz(zero))
        {
            int cost = max(zero[zeroes] - (ones + zeroes), 0);
            if (lastchar == 0)
            {
                ans = min(ans, cost + f(ones, zeroes + 1, cur_xor ^ lastlen ^ (lastlen + 1), lastlen + 1, lastchar));
            }
            else
            {
                ans = min(ans, cost + f(ones, zeroes + 1, cur_xor ^ 1, 1, 0));
            }
        }
        return ans;
    };

    int res = f(0, 0, 0, 0, 0);
    if (res > n * (n - 1))
        res = -1;

    cout << res << endl;

    time_taken();
    return 0;
}
