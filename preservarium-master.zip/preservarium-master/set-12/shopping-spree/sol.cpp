#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pii> vii;
typedef vector<vi> vvi;
typedef vector<pll> vll;
typedef vector<vl> vvl;

#define fori(i, n) for (int i = 0; i < n; i++)
#define ford(i, n) for (int i = n - 1; i >= 0; i--)
#define rep(i, a, b) for (int i = a; i <= b; i++)
#define repd(i, a, b) for (int i = a; i >= b; i--)
#define trav(x, a) for (auto &x : a)
#define all(x) (x).begin(), (x).end()
#define pb push_back
#define eb emplace_back
#define endl '\n'
#define sz(a) (int)(a).size()
#define fi first
#define se second

clock_t time_p = clock();
void time_taken()
{
    time_p = clock() - time_p;
    cerr << "Time Taken : " << (float)(time_p) / CLOCKS_PER_SEC << "\n";
}

const ll mod = 1e9 + 7;
const ll INF = 1e18;

ll modinv(ll a, ll m)
{
    assert(m > 0);
    if (m == 1)
        return 0;
    a %= m;
    if (a < 0)
        a += m;
    assert(a != 0);
    if (a == 1)
        return 1;
    return m - modinv(m, a) * m / a;
}

template <int MOD_>
struct modnum
{
private:
    int v;

public:
    static const int MOD = MOD_;

    modnum() : v(0) {}
    modnum(ll v_) : v(int(v_ % MOD))
    {
        if (v < 0)
            v += MOD;
    }
    explicit operator int() const { return v; }
    friend bool operator==(const modnum &a, const modnum &b) { return a.v == b.v; }
    friend bool operator!=(const modnum &a, const modnum &b) { return a.v != b.v; }

    modnum operator~() const
    {
        modnum res;
        res.v = modinv(v, MOD);
        return res;
    }

    modnum &operator+=(const modnum &o)
    {
        v += o.v;
        if (v >= MOD)
            v -= MOD;
        return *this;
    }
    modnum &operator-=(const modnum &o)
    {
        v -= o.v;
        if (v < 0)
            v += MOD;
        return *this;
    }
    modnum &operator*=(const modnum &o)
    {
        v = int(ll(v) * ll(o.v) % MOD);
        return *this;
    }
    modnum &operator/=(const modnum &o)
    {
        return *this *= (~o);
    }

    friend modnum operator+(const modnum &a, const modnum &b) { return modnum(a) += b; }
    friend modnum operator-(const modnum &a, const modnum &b) { return modnum(a) -= b; }
    friend modnum operator*(const modnum &a, const modnum &b) { return modnum(a) *= b; }
    friend modnum operator/(const modnum &a, const modnum &b) { return modnum(a) /= b; }
};

using num = modnum<mod>;

vector<num> fact;
vector<num> ifact;

void init()
{
    fact = {1};
    for (int i = 1; i < 300005; i++)
        fact.push_back(i * fact[i - 1]);
    for (num x : fact)
        ifact.push_back(1 / x);
}

num ncr(int n, int k)
{
    if (k < 0 || k > n)
        return 0;
    return fact[n] * ifact[k] * ifact[n - k];
}

num powmod(num x, int a)
{
    if (a == 0)
        return 1;
    if (a & 1)
        return x * powmod(x, a - 1);
    return powmod(x * x, a / 2);
}

int main()
{
    ios_base::sync_with_stdio(false), cin.tie(nullptr);

    int n, k, q;
    cin >> n >> k >> q;

    vvi cost(n, vi(k));
    fori(i, n) fori(j, k) cin >> cost[i][j];

    vvi adj(n);
    fori(_, n - 1)
    {
        int u, v;
        cin >> u >> v, --u, --v;
        adj[u].pb(v);
        adj[v].pb(u);
    }

    struct node
    {
        int k;
        vi mn, cnt;
        node(int _k) : k(_k)
        {
            mn = vi(k, mod);
            cnt = vi(k, 1);
        }
        node(int _k, vi &costs) : k(_k)
        {
            mn = costs;
            cnt = vi(k, 1);
        }

        void merge(const node &a, const node &b)
        {
            fori(i, k)
            {
                if (a.mn[i] < b.mn[i])
                {
                    mn[i] = a.mn[i];
                    cnt[i] = a.cnt[i];
                }
                else if (b.mn[i] < a.mn[i])
                {
                    mn[i] = b.mn[i];
                    cnt[i] = b.cnt[i];
                }
                else
                {
                    mn[i] = a.mn[i];
                    cnt[i] = a.cnt[i] + b.cnt[i];
                }
            }
        }
    };

    vi tin(n), tout(n), inv(n);
    int t = 0;
    function<void(int, int)> dfs = [&](int u, int p) -> void
    {
        tin[u] = t++;
        inv[t - 1] = u;
        for (int v : adj[u])
        {
            if (v == p)
                continue;
            dfs(v, u);
        }
        tout[u] = t - 1;
    };

    dfs(0, -1);

    vector<node> st(4 * n + 10, node(k));

    function<void(int, int, int)> build = [&](int v, int l, int r) -> void
    {
        if (l == r)
        {
            st[v] = node(k, cost[inv[l]]);
            return;
        }
        int mid = (l + r) / 2;
        build(2 * v, l, mid);
        build(2 * v + 1, mid + 1, r);
        st[v].merge(st[2 * v], st[2 * v + 1]);
    };

    build(1, 0, n - 1);

    function<void(int, int, int, int)> upd = [&](int v, int l, int r, int pos) -> void
    {
        if (pos < l or pos > r)
            return;
        if (pos == l and pos == r)
        {
            st[v] = node(k, cost[inv[l]]);
            return;
        }
        int mid = (l + r) / 2;
        upd(2 * v, l, mid, pos);
        upd(2 * v + 1, mid + 1, r, pos);
        st[v].merge(st[2 * v], st[2 * v + 1]);
    };

    function<node(int, int, int, int, int)> qry = [&](int v, int l, int r, int ql, int qr) -> node
    {
        if (l >= ql and r <= qr)
            return st[v];
        int mid = (l + r) / 2;
        node res(k);
        if (ql <= mid)
            res = qry(2 * v, l, mid, ql, qr);
        if (qr > mid)
        {
            node foo = qry(2 * v + 1, mid + 1, r, ql, qr);
            res.merge(res, foo);
        }
        return res;
    };

    while (q--)
    {
        int typ;
        cin >> typ;

        if (typ == 1)
        {
            int v;
            cin >> v, --v;
            node foo = qry(1, 0, n - 1, tin[v], tout[v]);
            num ways = 1;
            ll mn_cost = 0;
            fori(i, k)
            {
                mn_cost += foo.mn[i];
                ways *= foo.cnt[i];
            }
            cout << mn_cost << ' ' << int(ways) << endl;
        }
        else
        {
            int v, i, val;
            cin >> v >> i >> val, --i, --v;
            cost[v][i] = val;
            upd(1, 0, n - 1, tin[v]);
        }
    }

    time_taken();
    return 0;
}