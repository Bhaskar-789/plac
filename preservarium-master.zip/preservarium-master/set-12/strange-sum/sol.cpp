#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pii> vii;
typedef vector<vi> vvi;
typedef vector<pll> vll;
typedef vector<vl> vvl;

#define fori(i, n) for (int i = 0; i < n; i++)
#define ford(i, n) for (int i = n - 1; i >= 0; i--)
#define rep(i, a, b) for (int i = a; i <= b; i++)
#define repd(i, a, b) for (int i = a; i >= b; i--)
#define trav(x, a) for (auto &x : a)
#define all(x) (x).begin(), (x).end()
#define pb push_back
#define eb emplace_back
#define endl '\n'
#define sz(a) (int)(a).size()
#define fi first
#define se second

clock_t time_p = clock();
void time_taken()
{
    time_p = clock() - time_p;
    cerr << "Time Taken : " << (float)(time_p) / CLOCKS_PER_SEC << "\n";
}

const ll mod = 1e9 + 7;
const ll INF = 1e18;

template <typename T>
class BIT
{
public:
    int n;
    vector<T> data;

    BIT(int _n) : n(_n)
    {
        data.assign(n, static_cast<T>(0));
    }

    void upd(int x, T v)
    {
        while (x < n)
        {
            data[x] += v;
            x |= (x + 1);
        }
    }

    T get(int x)
    {
        T ans = 0;
        while (x >= 0)
        {
            ans += data[x];
            x = (x & (x + 1)) - 1;
        }
        return ans;
    }
};

int main()
{
    ios_base::sync_with_stdio(false), cin.tie(nullptr);

    int n, q;
    cin >> n >> q;

    BIT<ll> B1(n), B2(n);
    vl a(n);
    fori(i, n)
    {
        cin >> a[i];
        B1.upd(i, i * a[i]);
        B2.upd(i, a[i]);
    }

    fori(_, q)
    {
        int t;
        cin >> t;

        if (t == 1)
        {
            int idx, val;
            cin >> idx >> val, --idx;
            B1.upd(idx, -idx * a[idx]);
            B2.upd(idx, -a[idx]);
            a[idx] = val;
            B1.upd(idx, idx * a[idx]);
            B2.upd(idx, a[idx]);
        }
        else
        {
            int l, r;
            cin >> l >> r, --l, --r;
            cout << B1.get(r) - B1.get(l - 1) - (l - 1) * (B2.get(r) - B2.get(l - 1)) << endl;
        }
    }

    time_taken();
    return 0;
}