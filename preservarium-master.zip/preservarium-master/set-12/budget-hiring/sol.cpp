#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pii> vii;
typedef vector<vi> vvi;
typedef vector<pll> vll;
typedef vector<vl> vvl;

#define fori(i, n) for (int i = 0; i < n; i++)
#define ford(i, n) for (int i = n - 1; i >= 0; i--)
#define rep(i, a, b) for (int i = a; i <= b; i++)
#define repd(i, a, b) for (int i = a; i >= b; i--)
#define trav(x, a) for (auto &x : a)
#define all(x) (x).begin(), (x).end()
#define pb push_back
#define eb emplace_back
#define endl '\n'
#define sz(a) (int)(a).size()
#define fi first
#define se second

clock_t time_p = clock();
void time_taken()
{
    time_p = clock() - time_p;
    cerr << "Time Taken : " << (float)(time_p) / CLOCKS_PER_SEC << "\n";
}

const ll mod = 1e9 + 7;
const ll INF = 1e18;

int main()
{
    ios_base::sync_with_stdio(false), cin.tie(nullptr);

    int n, _;
    cin >> n >> _;

    vi par(n, -1), sal(n), skill(n);

    fori(i, n)
    {
        cin >> skill[i] >> sal[i];
    }

    function<int(int)> get = [&](int x) -> int
    {
        if (par[x] < 0)
            return x;
        return par[x] = get(par[x]);
    };

    auto merge = [&](int x, int y) -> bool
    {
        x = get(x);
        y = get(y);

        if (x == y)
            return false;

        if (par[x] > par[y])
            swap(x, y);

        par[x] += par[y];
        sal[x] += sal[y];
        skill[x] += skill[y];
        par[y] = x;
        return true;
    };

    int q;
    cin >> q >> _;

    while (q--)
    {
        int x, y;
        cin >> x >> y, --x, --y;
        merge(x, y);
    }

    int B;
    cin >> B;

    vi dp(B + 1);
    fori(i, n)
    {
        if (par[i] >= 0)
            continue;
        int U = skill[i];
        int V = sal[i];
        for (int j = B; j >= 0; j--)
        {
            if (j + V <= B)
            {
                dp[j + V] = max(dp[j + V], dp[j] + U);
            }
        }
    }

    cout << *max_element(all(dp)) << endl;

    time_taken();
    return 0;
}