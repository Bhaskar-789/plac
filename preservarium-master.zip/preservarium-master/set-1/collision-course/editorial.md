# Collision Course  

---

# Intuition
Since the collision does not change any particle's speed or direction, a particle will collide with every other particle at-most once. Now, let us assume that the particle starting from the `i-th` position at time `t = 0`, is represented by `p[i]` and its speed is given by `speed[i]`. Therefore, `p[pos]` will only collide with the following particles:  

- Particles starting before `pos` and having speed greater than `p[pos]`, i.e. `speed[j] > speed[pos]`, for `j < pos`.
- Particles starting after `pos` and having speed less than `p[pos]`, i.e. `speed[j] < speed[pos]`, for `j > pos`. 

This can be calculated in `O(n)` time, where `n` is the number of particles.  

---

# Pseudocode
```py
ans = 0  
for i in [1, pos):  
    if(speed[i] > speed[pos]) ans += 1

for i in [pos - 1, n]:  
    if(speed[i] < speed[pos]) ans += 1
```

---

# Code
* [Setter's Solution](sol.cpp)

---
