#include<bits/stdc++.h>
using namespace std;
#define int long long 
bool isRobotBounded(string instructions) {
    int x = 0, y = 0, i = 0;
    vector<vector<int>> d = {{0, 1}, {1, 0}, {0, -1}, { -1, 0}};
    for (char & ins : instructions)
        if (ins == 'R')
            i = (i + 1) % 4;
        else if (ins == 'L')
            i = (i + 3) % 4;
        else
            x += d[i][0], y += d[i][1];
    return x == 0 && y == 0 || i > 0;
}
void solve(){
    int n;cin>>n;
    for(int i=0;i<n;i++){
        string s;cin>>s;
        if(isRobotBounded(s)) cout<<"YES\n";
        else cout<<"NO\n";
    }
}  
int32_t main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    int T=1;
    while(T--){
        solve();
    }
    return 0;
}