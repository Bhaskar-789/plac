/******************READ-ONLY PART BEGINS*****************/
#include <bits/stdc++.h>
using namespace std;
/*******************READ-ONLY PART ENDS******************/

vector<string> doesCircleExist(vector<string> commands) {
}

/******************READ-ONLY PART BEGINS*****************/
int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);

	int n; cin >> n;
	vector<string> commands(n);
	for(auto &ele : commands) {
		cin >> ele;
	}

	auto res = doesCircleExist(commands);
	for(auto &ele : res) {
		cout << ele << "\n";
	}

	return 0;
}
/*******************READ-ONLY PART ENDS******************/
