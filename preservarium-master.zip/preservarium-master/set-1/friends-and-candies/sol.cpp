#include<bits/stdc++.h>
using namespace std;

#define A(x) (x).begin(),(x).end()
#define sz(x) ((int)(x).size())
#define UNI(x) sort(A(x)); (x).erase(unique(A(x)),(x).end())
using i64 = long long;
void _read();

const int INF = (1 << 27);
int get_answer(const vector<pair<int,int>> &vec, int C) {
      vector<int> dp(C + 1, -INF);
      dp[0] = 0;
      for(auto &[cost, cnt] : vec) {
            auto DP = dp;
            for(int pr = 0; pr + cost <= C; ++pr) {
                  DP[pr + cost] = max(dp[pr + cost], dp[pr] + cnt);
            }
            dp = DP;
      }
      return * max_element(A(dp));
}

int main () { _read(); 

      int n,C;
      cin >> n >> C;
      vector<int> cost(n + 1);
      for(int i = 1; i <= n; ++i)
            cin >> cost[i];
      int M;
      cin >> M;
      vector<vector<int>> adj(n + 1);
      while(M--) {
            int a,b;
            cin >> a >> b;
            adj[a].push_back(b);
            adj[b].push_back(a);
      }
      vector<pair<int,int>> cmp;
      vector<int> vis(n + 1);
      int ct = 0;
      int cnt = 0;
      function<void(int)> dfs = [&](int u) {
            vis[u] = 1;
            ct += cost[u];
            cnt++;
            for(int v : adj[u]) if(!vis[v]) {
                  dfs(v);
            }
      };
      for(int i = 1; i <= n; i++) if(!vis[i]) {
            ct = 0;
            cnt = 0;
            dfs(i);
            cmp.emplace_back(ct, cnt);
      }
      cout << get_answer(cmp, C) << '\n';
      return 0;
};

void _read() {
      ios_base :: sync_with_stdio(false);
      cin.tie(NULL);
      #ifdef LOCAL
      freopen("input.txt","r",stdin);
      #endif
}
