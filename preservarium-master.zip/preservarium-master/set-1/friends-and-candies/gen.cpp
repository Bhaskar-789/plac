#include <iostream>
#include "testlib.h"

using namespace std;

/********************* Custom Inputs ***************************/
int n_low = 1;
int n_high = 1e3;
int val_low = 1;
int val_high = 1e3;
int c_low = 1;
int c_high = 1e5;
int m_low = 0;
int m_high = 1e4 ;
/********************* Custom Inputs ***************************/

#define endl '\n'
void generate();

pair<int, int> gen_edge(int n)
{
	int x = rnd.next(1, n);
	int y = rnd.next(1, n);

	while (x == y)
	{
		x = rnd.next(1, n);
		y = rnd.next(1, n);
	}

	return make_pair(min(x, y), max(x, y));
}



int main(int argc, char* argv[])
{
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";
	
	if(type == "small") {
		n_high = 10;
		val_high = 9;
		c_high = 10;
		m_high = 5;
	}

	if(type == "extreme") {
		n_low = n_high;
		val_low = 1e2;
		c_low  = 1e3;
		m_low = 1e3;

	}
	
	generate();

	return 0;
}

void generate()
{
	int n = rnd.next(n_low, n_high);
	int c = rnd.next(c_low, c_high);
	vector<int> a(n);
	for(auto &ele : a) {
		ele = rnd.next(val_low, val_high);
	}
    
	
    int m = rnd.next(m_low, m_high);



	set<pair<int, int>> edge_set;

    if(m) {
		while (edge_set.size() != m)
		{
			edge_set.insert(gen_edge(n));
		}
	}

	cout << n << " " << c << endl;
	for(auto &ele : a) {
		cout << ele << " ";
	}
    cout<<endl<<m<<endl;
    if(m) {
		for (auto ele : edge_set)
		{
			cout << ele.first << " " << ele.second;
			cout << endl;
		}
	}
	cout << endl;
}