/******************READ-ONLY PART BEGINS*****************/
#include <bits/stdc++.h>
using namespace std;
/*******************READ-ONLY PART ENDS******************/

long long carParkingRoof(vector<long long> cars, int k) {
	sort(cars.begin(), cars.end());
	int n = cars.size();

	deque<long long> dq;

	// Add first "k" cars in the window.
	for(int i = 0; i < k; i++) {
		dq.push_back(cars[i]);
	}

	// |[a, b]| = b - a + 1
	long long min_cover = dq.back() - dq.front() + 1;

	// Add the latest car, remove the oldest.
	for(int i = k; i < n; i++) {
		dq.pop_front();
		dq.push_back(cars[i]);
		min_cover = min(min_cover, dq.back() - dq.front() + 1);
	}
	return min_cover;	
}

/******************READ-ONLY PART BEGINS*****************/
int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);

	int n; cin >> n;
	vector<long long> cars(n);
	for(auto &ele : cars) {
		cin >> ele;
	}
	int k; cin >> k;

	auto res = carParkingRoof(cars, k);
	cout << res << endl;

	return 0;
}
/*******************READ-ONLY PART ENDS******************/
