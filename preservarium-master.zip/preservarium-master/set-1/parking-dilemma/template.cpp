/******************READ-ONLY PART BEGINS*****************/
#include <bits/stdc++.h>
using namespace std;
/*******************READ-ONLY PART ENDS******************/

long long carParkingRoof(vector<long long> cars, int k) {
}

/******************READ-ONLY PART BEGINS*****************/
int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);

	int n; cin >> n;
	vector<long long> cars(n);
	for(auto &ele : cars) {
		cin >> ele;
	}
	int k; cin >> k;

	auto res = carParkingRoof(cars, k);
	cout << res << endl;

	return 0;
}
/*******************READ-ONLY PART ENDS******************/
