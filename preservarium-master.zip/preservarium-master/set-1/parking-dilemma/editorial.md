# Parking Dilemma 

---

# Intuition
To obtain the minimum length of a roof to cover atleast `k` cars, it is always better to cover exactly `k` consecutively parked cars. 


To determine consecutive locations, sort the location of the cars. The optimal answer would then be the length of the roof required to cover a sorted subarray of size `k`.

Suppose one optimal subarray is `[i, j]`. Since it must cover exactly `k` cars, we have

```
|[i, j]| = j - i + 1 = k
j = i + k - 1
```

Hence, for each `i`, we compute the corresponding `j`, and if it is within limits, we update our answer as 
```
|arr[i], arr[j]| = arr[j] - arr[i] + 1
```

Note: `|.|` represents the size of the interval.

Time complexity: `O(n)`.

---

## Pseudocode
```py
ans = infinity
sort(cars)
for i = 0, j = i + k - 1; j < n; i++, j++)
    ans = min(ans, cars[j] - cars[i] + 1)

print(ans)
```

---

# Alternate Approach
You can also implement it via **Deques**. Sort the location, and insert the first window of size `k` in a deque. The roof length required to cover this window is `(dq.back - dq.front + 1)`. Now, for each remaining element, remove the oldest car in the window from the front, add the latest one and recount the contribution.

---

## Pseudocode

```py
sort(cars)

for i in [0, k):
    dq.push_back(cars[i])

min_cover = dq.back - dq.front + 1
for i in [k, n):
    min_cover = min(min_cover, dq.back - dq.front  + 1)

print(min_cover)
```

---

# Code
* [Setter's Solution](sol.cpp)
* [Alternate Solution (Variety Jones)](sol-vj.cpp)