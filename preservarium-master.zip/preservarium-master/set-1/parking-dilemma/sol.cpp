#include<bits/stdc++.h>
using namespace std;

#define A(x) (x).begin(),(x).end()
#define sz(x) ((int)(x).size())
#define UNI(x) sort(A(x)); (x).erase(unique(A(x)),(x).end())
using i64 = long long;
void _read();


int main () { _read(); 

      int n;
      cin >> n;
      vector<i64> car(n);
      for(i64 &x : car)
            cin >> x;
      sort(A(car));
      int k; cin >> k;
      i64 ans = (1LL << 61);
      for(int i = 0, j = i + k - 1; j < n; i++, ++j)
            ans = min(ans, car[j] - car[i] + 1);
            
      cout << ans << '\n';
      return 0;
};

void _read() {
      ios_base :: sync_with_stdio(false);
      cin.tie(NULL);
      #ifdef LOCAL
      freopen("input.txt","r",stdin);
      #endif
}
