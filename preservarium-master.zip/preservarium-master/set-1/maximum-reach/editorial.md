# Maximum Reach 

---
# Intuition (Stack + DP)
We are interested in calculating the maximum reach of the `i-th` building. Assume that there exists a utility function `max_reach(i)` that would provide us with this value.

> How do we figure out `max_reach(i)` from other values?

Consider the first jump that you'd make. It clearly has to be on a building to the right, i.e `j > i`. Not only that, it should also be the minimal `j` such that `height[j] > height[i]`. To express it in compact terms, let's call this building `j` as the **Next Greater Element** (`NGE`) of the `i-th` building. Now, once we make the jump to `nge`, we are interested in the additional number of jumps that is possible from this point. By definition, we can get this value by invoking `max_reach(j)`.


To conclude, this is a linear **Dynamic Programming** problem. Let `dp[i]` denote the maximum reach of building `i`. The transition would then be 

```py 
dp[i] = 1 + dp[nge]
```

where `nge` is the **index** of the next building to the right having height greater than the `i-th` building. In order to calculate `nge` for each building `i`, one can follow the standard method which uses stack, as given in the following links: 

* [Reference 1: TechiDelight](https://www.techiedelight.com/next-greater-element/)
* [Reference 2: Leetcode](https://leetcode.com/problems/next-greater-element-i/discuss/991295/Java-%3A-O(N)-Time-%2B-O(N)-Space-using-Monotonic-Stack-with-explanation)

Make sure to handle the base case of the dp solution, i.e, the building having no `nge` value will have `dp[i] = 0`. 

---

## Pseudocode
```py
# (Assume zero based indexing)

# Finding the next greater element
nge = [-1]*n # stores the next greatest element
for i in [0, n):
    while(not stack.empty and height[stack.top] < height[i]) do
        nge[stack.top] = i
        stack.pop()
    stack.push(i)

# Using dp to find the maximum reach
dp = [0]*n
for i in [n - 1 downto 0]:
    if(nxt[i] == -1) # no next greater element was found 
        dp[i] = 0
    else 
        dp[i] = 1 + dp[nge[i]];

print(dp)

```

---

# Alternate Approach (Stack)
You don't really need to use **DP** if you understand the fundamental concept behind determining the **Next Greater Element**. There are 2 ways to determining the `NGE` array, one using forward pass, and the second using backward pass. (The implementation in the first section uses forward pass).

Here's my implementation for the backward pass `NGE` calculation:

```py
nge = [-1]*n
for i in [n - 1 downto 0]:
    while(not stack.empty and height[i] >= height[stack.top]):
        stack.pop
    if stack is not empty:
        nge[i] = stack.top
    stack.push(i)

print(nge)
```

Both versions use an invariant that the stack has to be **monotonic** at all times. Let us see why this should be true.

In the backward pass, suppose you inserted the last element onto the stack. Consider the second last element, if it is greater than the last element, there's no way the last element can be the NGE of any of the buildings. This is because, if it were the NGE for building `j`, it implies that `height[j] < height_of_last`. However, since `height_of_second_last > height_of_last`, it follows that `height_of_second_last > height[j]`, implying that the second last building should have been the candidate for `NGE` due to it being the closest.

In other words, when seen from left to right, sequences like `big small` can be collapsed to just `big`, because `big` acts as a barrier, and would never allow `small` to the be the `NGE`.

For sequences like `small big`, both of them can be of the NGE of some element, for example, `small` can be nge for `small - 1`, while `big` can be nge for `(small + big)/2`. Hence, we put them both on the stack.

> This implies that the top of the stack would always be the smallest candidate, while the last element in the stack would always be the largest candidate.

Once you've removed the redundant candidates from the stack, the top of the stack represents the nge of the current building. But what do the other elements in the stack represent? The other elements are precisely those elements to the right, which were strictly greater than their predecessors. Basically, the element from the second to top is the nge of the top element, the element from third to top is the nge of the element from second to top, and so on...

> The count of elements in the stack at this moment is equal to the number of jumps that is possible when you move from `nge` to `nge`, and that is exactly what we want.

---

## Pseudocode
```py
reach = [0]*n
for i in [n - 1 downto 0]:
    while(not stack.empty and height[i] >= height[stack.top]):
        stack.pop
    reach[i] = stack.size
    stack.push(i)

print(reach)
```

---

# Code
* [Setter's Solution](sol.cpp)
* [Alternate Approach (Variety Jones)](sol-vj-stack.cpp)

---
