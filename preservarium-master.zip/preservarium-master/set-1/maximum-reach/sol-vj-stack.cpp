/******************READ-ONLY PART BEGINS*****************/
#include <bits/stdc++.h>
using namespace std;
/*******************READ-ONLY PART ENDS******************/

vector<long long> solve(vector<long long> &a) {
	int n = a.size();

	vector<long long> res(n, 0);

	// stack stores indices, not values.
	stack<int> st;
	for(int i = n - 1; i >= 0; i--) {
		while(!st.empty() && a[i] >= a[st.top()]) {
			st.pop();
		}
		res[i] += (int)st.size();
		st.push(i);
	}
	return res;
}


int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);

	int n; cin >> n;
	vector<long long> a(n);
	for(auto &ele : a) {
		cin >> ele;
	}

	auto res = solve(a);
	for(auto &ele : res) {
		cout << ele << " ";
	}
	cout << endl;

	return 0;
}
