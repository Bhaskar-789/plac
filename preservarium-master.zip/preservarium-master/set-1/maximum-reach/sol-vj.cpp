/******************READ-ONLY PART BEGINS*****************/
#include <bits/stdc++.h>
using namespace std;
/*******************READ-ONLY PART ENDS******************/

vector<long long> solve(vector<long long> &a) {
	int n = a.size();

	// nge[i] = j implies that a[j] is the first element to the right
	// of i such that a[j] > i.
	// If no such element, nge[i] = -1
	vector<int> nge(n, -1);

	// stack stores indices, not values.
	stack<int> st;
	for(int i = n - 1; i >= 0; i--) {
		while(!st.empty() && a[i] >= a[st.top()]) {
			st.pop();
		}
		if(!st.empty()) {
			nge[i] = st.top();
		}
		st.push(i);
	}

	vector<long long> dp(n, 0);
	// dp[i] = 1 + dp[nge[i]]
	dp[n - 1] = 0;
	for(int i = n - 2; i >= 0; i--) {
		if(nge[i] != -1) {
			dp[i] = 1 + dp[nge[i]];
		}
	}
	return dp;
}


int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);

	int n; cin >> n;
	vector<long long> a(n);
	for(auto &ele : a) {
		cin >> ele;
	}

	auto res = solve(a);
	for(auto &ele : res) {
		cout << ele << " ";
	}
	cout << endl;

	return 0;
}
