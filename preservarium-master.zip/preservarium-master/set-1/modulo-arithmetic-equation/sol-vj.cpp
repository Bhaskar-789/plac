/******************READ-ONLY PART BEGINS*****************/
#include <bits/stdc++.h>
using namespace std;
/*******************READ-ONLY PART ENDS******************/

const int maxn = (int)1e6 + 6;

// Be careful with weird mod
const int mod = (int)1e6 + 7;

vector<int> spf;

void sieve() {
	spf.resize(maxn + 1);
	for(int num = 1; num < maxn; num++) {
		spf[num] = num;
	}

	for(int num = 2; num < maxn; num++) {
		// If not prime, continue. IMPORTANT.
		if(spf[num] != num) {
			continue;
		}

		// This is a prime. Iterate through each multiple
		// and make it the spf of all its multiples.
		for(int mult = 2*num; mult < maxn; mult += num) {
			if(spf[mult] == mult) {
				spf[mult] = num;
			}
		}
	}
}

// After some mathematical calculations, we can conclude that
// ans = count of divisors of (N!)^2
// N! = 1.2.3....n, hence, prime factors of all numbers from 
// 1 to N would contribute to the prime factorization of (N!).
// After adding the contribution of each prime, double them for (N!)^2.
// The number of divisors would be the product of (exponent + 1).
int ArithmeticEquation(int n) {
	// IMPORTANT : Don't forget to initiate spf.
	sieve();

	vector<int> prime_count(maxn + 1, 0);

	// Iterate through all numbers from 1 to N and update prime count.
	for(int num = 1; num <= n; num++) {
		// Make a copy, don't modify the loop iterator.
		int now = num;

		// Keep dividing by the smallest prime factor as long as you can.
		while(spf[now] != 1) {
			int prime_now = spf[now];
			prime_count[prime_now]++;
			now /= prime_now;
		}
	}

	// Since we are dealing with (N!)^2, double all occurences.
	for(auto &ele : prime_count) {
		ele *= 2;
	}

	long long res = 1;
	// Divisor count is prod(exp_i + 1) (exp_i denotes frequency of i-th prime.
	for(int num = 1; num < maxn; num++) {
		if(spf[num] == num) {
			res *= (prime_count[num] + 1);
			res %= mod;
		}
	}

	return res;
}

/******************READ-ONLY PART BEGINS*****************/
int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);

	int n; cin >> n;
	int res = ArithmeticEquation(n);
	cout << res << endl;

	return 0;
}
/*******************READ-ONLY PART ENDS******************/
