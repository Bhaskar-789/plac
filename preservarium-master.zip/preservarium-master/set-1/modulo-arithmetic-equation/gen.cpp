#include<iostream>
#include "testlib.h"
using namespace std;
/********************* Custom Inputs ***************************/
int n_low=1;
int n_high=1e6;
/********************* Custom Inputs ***************************/
#define endl '\n'
void generate();
int main(int argc, char* argv[]){
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";

	if(type == "small"){
		n_high=30;
	}

	if(type == "extreme"){
		n_low=1e6-100;
	}

	generate();
	return 0;
}
void generate(){
	int n = rnd.next(n_low, n_high);
	cout << n << endl;
}