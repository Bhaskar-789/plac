/******************READ-ONLY PART BEGINS*****************/
#include <bits/stdc++.h>
using namespace std;
/*******************READ-ONLY PART ENDS******************/

int ArithmeticEquation(int n) {
}

/******************READ-ONLY PART BEGINS*****************/
int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);

	int n; cin >> n;
	int res = ArithmeticEquation(n);
	cout << res << endl;

	return 0;
}
/*******************READ-ONLY PART ENDS******************/
