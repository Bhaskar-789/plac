# Modulo Arithmetic Equation 

---

# Intuition
Let `(x,y)`, be a positive integral solution of `1/x + 1/y = 1/(N!)` Now, Let us assume `N! = p`, therefore,  
```py
=> 1/x + 1/y = 1/p
=> xy = p(x + y)  
=> xy - p(x + y) + p*p = p*p
=> x(y - p) - p(y - p) = p*p
=> (x - p)(y - p) = p*p
```

Assuming `x - p = A`, and `y - p = B`  
we have, `AB = p^2`.  

We can see that each value of `A` and `B` represents a unique value for `x` and `y` respectively. Hence, the number of solution `(x,y)` is equal to the number of solution `(A,B)`, which is equal to the number of divisors of `p^2` or `(N!)^2`.   

The number of divisors of `(N!)^2` can be calculated by storing the frequency of prime factors of the number `N!`. This can be done by factorizing each number in the set `[1,N]` with the help of their smallest prime factors, and adding up the contribution of each number towards the frequency of a prime factor. The answer will then, simply be `ans` such that

```py
ans = (2 * cnt[P[0]] + 1)*(2 * cnt[P[1]] + 1)*(2 * cnt[P[2]] + 1)*...*(2 * cnt[P[n]] + 1)
```

where `cnt[P[i]]` is the frequency of prime factor `P[i]` in `N!`, and `n` is the number of prime factors. (Note that, the frequency of prime factor `P[i]` in `(N!)^2` is `2 * cnt[P[i]]`).  

The complexity of the program is `O(N * logN)`.

**Important Note**: Take care of weird modulo. (It's not `10^9 + 7`).


## Factorizing numbers using Sieve
First, we need to efficiently compute all the prime numbers in `[1, 10^6]`. To do so, we can use **Sieve's technique** for prime detection. We start with the first prime number, and cross out all its multiples as being not prime. Then we move on to the next uncrossed number, declare it as a prime and cross out all its multiples. We repeat this process untill we cannot find the next uncrossed number. In the end, all uncrossed numbers are prime.

Now, we need to compute the prime factorization of any number. To do so, we just make one minor change in Sieve's algorithm. Whenever we cross a number, we also record the first prime number that crossed it. Notice that the **Smallest Prime Factor** of any integer would be the first number to cross it. This way, we can create an array `spf`, where `spf[num]` would now denote the smallest prime factor of `num`. Of course, if the `spf` value does not change at all, it implies that the number is prime. There is no change in the time complexity of the algorithm.

Once we have the SPF array, we can compute the prime factorization of any number in `O(log(n))`. We already know the smallest prime factor, i.e, `spf[num]`, hence, `num/spf[num]` should give us a new integer. But now, we know the `spf` of this integer, which is also a prime factor of the original one. If we keep doing `num = num/spf[num]`, we can cycle through each prime factor, along with multiplicity. Since there can be atmost `log(N)` distinct prime factors, the time complexity is `O(log(n))`.

The time complexity for **Sieve's Algorithm** is `O(n log(log(n))`. (Try to prove it yourself or refer to other materials present online).


---

## Pseudocode
```py
# Sieve to store the smallest prime factor 
def sieve():
    # Stores the smallest prime factor
    int spf[N] = {0} 
    spf[1] = 1
    for i in [2, N]: 
        if (spf[i] is 0) 
            for j in [i : N] 
                if (spf[j] is 0) 
                    spf[j] = i
                j += i

    return spf  

# Storing the count of prime factors
def factorise(int x):
    # Stores the frequency of all prime factors
    int frequency[N] = {0}
    for i in [2, N]:
        int x = i
        
        # factorising each number
        while (x > 1) do
            frequency[spf[x]]++
            x /= spf[x]

    return frequency

def solve():
    sieve()
    factorise()
    ans = 0
    for each prime:
        ans += 2*frequency[prime] + 1

print(ans)
```

---

# Alternate Approach
> How do you find the number of positive integral solutions to `y = x/2` when `x` belongs to `[1, 10]`?

We can notice that once we fix `x`, `y` is uniquely determinely. However, for our use-case, `y` should also be an integer. Hence, we are interested in the number of ways to choose `x` such that `x/2` is an integer. In other words, how many `x` can you find such that `x%2 = 0`. Once we figure out those `x`, our `y` is automatically determined as an integer, hence the count of such `x` would be our answer.

In this problem, let's assume `z = N!`, where `z` is a constant. In this case, the equation becomes:
```py
1/x + 1/y = 1/z
```

Since there are only 2 variables, fixing one would uniquely determine the other. Let's convert it to the form `y = x/2` (as in the first example):
```py
1/y = 1/z - 1/x
y = xz/(x - z)
```

Since `z` is fixed, if we can somehow determine all those `x` which would make `xz/(x - z)` an integer, we are done. In other words, 
```py
xz % (x - z) == 0
```

Clearly, `(x - z)` should be greater than zero. WLOG, assume
```py
x = z + delta
```

A unique `delta` determines a unique `x`. Simplifying the equation, we have
```py
(z + delta)*z % delta must be 0
z*z % delta + z*delta % delta must be 0
```

Since `z*delta` is a multiple of `delta`, therefore `z*delta % delta = 0`. So, we are just left with

```py
z*z % delta must be 0
```

Hence, `delta` can be any and all of the divisors of `z^2`, and each such delta would determine a unique `x` which would determine a unique answer.

> The answer is the number of divisors of `(N!)^2`

## Counting Divisors
First, let us determine the count of divisors of `(N!)`. There's no such formula to derive the count of divisors of `(N!)^2` from divisors of `N!`, however, the underlying technique would give us an idea.

Suppose we have 
```py
num = p1^x1 * p2^x2 * p3^x3 ...
```

where each `pi` is a prime factor of `num`, then from your JEE days, you can recall that the count of divisors is `(x1 + 1)*(x2 + 1)... `. A quick **P&C** refresher on why this is true. Any divisor must contain the prime factor `pi` either `0` times, or `1` times, .... or `xi` times. Hence, each prime factor has `xi + 1` choices. Since they are independent, their product gives us unique numbers.

So far we have determined that if we can find prime factorization of a number, along with multiplicity, we can also count divisors too. However, **Sieve** only works till `10^6`, while we need to compute prime factorization of `10^6!`. 

If you notice carefully,

```
N! = 1*2*3*.....n
```

As we can see, although `N!` can be infinitely large, it can only contain the prime factors with same multiplicites that are present in all numbers from 1 to `n` (adding up the contribution along the way).

Hence, if we can find prime factorization and multiplicity of all numbers from 1 to n, we can reach the prime factorization for `N!`. For `N!^2`, we simply double each exponent, (recall **Exponent Law**). And on how to actually determine prime factorization using Sieve, you can read the editorial above.

Time Complexity: `O(N Log(N))`.

---

## Pseudocode
```py
# In my version, I keep spf[num] = num for prime.
# But be careful to not conclude spf[1] = 1 ===> 1 is prime.
def sieve():
    for num in [1, maxn):
        spf[num] = num
    
    for num in [2, maxn):
        # This number is not prime
        if spf[num] is not num:
            continue
        
        # Iterate through all multiples and mark it.
        for mult = 2*num; mult < maxn; mult += num:
            # If spf is already altered don't touch it.
            # If you do that, you'll end up with lpf.
            if spf[mult] == spf[mult]:
                spf[mult] = num

    
def solve():
    sieve()

    for num in [1, n]:
        # Common bug: Always make a copy and modify
        copy = num
        while (spf[copy] is not 1):
            prime_now = spf[now]
            exp_count[prime_now] += 1
            copy /= prime_now

    res = 1
    for all prime in [1, n]:
        res *= (2*exp_count[prime] + 1)
    
    print(res)
```

---

# Code
* [Setter's Solution](sol.cpp)
* [Alternate Solution (Variety Jones)](sol-vj.cpp)

---
