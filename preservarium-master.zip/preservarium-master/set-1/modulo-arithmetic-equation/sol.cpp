#include<bits/stdc++.h>
using namespace std;

#define A(x) (x).begin(),(x).end()
#define sz(x) ((int)(x).size())
#define UNI(x) sort(A(x)); (x).erase(unique(A(x)),(x).end())
using i64 = long long;
void _read();

// Change maxn appropiately.
const int maxn = 1e6 + 11;
struct SIEVE {
	vector<int> primes;
	bool ip[maxn];
	int spf[maxn];
	SIEVE() {
		fill(ip,ip+maxn,true);
		ip[0] = ip[1] = 0;
		for( int i = 2; i < maxn; i++) {
			if(!ip[i]) continue;
			spf[i] = i;
			primes.push_back(i);
			for( int j = (i << 1); j < maxn; j += i) {
				ip[j] = false;
				spf[j] = i;
			}
		}
	}
	bool is_prime(int x) const { return ip[x]; };
	vector<pair<int,int>> fac(int x) {
		assert(x > 1);
		vector<pair<int,int>> ret;
		while(x > 1) {
			int y = spf[x];
			int cnt = 0;
			while(x % y == 0) {
				x /= y;
				cnt++;
			}
			ret.emplace_back(y,cnt);
		}
		return ret;
	}
} sie;

struct Compressor {
      vector<int> b;
      Compressor(const vector<int> &v) {
            b = v;
            UNI(b);
      }
      Compressor() {};
      int f_map(int x) { return lower_bound(A(b), x) - b.begin(); };
      int r_map(int x) { assert(x < sz(b)); return b[x];};
      int size() { return sz(b); };
};

// Check for the weird mod.
const int mod = 1e6 + 7;

struct Solution {
      int n;
      Compressor C;
      Solution(int _n) : n(_n) { C = Compressor(sie.primes);}
      int answer() {
            vector<int> p(C.size());
            for(int i = 2; i <= n; i++) {
                  auto fac = sie.fac(i);
                  for(auto &[x, y] : fac)
                        p[C.f_map(x)] += y;
            }
            int ans = 1;
            for(int x : p) {
                  ans = (1LL * ans * (2 * x + 1)) % mod;
            }
            return ans;
      }
};

int main () { _read(); 

      int N;
      cin >> N;
      cout << Solution(N).answer() << '\n';
      return 0;
};

void _read() {
      ios_base :: sync_with_stdio(false);
      cin.tie(NULL);
      #ifdef LOCAL
      freopen("input.txt","r",stdin);
      #endif
}
