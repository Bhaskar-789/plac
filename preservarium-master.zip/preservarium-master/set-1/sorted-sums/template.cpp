/******************READ-ONLY PART BEGINS*****************/
#include <bits/stdc++.h>
using namespace std;
/*******************READ-ONLY PART ENDS******************/

int sortedSum(vector<int> a) {
}

/******************READ-ONLY PART BEGINS*****************/
int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);

	int n; cin >> n;
	vector<int> a(n);
	for(auto &ele : a) {
		cin >> ele;
	}

	auto res = sortedSum(a);
	cout << res << endl;

	return 0;
}
/*******************READ-ONLY PART ENDS******************/
