#include<bits/stdc++.h>
using namespace std;

#define A(x) (x).begin(),(x).end()
#define sz(x) ((int)(x).size())
#define UNI(x) sort(A(x)); (x).erase(unique(A(x)),(x).end())
using i64 = long long;
void _read();

/*
? Idea;
We will create a mapping f : A -> B will the following property
!for all (a, b) in A we have 
      ! a < b => f(a) < f(b)
^ 
Now we have the following methods,
      * For inserting, value f(a), we can add f(a) at position a;
      * Sum is normal Range Sum;
      * We can create two fenwick trees, one for range sum, and one for frequency.
      * That is equivalent of having two fields in a BBST.
      * Is this really that complicated or I'm just messing things up?
      * Well Let's just go with it for now.
      * Umm, So we really just need after inserting x, the sum of elements >= x;

*/
const int mod = 1e9 + 7;
template<bool _MOD> struct fenwick {
      int n;
      vector<int> ft;
      int tot = 0;
      fenwick(int _n) : n(_n), ft(_n + 1) {};
      fenwick() {};
      void rev(int &x) {
            if(!_MOD)
                  return;
            while(x < 0)
                  x += mod;
            while(x > mod)
                  x -= mod;
      }
      void update(int p, int x) {
            tot += x;
            rev(tot);
            for(++p; p <= n; p += (p & -p))
                  ft[p] += x, rev(ft[p]);
                  
      }
      int sum(int p) {
            int res = 0;
            for(++p; p > 0; p -= (p & -p))
                  res += ft[p], rev(res);
            return res;
      }
};

struct Compressor {
      vector<int> b;
      void push(int x) { b.push_back(x); };
      void compress() { UNI(b); };
      int f_map(int x) { return int(lower_bound(A(b), x) - b.begin()); };
      int r_map(int x) { assert(x >= 0 && x < sz(b)); return b[x];}
      int size() { return sz(b); };
} C;

/*
      * Insert a element
      * f(x) : Find the sum of all elements Strictly Less than x
      * Find Number of elements strictly less than x;
      * Find the sum of elements Greater than or equal to x;
      * All Operations are modulo;
*/

class DS {
      fenwick<true> sum;
      fenwick<false> pos;
public:
      DS() { 
            sum = fenwick<true>(C.size());
            pos = fenwick<false>(C.size());
      }
      void insert(int i) {
            int x = C.f_map(i);
            sum.update(x, i);
            pos.update(x, 1);
      }
      int get(int i) {
            int x = C.f_map(i);
            int ret = sum.tot;
            ret = (ret - sum.sum(x - 1)) % mod;
            if(ret < 0)
                  ret += mod;
            return ret; 
      }
      int getPos(int i) {
            int x = C.f_map(i);
            return pos.sum(x - 1) + 1;
      }

};

int main () { _read(); 

      int n;
      cin >> n;
      vector<int> v(n);
      for(int &x : v) {
            cin >> x;
            C.push(x);
      }
      C.compress();
      DS D = DS();
      i64 ans = 0, prev = 0;
      for(const int &x : v) {
            i64 cur = prev + D.get(x) + D.getPos(x) * x;
            ans += cur;
	    // revert if needed
	    ans %= mod;
            prev = cur;
            D.insert(x);
      }
      cout << ans << '\n';
      return 0;
};

void _read() {
      ios_base :: sync_with_stdio(false);
      cin.tie(NULL);
      #ifdef LOCAL
      freopen("input.txt","r",stdin);
      #endif
}
