/******************READ-ONLY PART BEGINS*****************/
#include <bits/stdc++.h>
using namespace std;
/*******************READ-ONLY PART ENDS******************/

long long teamFormation(vector<int> score, int team_size, int k) {
}

/******************READ-ONLY PART BEGINS*****************/
int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);

	int n; cin >> n;
	vector<int> score(n);
	for(auto &ele : score) {
		cin >> ele;
	}
	
	int team_size, k;
	cin >> team_size >> k;

	auto res = teamFormation(score, team_size, k);
	cout << res << endl;

	return 0;
}
/*******************READ-ONLY PART ENDS******************/
