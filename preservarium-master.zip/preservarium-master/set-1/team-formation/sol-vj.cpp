/******************READ-ONLY PART BEGINS*****************/
#include <bits/stdc++.h>
using namespace std;
/*******************READ-ONLY PART ENDS******************/

long long teamFormation(vector<int> score, int team_size, int k) {
	int n = score.size();

	deque<int> dq;
	for(int i = 0; i < n; i++) {
		dq.push_back(score[i]);
	}

	priority_queue<int> left_heap, right_heap;
	
	// Fill first "k" element in left_heap (it has high priority).
	for(int cnt = 0; cnt < k; cnt++) {
		if(!dq.empty()) {
			left_heap.push(dq.front());
			dq.pop_front();
		}
	}

	// Now, fill the last "k" element in right heap
	for(int cnt = 0; cnt < k; cnt++) {
		if(!dq.empty()) {
			right_heap.push(dq.back());
			dq.pop_back();
		}
	}


	long long sum = 0;

	// Each element is in a single heap now. left_heap takes priority.
	for(int taken = 0; taken != team_size; taken++) {
		// First decide which heap to pop from.
		const int left = 0, right = 1;
		int pop_type;
		if(right_heap.empty()) {
			pop_type = left;
		} else if(left_heap.empty()) {
			pop_type = right;
		} else {
			// In case of tie, prefer left heap
			if(right_heap.top() > left_heap.top()) {
				pop_type = right;
			} else if(left_heap.top() >= right_heap.top()) {
				pop_type = left;
			}
		}

		if(pop_type == left) {
			assert(!left_heap.empty());
			sum += left_heap.top();
			left_heap.pop();

			if(!dq.empty()) {
				left_heap.push(dq.front());
				dq.pop_front();
			}
		}
		else if(pop_type == right) {
			assert(!right_heap.empty());
			sum += right_heap.top();
			right_heap.pop();

			if(!dq.empty()) {
				right_heap.push(dq.back());
				dq.pop_back();
			}
		}
	}
	return sum;
}

/******************READ-ONLY PART BEGINS*****************/
int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);

	int n; cin >> n;
	vector<int> score(n);
	for(auto &ele : score) {
		cin >> ele;
	}
	
	int team_size, k;
	cin >> team_size >> k;

	auto res = teamFormation(score, team_size, k);
	cout << res << endl;

	return 0;
}
/*******************READ-ONLY PART ENDS******************/
