# Team Formation 

---

# Intuition
Let us assume that the first `k` employees form the prefix window, and the last `k` employees form the suffix window. The main idea is to choose the maximum element from the suffix or prefix window and update the respective window. We keep on repeating this process until our team size reaches `teamSize`.

### Some ideas regarding the implementation :
- We can keep two <b>priority_queues</b> to represent the prefix and the suffix window. Note that the size of these windows will be `min(k, remaining employees)`. 
Let the prefix window be denoted by a priority queue `q[0]` and the suffix window by priority queue `q[1]`
- The score of the remaining employees that are not the part of the window can be tracked using a `deque`, as it allows removing elements from both the ends. 
- We can query and erase the **maximum** scored employee from the top of the window in `O(log k)`. For instance, suppose the prefix window has maximum scored employee as compared to the suffix window that is 
    ```py
        q[0].top() > q[1].top()
    ``` 
    Now, we will remove the topmost element from `q[0]`, add it to our answer and update the window
- To update a window, say, the prefix window, we need to insert the element present at the front of the `deque` in `q[0]`. This can be done by popping an element from the front of the `deque` and adding it to `q[0]`.
- Similar approach can be used if the maximum element is present in `q[1]`. In that case we will remove the topmost element from `q[1]` and update it by popping an element from the back of the `deque`.

---

## Pseudocode
```py
priority_queue<int> q[2] # prefix(q[0]) and suffix(q[1]) window 
deque<int> de # contains the scores of remaining employees
int team, k

# Initially the size of the windows will be atmost k
def preprocess():
    for x in [0, 1] : 
        for i in [0, k): 
            if(de is not empty)
                if(x is not zero)
                    q[1].push(de.back())
                    de.pop_back()
                else 
                    q[0].push(de.front())
                    de.pop_front()

# Removes the maximum element from the window and updates them
def remove(int x):
    int y = q[x].top()
    q[x].pop()
    if (de is not empty) 
        q[x].push(x ? de.back() : de.front())
        (x ? de.pop_back() : de.pop_front())
    
    return y


# Pops & returns the maximum element from the window
def getMax():
    if (q[1] is empty) 
        return remove(0)

    if (q[0] is empty)) 
        return remove(1)

    if(q[0].top() < q[1].top)
        return remove(1)
    else
        return remove(0) 

# calculates the answer
def get_answer():
    # First, transfer elements to deque
    preprocess()
    long long ret = 0
    repeat team_size times:
        ret += getMax()
        
    return ret;

print(get_answer())
```

---

# Alternate Approach
Let's maintain 2 **max_heaps**. One for the prefix window, and one for the suffix window. As per the rules, we need to choose the maximum element amongst these 2 heaps, and remove it at every stage, while adding an incoming element.

Since the maximum element of a heap is stored at the top of the tree, it is just sufficient to compare the maximum element of `left_heap` and `right_heap`.

If there's no tie, we just need to remove the maximum element from the corresponding heap. In case of tie, i.e, `left_heap.max == right_heap.max`, we should always prioritize deletion from `left_heap`.

These things are trivial if the prefix and suffix window are disjoint. However, if the remaining array has less than `2*k` elements, then prefix and suffix would start overlapping.

So, how do we deal with this problem? Do we maintain 2 copies of overlapping elements in both the heaps? But how do we ensure deletion from both, as heaps don't have random access? and how to resolve ties or perform insertion in the correct heap?

To get rid of this issue, we can enforce a rule that every element can only be present in a single heap. Since we have to prioritize deletion from `left_heap`, we need to ensure that `left_heap` is filled with all available elements before filling the `right_heap`, which can be possibly empty.

Once we have figured out which heap to delete from, we can just do `heap.pop`. But for addition of new elements, we also need to keep track of the last element that was inserted into the heap, so that we can add the left/right neigbour. This might again cause implementation issues for overlapping sequences.

To resolve this, let's transfer all the elements to a **deque**. Once we place an element into a particular heap, we remove it from the deque. In this way,

> The front of the deque would always denote the next element that is supposed to go into the left heap, while the back of the deque denotes the next element that is supposed to go into the right heap.

To summarize the algorithm, we need to transfer all elements to a deque, then transfer the first `k` elements of the deque to `left_heap` and last `k` elements to the `right_heap`. Then, until we have reached `team_size`, we need to first figure out which heap to perform the deletion on, and do the corresponding insertion via deque's front/back.

Time Complexity of the approach: `O(N Log(N))`.

---

## Psuedocode

```py
# Transfer all elements to the deque
for each element in score:
    dq.push_back(element)

# IMPORTANT: First, transfer k elements to left heap
repeat k times:
    if dq is not empty:
        left_heap.push(dq.front)
        dq.pop_front

# Next, transfer k element to the right heap
repeat k times:
    if dq is not empty:
        right_heap.push(dq.back)
        dq.pop_back

sum = 0
repeat team_size times:
    # Find which heap to pop from
    if right_heap is empty:
        pop_from = left
    else if left_heap is empty:
        pop_from = right
    else:
        # In case of tie, prefer left heap
        if left_heap.max >= right_heap.max:
            pop_from = left
        else:
            pop_from = right
    
    # Need to pop from left_heap
    if pop_from is left:
        sum += left_heap.max
        left_heap.pop
        if dq is not empty:
            left_heap.push(dq.front)
            dq.pop_front

    # Need to pop from right_heap
    else if pop_from is right:
        sum += right_heap.max
        right_heap.pop
        if dq is not empty:
            right_heap.push(dq.back)
            dq.pop_back


print(sum)
```

---

# Code
* [Setter's Solution](sol.cpp)
* [Alternate Solution (Variety Jones)](sol-vj.cpp)

---
