#include<bits/stdc++.h>
using namespace std;

#define A(x) (x).begin(),(x).end()
#define sz(x) ((int)(x).size())
#define UNI(x) sort(A(x)); (x).erase(unique(A(x)),(x).end())
using i64 = long long;
void _read();

// You have an array, a window_size, and a team size;
// You should take the maximum or the minimum element from the array;

class Solution {
      priority_queue<int> q[2];
      deque<int> de;
      int l, r, n, k, team;
public:
      Solution() {
            INPUT();
           for(int x : {0, 1}) {
                 for(int i = 0; i < k && !de.empty(); i++) {
                       q[x].push(x ? de.back() : de.front());
                       (x ? de.pop_back() : de.pop_front());
                 }
           }
      }
private:
      void INPUT() {
            cin >> n;
            de = deque<int>(n);
            for(int &x : de)
                  cin >> x;
            cin >> team >> k;
      }
      int remove(int x) {
            int y = q[x].top();
            q[x].pop();
            if(!de.empty()) {
                  q[x].push(x ? de.back() : de.front());
                  (x ? de.pop_back() : de.pop_front());
            }
            return y;
      }
      int get() {
            assert(!q[0].empty() || !q[1].empty());
            if(q[1].empty()) {
                  return remove(0);
            }
            if(q[0].empty()) {
                  return remove(1);
            }
            return remove(q[0].top() < q[1].top());
      }
public:
      long long get_answer() {
            long long ret = 0;
            while(team--) {
                  ret += get();
            }
            return ret;
      }
};

int main () { _read(); 

      cout << Solution().get_answer() << '\n';
      return 0;
};

void _read() {
      ios_base :: sync_with_stdio(false);
      cin.tie(NULL);
      #ifdef LOCAL
      freopen("input.txt","r",stdin);
      #endif
}
