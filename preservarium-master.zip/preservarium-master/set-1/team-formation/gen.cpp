#include<iostream>
#include "testlib.h"
using namespace std;
/********************* Custom Inputs ***************************/
int n_low=1;
int n_high=1e5;
int score_low=1;
int score_high=1e9;
/********************* Custom Inputs ***************************/
#define endl '\n'
void generate();
int main(int argc, char* argv[]){
	registerGen(argc, argv, 1);
	string type = argc > 1 ? argv[1] : "unexpected";

	if(type == "small"){
		n_high = 20;
		score_high = 50;
	}

	if(type == "extreme"){
		n_low = n_high;
		score_low = 1e8;
	}

	generate();
	return 0;
}
void generate(){
	int n = rnd.next(n_low, n_high);
	int team_size = rnd.next(1, n);
	int k = rnd.next(1, n);
	vector<int>a;
	while((int)a.size() != n){
		a.push_back(rnd.next(score_low,score_high));
	} 
	cout << n << endl;
	for(auto &ele : a){
		cout << ele << endl;
	}
	cout << team_size << endl;
	cout << k << endl;
}